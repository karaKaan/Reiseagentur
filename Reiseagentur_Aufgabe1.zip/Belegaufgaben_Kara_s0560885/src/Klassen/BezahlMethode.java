package Klassen;

/***
 * 
 * Die Klasse BezahlMethode ist Vorrausetzung, dass ein Objekt der Klasse BezahlMethode angelegt werden kann.
 * 
 * @author                   Kaan_Kara_s0560885
 * @eclipseVersion           2019-09 R (4.13.0)
 * @javaVersion              12
 * @runTime                  33
 * @erstellungsDatum         21.10.2019
 * @letzte�nderungsDatum     25.10.2019
 *
 */

public class BezahlMethode {
	/**
	 * Die Klasse BezahlMethode hat die Variablen String bezeichnung und String beschreibung.
	 * Die Variablen sind alle private.
	 */
	
	private String bezeichnung;
	private String beschreibung;
	
	
	/**
	 * Die Signatur des Konstruktors muss erf�llt werden, damit ein Objekt der Klasse BezahlMethode entstehen kann.
	 * Daf�r m�ssen die Parameter(siehe unten) vollst�ndig ausgef�llt werden.
	 * 
	 * @param bezeichnung
	 * @param beschreibung
	 */
	public BezahlMethode(String bezeichnung, String beschreibung) {
		super();
		this.bezeichnung = bezeichnung;
		this.beschreibung = beschreibung;
	}

	/**
	 * Gibt die Variable bezeichnung zur�ck.
	 * @return bezeichnung
	 */
	public String getBezeichnung() {
		return bezeichnung;
	}

	/**
	 * Legt die Variable bezeichnung an.
	 * @param bezeichnung
	 */
	public void setBezeichnung(String bezeichnung) {
		this.bezeichnung = bezeichnung;
	}

	/**
	 * Gibt die Variable beschreibung zur�ck.
	 * @return beschreibung
	 */
	public String getBeschreibung() {
		return beschreibung;
	}

	/**
	 * Legt die Variable beschreibung an.
	 * @param beschreibung
	 */
	public void setBeschreibung(String beschreibung) {
		this.beschreibung = beschreibung;
	}
	
	
	
	
	
	
}
