package Klassen;

/***
 * 
 * Die Klasse Kunde ist Vorrausetzung, dass ein Objekt der Klasse Kunde angelegt werden kann.
 * 
 * 
 * @author                   Kaan_Kara_s0560885
 * @eclipseVersion           2019-09 R (4.13.0)
 * @javaVersion              12
 * @runTime                  33
 * @erstellungsDatum         21.10.2019
 * @letzte�nderungsDatum     25.10.2019
 * 
 */

public class Kunde {
	
	/**
	 * Die Klasse Kunde hat die Variablen int kundenNr, String anrede, String vornamen, String nachnamen, String emailAdresse;
	 * int telefonNr und String geburtsDatum.
	 * Au�erdem werden Objekte der Klassen Adresse in die Variablen privateAdresse und businessAdresse hinzugef�gt.
	 * Das gleiche passiert auch bei der Klasse BezahlMethode, mit der Variable bezahlMethode.
	 * 
	 * Au�erdem sind die Variablen alle private.
	 * 
	 * 
	 */
	
	private int kundenNr;
	private String anrede;
	private String vornamen;
	private String nachnamen;
	private String emailAdresse;
	private	int telefonNr;
	private String geburtsDatum;
	private Adresse privateAdresse;
	private Adresse businessAdresse;
	private BezahlMethode bezahlMethode;
		
	
	/**
	 * 
	 * Die Signatur des Konstruktors muss erf�llt sein, damit ein Objekt der Klasse Kunde erstellt werden kann.
	 * Daf�r sind die unten stehenden Parameter n�tig.
	 * 
	 * @param kundenNr
	 * @param anrede
	 * @param vornamen
	 * @param nachnamen
	 * @param emailAdresse
	 * @param telefonNr
	 * @param geburtsDatum
	 * @param privateAdresse
	 * @param businessAdresse
	 * @param bezahlMethode
	 */
	public Kunde(int kundenNr, String anrede, String vornamen, String nachnamen, String emailAdresse, int telefonNr,
			String geburtsDatum, Adresse privateAdresse,  BezahlMethode bezahlMethode) {
		super();
		this.kundenNr = kundenNr;
		this.anrede = anrede;
		this.vornamen = vornamen;
		this.nachnamen = nachnamen;
		this.emailAdresse = emailAdresse;
		this.telefonNr = telefonNr;
		this.geburtsDatum = geburtsDatum;
		this.privateAdresse = privateAdresse;
		this.bezahlMethode = bezahlMethode;
	}
	
	/**
	 * Gibt die Variable kundenNr zur�ck.
	 * @return kundenNr
	 */
	public int getKundenNr() {
		return kundenNr;
	}
	
	/**
	 * Legt die Variable kundenNr an.
	 * @param kundenNr
	 */
	public void setKundenNr(int kundenNr) {
		this.kundenNr = kundenNr;
	}
	
	/**
	 * Gibt die Variable anrede zur�ck.
	 * @return anrede
	 */
	public String getAnrede() {
		return anrede;
	}
	
	/**
	 * Legt die Variable anrede an.
	 * @param anrede
	 */
	public void setAnrede(String anrede) {
		this.anrede = anrede;
	}
	
	/**
	 * Gibt die Variable vornamen zur�ck.
	 * @return vornamen
	 */
	public String getVornamen() {
		return vornamen;
	}
	
	/**
	 * Legt die Variable vornamen an.
	 * @param vornamen
	 */
	public void setVornamen(String vornamen) {
		this.vornamen = vornamen;
	}
	
	/**
	 * Gibt die Variable nachnamen zur�ck.
	 * @return nachnamen
	 */
	public String getNachnamen() {
		return nachnamen;
	}
	
	/**
	 * Legt die Variable nachnamen an.
	 * @param nachnamen
	 */
	public void setNachnamen(String nachnamen) {
		this.nachnamen = nachnamen;
	}
	
	/**
	 * Gibt die Variable emailAdresse zur�ck.
	 * @return emailAdresse
	 */
	public String getEmailAdresse() {
		return emailAdresse;
	}
	
	/**
	 * Legt die Variable emailAdresse an.
	 * @param emailAdresse
	 */
	public void setEmailAdresse(String emailAdresse) {
		this.emailAdresse = emailAdresse;
	}
	
	/**
	 * Gibt die Variable telefonNr zur�ck.
	 * @return telefonNr
	 */
	public int getTelefonNr() {
		return telefonNr;
	}
	
	/**
	 * Legt die Variable telefonNr an.
	 * @param telefonNr
	 */
	public void setTelefonNr(int telefonNr) {
		this.telefonNr = telefonNr;
	}
	
	/**
	 * Gibt die Variable geburtsDatum zur�ck.
	 * @return geburtsDatum
	 */
	public String getGeburtsDatum() {
		return geburtsDatum;
	}
	
	/**
	 * Legt die Variable geburtsDatum an.
	 * @param geburtsDatum
	 */
	public void setGeburtsDatum(String geburtsDatum) {
		this.geburtsDatum = geburtsDatum;
	}
	
	/**
	 * Gibt den Objekt der Klasse Adresse, als Variable privateAdresse zur�ck.
	 * @return privateAdresse
	 */
	public Adresse getPrivateAdresse() {
		return privateAdresse;
	}
	
	/**
	 * Legt den Objekt der Klasse Adresse, als Variable privateAdresse an.
	 * @param privateAdresse
	 */
	public void setPrivateAdresse(Adresse privateAdresse) {
		this.privateAdresse = privateAdresse;
	}
	
	/**
	 * Gibt den Objekt der Klasse Adresse, als Variable businessAdresse zur�ck.
	 * @return businessAdresse
	 */
	public Adresse getBusinessAdresse() {
		return businessAdresse;
	}
	
	/**
	 * Legt den Objekt der Klasse Adresse, als Variable businessAdresse an.
	 * @param businessAdresse
	 */
	public void setBusinessAdresse(Adresse businessAdresse) {
		this.businessAdresse = businessAdresse;
	}
	
	/**
	 * Gibt den Objekt der Klasse BezahlMethode, als Variable bezahlMethode zur�ck.
	 * @return the bezahlMethode
	 */
	public BezahlMethode getBezahlMethode() {
		return bezahlMethode;
	}
	
	/**
	 * Legt den Objekt der Klasse BezahlMethode, als Variable bezahlMethode an.
	 * @param bezahlMethode
	 */
	public void setBezahlMethode(BezahlMethode bezahlMethode) {
		this.bezahlMethode = bezahlMethode;
	}
	
	
	
}
