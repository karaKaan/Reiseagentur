package Klassen;

import java.util.ArrayList;

/***
 * 
 * Die Klasse ReiseAgentur ist Vorrausetzung, dass ein Objekt der Klasse ReiseAgentur angelegt werden kann.
 * Au�erdem f�gt es die Objekte der Klasse Kunde in eine ArrayList.
 * 
 * 
 * @author                   Kaan_Kara_s0560885
 * @eclipseVersion           2019-09 R (4.13.0)
 * @javaVersion              12
 * @runTime                  33
 * @erstellungsDatum         21.10.2019
 * @letzte�nderungsDatum     25.10.2019
 *	
 */

public class ReiseAgentur {
	
	/***
	 * Als Attribute f�r die Klasse ReiseAgentur wurde ein String ustIdNr, String name, ein Objekt der Klasse Adresse businessAdresse
	 * und eine ArrayListe kundeArrList die, die Objekte der Klasse Kunde aufnehmen kann, angelegt. 
	 * 
	 * Au�erdem sind die Variablen alle private.
	 * 
	 */
	
	private String ustIdNr;
	private String name;
	private Adresse businessAdresse;
	private ArrayList<Kunde> kundeArrList = new ArrayList<Kunde>();


	/**
	 * Der Konstruktor ben�tigt die Variablen String ustIdNr, String name und Adresse businessAdresse.
	 * Wenn die Signatur des Konstruktor richtig eingetragen worden ist, wird ein Objekt der Klasse ReiseAgentur angelegt.
	 * 
	 * @param ustIdNr
	 * @param name
	 * @param businessAdresse
	 * @param kunde
	 */
	public ReiseAgentur(String ustIdNr, String name, Adresse businessAdresse) {
		super();
		this.ustIdNr = ustIdNr;
		this.name = name;
		this.businessAdresse = businessAdresse;

	}
	
	/**
	 * Gibt die Variable ustIdNr zur�ck.
	 * @return the ustIdNr
	 */
	public String getUstIdNr() {
		return ustIdNr;
	}
	
	/**
	 * Legt die Variable ustIdNr an.
	 * @param ustIdNr
	 */
	public void setUstIdNr(String ustIdNr) {
		this.ustIdNr = ustIdNr;
	}
	
	/**
	 * Gibt die Variable name zur�ck.
	 * @return name
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * Legt die Variable name an.
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * Gibt den Objekt der Klasse Adresse, als Variable businessAdresse zur�ck.
	 * @return businessAdresse
	 */
	public Adresse getBusinessAdresse() {
		return businessAdresse;
	}
	
	/**
	 * Legt den Objekt der Klasse Adresse, als Variable businessAdresse an.
	 * @param businessAdresse 
	 */
	public void setBusinessAdresse(Adresse businessAdresse) {
		this.businessAdresse = businessAdresse;
	}
	
	/**
	 * Gibt eine Liste von Objekten der Klasse Kunde zur�ck.
	 * @return kunde
	 */
	public ArrayList<Kunde> getKundeArrList() {
		return kundeArrList;
	}
	
	/**
	 * Legt die Objekte der Klasse Kunde an.
	 * @param kunde 
	 */
	public void setKundeArrList(ArrayList<Kunde> kunde) {
		this.kundeArrList = kunde;
	}
	
}
