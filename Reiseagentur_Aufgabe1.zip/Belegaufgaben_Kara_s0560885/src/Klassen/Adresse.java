package Klassen;

/***
 * 
 * Die Klasse Adresse ist Vorrausetzung, dass ein Objekt der Klasse Adresse angelegt werden kann.
 * 
 * @author                   Kaan_Kara_s0560885
 * @eclipseVersion           2019-09 R (4.13.0)
 * @javaVersion              12
 * @runTime                  33
 * @erstellungsDatum         21.10.2019
 * @letzte�nderungsDatum     25.10.2019
 * 
 */

public class Adresse {
	
	/**
	 * Die Klasse Adresse hat die Variablen String stra�e, String hausNr, int plz und String ort.
	 * Die Variablen sind alle private.
	 */
	
	private String stra�e;
	private String hausNr;
	private int plz;
	private String ort;
	
	
	/**
	 * Die Signatur des Konstruktors muss erf�llt werden, damit ein Objekt der Klasse Adresse entstehen kann.
	 * Daf�r m�ssen die Parameter(siehe unten) vollst�ndig ausgef�llt werden.
	 * 
	 * @param stra�e
	 * @param hausNr
	 * @param plz
	 * @param ort
	 */
	public Adresse(String stra�e, String hausNr, int plz, String ort) {
		super();
		this.stra�e = stra�e;
		this.hausNr = hausNr;
		this.plz = plz;
		this.ort = ort;
	}


	/**
	 * Gibt die Variable stra�e zur�ck.
	 * @return stra�e
	 */
	public String getStra�e() {
		return stra�e;
	}
	
	/**
	 * Legt die Variable stra�e an.
	 * @param stra�e
	 */
	public void setStra�e(String stra�e) {
		this.stra�e = stra�e;
	}
	
	/**
	 * Gibt die Variable hausNr zur�ck.
	 * @return hausNr
	 */
	public String getHausNr() {
		return hausNr;
	}
	
	/**
	 * Legt die Variable hausNr an.
	 * @param hausNr
	 */
	public void setHausNr(String hausNr) {
		this.hausNr = hausNr;
	}
	
	/**
	 * Gibt die Variable plz zur�ck.
	 * @return plz
	 */
	public int getPlz() {
		return plz;
	}
	
	/**
	 * Legt die Variable plz an.
	 * @param plz
	 */
	public void setPlz(int plz) {
		this.plz = plz;
	}
	
	/**
	 * Gibt die Variable ort zur�ck.
	 * @return ort
	 */
	public String getOrt() {
		return ort;
	}
	
	/**
	 * Legt die Variable ort an.
	 * @param ort
	 */
	public void setOrt(String ort) {
		this.ort = ort;
	}
	
	
	

}
