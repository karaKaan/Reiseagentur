package Starter;
import Klassen.Adresse;
import Klassen.BezahlMethode;
import Klassen.Kunde;
import Klassen.ReiseAgentur;

/***
 *
 * Die Starter-Klasse legt die Objekte der jeweiligen Klassen an
 * und gibt die Informationen auf der Konsole wieder.
 * 
 * @author                   Kaan_Kara_s0560885
 * @eclipseVersion           2019-09 R (4.13.0)
 * @javaVersion              12
 * @runTime                  33
 * @erstellungsDatum         21.10.2019
 * @letzte�nderungsDatum     25.10.2019
 * 
 */

public class Starter {


	/***
	 * In der main-Methode legen wir die Objekte der Klassen Adresse, BezahlMethode, Kunde und ReiseAgentur an, sowie mit den dazugeh�rigen
	 * Information, an.
	 * Die erstellten Objekte der Klasse Kunden werden in die ArrayListe von getKundeArrList hinzugef�gt.
	 * Diese Informationen werden in der Konsole ausgegeben, unzwar immer ausgehend von der Klasse ReiseAgentur.
	 * 
	 * @param args
	 * 
	 */
	
	public static void main(String[] args) {
		Adresse reiseAgenturAdresse = new Adresse("Hauptstra�e", "5a", 10559, "Berlin");
		Adresse kundePrivateAdresse1 = new Adresse("Hauptstra�e", "13b", 11342, "Berlin");
		Adresse kundePrivateAdresse2 = new Adresse("Beispielstra�e", "22d", 44321, "Frankfurt");
		Adresse kundeBusinessAdresse2 = new Adresse("Helsinkistra�e", "9c", 40454, "Frankfurt");
		Adresse kundePrivateAdresse3 = new Adresse("Musterstra�e", "3a", 30321, "Hamburg");
	
		BezahlMethode kundeBezahlMethodePaypal = new BezahlMethode("Paypal", "Konto: bob.m�ller@gamil.com");
		BezahlMethode kundeBezahlMethodeKlarna = new BezahlMethode("Klarna", "Konto: maria.schmitt@gmail.com");
		BezahlMethode kundeBezahlMethodeSofort = new BezahlMethode("Sofort�berweisung", "Konto: schneider.martin@gmail.com");
		
		Kunde kundeBobMueller = new Kunde(1, "Herr", "Bob", "M�ller", "bob.m�ller@gmail.com", 5554223, "02.03.1989", kundePrivateAdresse1,kundeBezahlMethodePaypal);
		Kunde kundeMariaSchmitt = new Kunde(2, "Frau", "Maria", "Schmitt", "maria.schmitt@gmail.com", 5011426, "23.11.1993", kundePrivateAdresse2, kundeBezahlMethodeKlarna);
		kundeMariaSchmitt.setBusinessAdresse(kundeBusinessAdresse2);
		Kunde kundeMartinSchneider = new Kunde(3, "Herr", "Martin", "Schneider", "schneider.martin@gmail.com", 9528844, "06.07.1980", kundePrivateAdresse3, kundeBezahlMethodeSofort);

		ReiseAgentur magicHolidayReiseAgentur = new ReiseAgentur("DE812524001", "Magic Holidays Reiseagentur",reiseAgenturAdresse);
		
		magicHolidayReiseAgentur.getKundeArrList().add(kundeBobMueller);
		magicHolidayReiseAgentur.getKundeArrList().add(kundeMariaSchmitt);
		magicHolidayReiseAgentur.getKundeArrList().add(kundeMartinSchneider);
		
		
		System.out.println("Information zur Reiseagentur" + "\n"+ magicHolidayReiseAgentur.getUstIdNr() + " | " + magicHolidayReiseAgentur.getName() + " | " 
				+ magicHolidayReiseAgentur.getBusinessAdresse().getStra�e() + " | " + magicHolidayReiseAgentur.getBusinessAdresse().getHausNr() + " | " 
				+ magicHolidayReiseAgentur.getBusinessAdresse().getPlz() + " | " + magicHolidayReiseAgentur.getBusinessAdresse().getOrt());
		System.out.println("\n" + "Informationen zu den Kunden");
		
		for (Kunde kunde: magicHolidayReiseAgentur.getKundeArrList()) {
			try {
				System.out.println(kunde.getKundenNr() + " | " + kunde.getAnrede() + " | " + kunde.getVornamen() + " | " + kunde.getNachnamen() + " | "
						+ kunde.getGeburtsDatum() + " | " + kunde.getEmailAdresse() + " | " + kunde.getTelefonNr() + " | " + kunde.getPrivateAdresse().getStra�e() +" | "
						+ kunde.getPrivateAdresse().getHausNr() + " | " + kunde.getPrivateAdresse().getPlz() + " | " + kunde.getPrivateAdresse().getOrt() + " | "
						+ kunde.getBezahlMethode().getBezeichnung() + " | " + kunde.getBezahlMethode().getBeschreibung());
				
				System.out.println("Gesch�ftsadresse: " + kunde.getBusinessAdresse().getStra�e() +" | "
						+ kunde.getBusinessAdresse().getHausNr() + " | " + kunde.getBusinessAdresse().getPlz() + " | " + kunde.getBusinessAdresse().getOrt());
				System.out.println("\n");
				
			} catch (Exception e) {
				System.out.println("Keine Gesch�ftsadresse vorhanden \n");
				
			}
				
		}
	

	}
	

}
