package klassen;

import java.util.ArrayList;

/***
 * 
 * Die Klasse ReiseAgentur ist Vorrausetzung, dass ein Objekt der Klasse ReiseAgentur angelegt werden kann.
 * Au\u00dferdem f\u00fcgt es die Objekte der Klasse Kunde in eine ArrayList.
 * 
 * 
 * @author                   S0560885 Kaan Kara
 * @eclipseVersion           2019-09 R (4.13.0)
 * @javaVersion              12
 * @runTime                  33
 * @erstellungsDatum         21.10.2019
 * @letzte\u00c4nderungsDatum     17.11.2019
 *	
 */

public class ReiseAgentur {
	
	/***
	 * Als Attribute f\u00fcr die Klasse ReiseAgentur wurde ein String ustIdNr, String name, ein Objekt der Klasse Adresse businessAdresse
	 * und eine ArrayListe kundeArrList die, die Objekte der Klasse Kunde aufnehmen kann, angelegt. 
	 * 
	 * Au\u00dferdem sind die Variablen alle private.
	 * 
	 */
	
	private String ustIdNr;
	private String name;
	private Adresse businessAdresse;
	private ArrayList<Kunde> kundeArrList = new ArrayList<Kunde>();


	/**
	 * Der Konstruktor ben\u00f6tigt die Variablen String ustIdNr, String name und Adresse businessAdresse.
	 * Wenn die Signatur des Konstruktor richtig eingetragen worden ist, wird ein Objekt der Klasse ReiseAgentur angelegt.
	 *  
	 * @param ustIdNr wird ben\u00f6tigt.
	 * @param name wird ben\u00f6tigt.
	 * @param businessAdresse wird ben\u00f6tigt.
	 * @param kunde wird ben\u00f6tigt.
	 */
	public ReiseAgentur(String ustIdNr, String name, Adresse businessAdresse) {
		super();
		this.ustIdNr = ustIdNr;
		this.name = name;
		this.businessAdresse = businessAdresse;

	}
	
	/**
	 * F\u00fcgt Objekte der Klasse Kunde in einer ArrayListe hinzu.
	 * @param kunde - akzeptiert nur Objekte der Klasse Kunde.
	 */
	public void storeKundeToArray(Kunde kunde) {
		this.getKundeArrList().add(kunde);
	}
	
	/**
	 * Gibt die Variable ustIdNr zur\u00fcck.
	 * @return the ustIdNr wird zur\u00fcckgegeben.
	 */
	public String getUstIdNr() {
		return ustIdNr;
	}
	
	/**
	 * Legt die Variable ustIdNr an.
	 * @param ustIdNr wird ben\u00f6tigt.
	 */
	public void setUstIdNr(String ustIdNr) {
		this.ustIdNr = ustIdNr;
	}
	
	/**
	 * Gibt die Variable name zur\u00fcck.
	 * @return name wird zur\u00fcckgegeben.
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * Legt die Variable name an.
	 * @param name wird ben\u00f6tigt.
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * Gibt den Objekt der Klasse Adresse, als Variable businessAdresse zur\u00fcck.
	 * @return businessAdresse wird zur\u00fcckgegeben.
	 */
	public Adresse getBusinessAdresse() {
		return businessAdresse;
	}
	
	/**
	 * Legt den Objekt der Klasse Adresse, als Variable businessAdresse an.
	 * @param businessAdresse wird ben\u00f6tigt.
	 */
	public void setBusinessAdresse(Adresse businessAdresse) {
		this.businessAdresse = businessAdresse;
	}
	
	/**
	 * Gibt eine Liste von Objekten der Klasse Kunde zur\u00fcck.
	 * @return kunde wird zur\u00fcckgegeben.
	 */
	public ArrayList<Kunde> getKundeArrList() {
		return kundeArrList;
	}
	
	/**
	 * Legt die Objekte der Klasse Kunde an.
	 * @param kunde wird ben\u00f6tigt.
	 */
	public void setKundeArrList(ArrayList<Kunde> kunde) {
		this.kundeArrList = kunde;
	}
}
