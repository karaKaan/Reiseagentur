package klassen;


/**
 * Die abstrakte Klasse Reservierung ist Voraussetzung f\u00fcr die, Signatur gleiche, Vererbung.
 *  
 * @author                   S0560885 Kaan Kara
 * @eclipseVersion           2019-09 R (4.13.0)
 * @javaVersion              12
 * @runTime                  33
 * @erstellungsDatum         21.10.2019
 * @letzte\u00c4nderungsDatum     17.11.2019
 *
 */
public abstract class Reservierung {
	private int reservierungsNr;
	private String datum;
	private double summe;
	
	/**
	 * Die Signatur des Konstruktors muss erf\u00fcllt werden, damit ein Objekt der Klasse Adresse entstehen kann.
	 * Daf\u00fcr m\u00fcssen die Parameter(siehe unten) vollst\u00e4ndig ausgef\u00fcllt werden.
	 * 
	 * @param reservierungsNr wird ben\u00f6tigt.
	 * @param datum wird ben\u00f6tigt.
	 * @param summe wird ben\u00f6tigt.
	 */
	public Reservierung(int reservierungsNr, String datum, double summe) {
		super();
		this.reservierungsNr = reservierungsNr;
		this.datum = datum;
		this.summe = summe;
	}
	

	/**
	 * Gibt die Variable reservierungsNr zur\u00fcck.
	 * @return reservierungsNr wird zur\u00fcckgegeben.
	 */
	public int getReservierungsNr() {
		return reservierungsNr;
	}

	/**
	 * Legt die Variable reservierungsNr an.
	 * @param reservierungsNr wird ben\u00f6tigt.
	 */
	public void setReservierungsNr(int reservierungsNr) {
		this.reservierungsNr = reservierungsNr;
	}

	/**
	 * Gibt die Variable datum zur\u00fcck.
	 * @return datum wird zur\u00fcckgegeben.
	 */
	public String getDatum() {
		return datum;
	}

	/**
	 * Legt die Variable datum an.
	 * @param datum wird ben\u00f6tigt.
	 */
	public void setDatum(String datum) {
		this.datum = datum;
	}

	/**
	 * Gibt die Variable summe zur\u00fcck.
	 * @return the summe wird zur\u00fcckgegeben.
	 */
	public double getSumme() {
		return summe;
	}

	/**
	 * Legt die Variable summe an.
	 * @param summe wird ben\u00f6tigt.
	 */
	public void setSumme(double summe) {
		this.summe = summe;
	}
}
