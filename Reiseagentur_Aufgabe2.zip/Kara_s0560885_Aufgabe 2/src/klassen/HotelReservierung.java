package klassen;

/**
 * Die Klasse HotelReservierung erbt von der abstrakten Klasse Reservierung.
 * Durch diese Klasse, kann man ein Objekt der Klasse HotelReservierung erstellen.
 * 
 * @author                   S0560885 Kaan Kara
 * @eclipseVersion           2019-09 R (4.13.0)
 * @javaVersion              12
 * @runTime                  33
 * @erstellungsDatum         21.10.2019
 * @letzte\u00c4nderungsDatum     17.11.2019
 */
public class HotelReservierung extends Reservierung {
	String hotelName;
	String reiseDauer;
	
	/**
	 * Die Signatur des Konstruktors muss erf\u00fcllt werden, damit ein Objekt der Klasse Adresse entstehen kann.
	 * Daf\u00fcr m\u00fcssen die Parameter(siehe unten) vollst\u00e4ndig ausgef\u00fcllt werden.
	 * 
	 * @param reservierungsNr wird ben\u00f6tigt.
	 * @param datum wird ben\u00f6tigt.
	 * @param summe wird ben\u00f6tigt.
	 * @param hotelName wird ben\u00f6tigt.
	 * @param reiseDauer wird ben\u00f6tigt.
	 */
	public HotelReservierung(int reservierungsNr, String datum, double summe, String hotelName, String reiseDauer) {
		super(reservierungsNr, datum, summe);
		this.hotelName = hotelName;
		this.reiseDauer = reiseDauer;
	}
	
	/**
	 * Gibt die Variable hotelName zur\u00fcck.
	 * @return hotelName wird zur\u00fcckgegeben.
	 */
	public String getHotelName() {
		return hotelName;
	}
	
	/**
	 * Legt die Variable hotelName an.
	 * @param hotelName wird ben\u00f6tigt.
	 */
	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}
	
	/**
	 * Gibt die Variable reiseDauer zur\u00fcck.
	 * @return reiseDauer wird zur\u00fcckgegeben.
	 */
	public String getReiseDauer() {
		return reiseDauer;
	}
	
	/**
	 * Legt die Variable reiseDauer an.
	 * @param reiseDauer wird ben\u00f6tigt.
	 */
	public void setReiseDauer(String reiseDauer) {
		this.reiseDauer = reiseDauer;
	}	
}
