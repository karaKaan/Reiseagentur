package klassen;

import java.util.ArrayList;

/***
 * Die abstrakte Klasse Kunde ist Voraussetzung f\u00fcr die, Signatur gleiche, Vererbung.
 * 
 * @author                   S0560885 Kaan Kara
 * @eclipseVersion           2019-09 R (4.13.0)
 * @javaVersion              12
 * @runTime                  33
 * @erstellungsDatum         21.10.2019
 * @letzte\u00c4nderungsDatum     17.11.2019
 * 
 */

public abstract class Kunde {
	
	/**
	 * Die Klasse Kunde hat die Variablen int kundenNr, String anrede, String vornamen, String nachnamen, String emailAdresse;
	 * int telefonNr und String geburtsDatum.
	 * Au\u00dferdem werden Objekte der Klassen Adresse in die Variablen privateAdresse und businessAdresse hinzugef\u00fcgt.
	 * Das gleiche passiert auch bei der Klasse BezahlMethode, mit der Variable bezahlMethode.
	 * 
	 * Au\u00dferdem sind die Variablen alle private.
	 * 
	 * 
	 */
	
	private int kundenNr;
	private String anrede;
	private String vorname;
	private String nachname;
	private String vollstaendigerName;
	private String emailAdresse;
	private	String telefonNr;
	private String geburtsDatum;
	private Adresse adresse;
	
	private ArrayList<Reservierung> kundeInReservierungArrList = new ArrayList<Reservierung>();
	
	
	
	/**
	 * 
	 * Die Signatur des Konstruktors muss erf\u00fcllt sein, damit ein Objekt der Klasse Kunde erstellt werden kann.
	 * Daf\u00fcr sind die unten stehenden Parameter n\u00f6tig.
	 * 
	 * @param kundenNr wird ben\u00f6tigt.
	 * @param anrede wird ben\u00f6tigt.
	 * @param vornamen wird ben\u00f6tigt.
	 * @param nachnamen wird ben\u00f6tigt.
	 * @param emailAdresse wird ben\u00f6tigt.
	 * @param telefonNr wird ben\u00f6tigt.
	 * @param geburtsDatum wird ben\u00f6tigt.
	 * @param privateAdresse wird ben\u00f6tigt.
	 * @param businessAdresse wird ben\u00f6tigt.
	 * @param bezahlMethode wird ben\u00f6tigt.
	 */
	public Kunde(int kundenNr, String anrede, String vornamen, String nachnamen, String emailAdresse, String telefonNr,
			String geburtsDatum) {
		super();
		this.kundenNr = kundenNr;
		this.anrede = anrede;
		this.vorname = vornamen;
		this.nachname = nachnamen;
		this.emailAdresse = emailAdresse;
		this.telefonNr = telefonNr;
		this.geburtsDatum = geburtsDatum;
		

	}
	/**
	 * Stellt die abstrakte Klasse getName() und ihre Signatur dar.
	 */
	public abstract void getName();
	/**
	 * F\u00fcgt den Objekt der Klasse BezahlMethode einer ArrayListe oder einer Array hinzu.
	 * @param bezahlMethode - akzeptiert nur Objekte der Klasse BezahlMethode.
	 */
	public abstract void storeBezahlMethodeToArray(BezahlMethode bezahlMethode);
	
	/**
	 * F\u00fcgt Objekte der Klasse Reservierung einer ArrayListe hinzu
	 * @param reservierung - akzeptiert nur Objekte der Klasse Reservierung.
	 */
	public void storeKundeMitReservierungToArray(Reservierung reservierung) {
		this.getKundeInReservierungArrList().add(reservierung);
	}
	
	/**
	 * Gibt die Variable kundenNr zur\u00fcck.
	 * @return kundenNr wird zur\u00fcckgegeben.
	 */
	public int getKundenNr() {
		return kundenNr;
	}
	
	/**
	 * Legt die Variable kundenNr an.
	 * @param kundenNr wird ben\u00f6tigt.
	 */
	public void setKundenNr(int kundenNr) {
		this.kundenNr = kundenNr;
	}
	
	/**
	 * Gibt die Variable anrede zur\u00fcck.
	 * @return anrede wird zur\u00fcckgegeben.
	 */
	public String getAnrede() {
		return anrede;
	}
	
	/**
	 * Legt die Variable anrede an.
	 * @param anrede wird ben\u00f6tigt.
	 */
	public void setAnrede(String anrede) {
		this.anrede = anrede;
	}
	
	/**
	 * Gibt die Variable vornamen zur\u00fcck.
	 * @return vornamen wird zur\u00fcckgegeben.
	 */
	public String getVorname() {
		return vorname;
	}
	
	/**
	 * Legt die Variable vornamen an.
	 * @param vornamen wird ben\u00f6tigt.
	 */
	public void setVorname(String vornamen) {
		this.vorname = vornamen;
	}
	
	/**
	 * Gibt die Variable nachnamen zur\u00fcck.
	 * @return nachnamen wird zur\u00fcckgegeben.
	 */
	public String getNachname() {
		return nachname;
	}
	
	/**
	 * Legt die Variable nachnamen an.
	 * @param nachnamen wird ben\u00f6tigt.
	 */
	public void setNachname(String nachnamen) {
		this.nachname = nachnamen;
	}
	
	/**
	 * Gibt die Variable emailAdresse zur\u00fcck.
	 * @return emailAdresse wird zur\u00fcckgegeben.
	 */
	public String getEmailAdresse() {
		return emailAdresse;
	}
	
	/**
	 * Legt die Variable emailAdresse an.
	 * @param emailAdresse wird ben\u00f6tigt.
	 */
	public void setEmailAdresse(String emailAdresse) {
		this.emailAdresse = emailAdresse;
	}
	
	/**
	 * Gibt die Variable telefonNr zur\u00fcck.
	 * @return telefonNr wird zur\u00fcckgegeben.
	 */
	public String getTelefonNr() {
		return telefonNr;
	}
	
	/**
	 * Legt die Variable telefonNr an.
	 * @param telefonNr wird ben\u00f6tigt.
	 */
	public void setTelefonNr(String telefonNr) {
		this.telefonNr = telefonNr;
	}
	
	/**
	 * Gibt die Variable geburtsDatum zur\u00fcck.
	 * @return geburtsDatum wird zur\u00fcckgegeben.
	 */
	public String getGeburtsDatum() {
		return geburtsDatum;
	}
	
	/**
	 * Legt die Variable geburtsDatum an.
	 * @param geburtsDatum wird ben\u00f6tigt.
	 */
	public void setGeburtsDatum(String geburtsDatum) {
		this.geburtsDatum = geburtsDatum;
	}
	
	/**
	 * Gibt den Objekt der Klasse Adresse, als Variable privateAdresse zur\u00fcck.
	 * @return privateAdresse wird zur\u00fcckgegeben.
	 */
	public Adresse getAdresse() {
		return adresse;
	}
	
	/**
	 * Legt den Objekt der Klasse Adresse, als Variable privateAdresse an.
	 * @param privateAdresse wird ben\u00f6tigt.
	 */
	public void setAdresse(Adresse adresse) {
		this.adresse = adresse;
	}
	
	/**
	 *  Gibt den Wert der Variable vollstaendigerName zur\u00fcck.
	 * @return vollstaendigerName wird zur\u00fcckgegeben.
	 */
	public String getVollstaendigerName() {
		return vollstaendigerName;
	}
	
	/**
	 * Legt die Variable vollstaendigerName an.
	 * @param vollstaendigerName wird ben\u00f6tigt.
	 */
	public void setVollstaendigerName(String vollstaendigerName) {
		this.vollstaendigerName = vollstaendigerName;
	}

	/**
	 * Gibt die ArrayListe kundeInReservierungArrList, der Objekte der Klasse Reservierung akzeptiert, wieder.
	 * @return kundeInReservierungArrList wird zur\u00fcckgegeben.
	 */
	public ArrayList<Reservierung> getKundeInReservierungArrList() {
		return kundeInReservierungArrList;
	}

	/**
	 * Legt die ArrayListe kundeInReservierungArrList, der Objekte der Klasse Reservierung akzeptiert, an.
	 * @param kundeInReservierungArrList wird ben\u00f6tigt.
	 */
	public void setKundeInReservierungArrList(ArrayList<Reservierung> kundeInReservierungArrList) {
		this.kundeInReservierungArrList = kundeInReservierungArrList;
	}
}
