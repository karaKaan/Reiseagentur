package klassen;

/**
 * Die Klasse FlugReservierung erbt von der abstrakten Klasse Reservierung.
 * Durch diese Klasse, kann man ein Objekt der Klasse FlugReservierung erstellen.
 * 
 * @author                   S0560885 Kaan Kara
 * @eclipseVersion           2019-09 R (4.13.0)
 * @javaVersion              12
 * @runTime                  33
 * @erstellungsDatum         21.10.2019
 * @letzte\u00c4nderungsDatum     17.11.2019
 */
public class FlugReservierung extends Reservierung {
	int flugNr;
	String abFlugHafen;
	String zielFlugHafen;
	/**
	 * Die Signatur des Konstruktors muss erf\u00fcllt werden, damit ein Objekt der Klasse Adresse entstehen kann.
	 * Daf\u00fcr m\u00fcssen die Parameter(siehe unten) vollst\u00e4ndig ausgef\u00fcllt werden.
	 * 
	 * @param reservierungsNr wird ben\u00f6tigt.
	 * @param datum wird ben\u00f6tigt.
	 * @param summe wird ben\u00f6tigt.
	 * @param flugNr wird ben\u00f6tigt. 
	 * @param abFlugHafen wird ben\u00f6tigt.
	 * @param zielFlugHafen wird ben\u00f6tigt.
	 */
	public FlugReservierung(int reservierungsNr, String datum, double summe, int flugNr, String abFlugHafen,
			String zielFlugHafen) {
		super(reservierungsNr, datum, summe);
		this.flugNr = flugNr;
		this.abFlugHafen = abFlugHafen;
		this.zielFlugHafen = zielFlugHafen;
	}

	/**
	 * Gibt die Variable flugNr zur\u00fcck.
	 * @return flugNr wird zur\u00fcckgegeben.
	 */
	public int getFlugNr() {
		return flugNr;
	}
	/**
	 * Legt die Variable flugNr an.
	 * @param flugNr wird ben\u00f6tigt.
	 */
	public void setFlugNr(int flugNr) {
		this.flugNr = flugNr;
	}
	/**
	 * Gibt die Variable abFlugHafen zur\u00fcck.
	 * @return abFlugHafen wird zur\u00fcckgegeben.
	 */
	public String getAbFlugHafen() {
		return abFlugHafen;
	}
	/**
	 * Legt die Variable abFlugHafen an.
	 * @param abFlugHafen wird ben\u00f6tigt.
	 */
	public void setAbFlugHafen(String abFlugHafen) {
		this.abFlugHafen = abFlugHafen;
	}
	/**
	 * Gibt die Variable zielFlugHafen zur\u00fcck.
	 * @return zielFlugHafen wird zur\u00fcckgegeben.
	 */
	public String getZielFlugHafen() {
		return zielFlugHafen;
	}
	/**
	 * Legt die Variable zielFlugHafen an.
	 * @param zielFlugHafen wird ben\u00f6tigt.
	 */
	public void setZielFlugHafen(String zielFlugHafen) {
		this.zielFlugHafen = zielFlugHafen;
	}	
}
