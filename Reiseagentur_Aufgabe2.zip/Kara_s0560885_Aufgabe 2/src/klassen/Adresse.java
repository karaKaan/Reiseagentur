package klassen;

import java.util.Scanner;

/***
 * 
 * Die Klasse Adresse ist Vorrausetzung, dass ein Objekt der Klasse Adresse angelegt werden kann.
 * 
 * @author                   S0560885 Kaan Kara
 * @eclipseVersion           2019-09 R (4.13.0)
 * @javaVersion              12
 * @runTime                  33
 * @erstellungsDatum         21.10.2019
 * @letzte\u00c4nderungsDatum     17.11.2019
 * 
 */

public class Adresse {
	
	/**
	 * Die Klasse Adresse hat die Variablen String stra\u00dfe, String hausNr, int plz und String ort.
	 * Die Variablen sind alle private.
	 */
	Scanner scanner = new Scanner(System.in);
	private String stra\u00dfe;
	private String hausNr;
	private int plz;
	private String ort;
	
	
	/**
	 * Die Signatur des Konstruktors muss erf\u00fcllt werden, damit ein Objekt der Klasse Adresse entstehen kann.
	 * Daf\u00fcr m\u00fcssen die Parameter(siehe unten) vollst\u00e4ndig ausgef\u00fcllt werden.
	 * 
	 * @param stra\u00dfe wird ben\u00f6tigt.
	 * @param hausNr wird ben\u00f6tigt.
	 * @param plz wird ben\u00f6tigt.
	 * @param ort wird ben\u00f6tigt.
	 */
	public Adresse(String stra\u00dfe, String hausNr, int plz, String ort) {
		super();
		this.stra\u00dfe = stra\u00dfe;
		this.hausNr = hausNr;
		this.plz = plz;
		this.ort = ort;
	}
	
	
	/**
	 * Gibt die Variable stra\u00dfe zur\u00fcck.
	 * @return stra\u00dfe wird zur\u00fcckgegeben.
	 */
	public String getStra\u00dfe() {
		return stra\u00dfe;
	}
	
	/**
	 * Legt die Variable stra\u00dfe an.
	 * @param stra\u00dfe wird ben\u00f6tigt.
	 */
	public void setStra\u00dfe(String stra\u00dfe) {
		this.stra\u00dfe = stra\u00dfe;
	}
	
	/**
	 * Gibt die Variable hausNr zur\u00fcck.
	 * @return hausNr wird zur\u00fcckgegeben.
	 */
	public String getHausNr() {
		return hausNr;
	}
	
	/**
	 * Legt die Variable hausNr an.
	 * @param hausNr wird ben\u00f6tigt.
	 */
	public void setHausNr(String hausNr) {
		this.hausNr = hausNr;
	}
	
	/**
	 * Gibt die Variable plz zur\u00fcck.
	 * @return plz wird zur\u00fcckgegeben.
	 */
	public int getPlz() {
		return plz;
	}
	
	/**
	 * Legt die Variable plz an.
	 * @param plz wird ben\u00f6tigt.
	 */
	public void setPlz(int plz) {
		this.plz = plz;
	}
	
	/**
	 * Gibt die Variable ort zur\u00fcck.
	 * @return ort wird zur\u00fcckgegeben.
	 */
	public String getOrt() {
		return ort;
	}
	
	/**
	 * Legt die Variable ort an.
	 * @param ort wird ben\u00f6tigt.
	 */
	public void setOrt(String ort) {
		this.ort = ort;
	}
}
