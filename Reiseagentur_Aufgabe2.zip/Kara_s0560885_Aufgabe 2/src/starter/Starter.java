package starter;
import java.util.InputMismatchException;
import java.util.Scanner;

import klassen.Adresse;
import klassen.BezahlMethode;
import klassen.FlugReservierung;
import klassen.GeschaeftsKunde;
import klassen.HotelReservierung;
import klassen.Kunde;
import klassen.PrivatKunde;
import klassen.ReiseAgentur;
import klassen.Reservierung;

/***
 *
 * Die Starter-Klasse legt die Objekte der jeweiligen Klassen an
 * und gibt die Informationen auf der Konsole wieder.
 * 
 * @author                   S0560885 Kaan Kara
 * @eclipseVersion           2019-09 R (4.13.0)
 * @javaVersion              12
 * @runTime                  33
 * @erstellungsDatum         21.10.2019
 * @letzte\u00c4nderungsDatum     17.11.2019
 * 
 */

public class Starter {
	
	/**
	 * In der main-Methode wird die Methode "erzeugeReiseAgentur()" aufgerufen,
	 * dadurch wird ein Objekt der Klasse ReiseAgentur erzeugt.
	 * Es ist au\u00dferhalb der while-Schleife, da wir nur ein Objekt der Klasse ReiseAgentur ben\u00f6tigen.
	 * Die While-Schleife ist immer "true" und es werden die Methoden zeigeMenueOberflaeche(), 
	 * nimmZahlVonMitarbeiter() und  fuehreWahlAus() aufgerufen.
	 * 
	 * Die Konsole zeigt zun\u00e4chst die Men\u00fcoberfl\u00e4che und der Benutzer kann dann eine Zahl eingeben.
	 * Diese Zahl wird dann in der Variable "wahlVonMitarbeiter" initialisiert.
	 * Diese Variable wird dann an die Methode "fuehreWahlAus()" als Parameter weitergegeben,
	 * au\u00dferdem das Objekt "magicHolidaysReiseAgentur" wird ebenso als Parameter weitergegeben.
	 * 
	 * @param args wird ben\u00f6tigt.
	 * 
	 */
	public static void main(String[] args) {
		ReiseAgentur magicHolidaysReiseAgentur = new Starter().erzeugeReiseAgentur();
		new Starter().erzeugeDreiPrivatKunde(magicHolidaysReiseAgentur);
		new Starter().erzeugeDreiGeschaeftsKunde(magicHolidaysReiseAgentur);
			while(true) {
				new Starter().zeigeMenueOberflaeche();
				int wahlVonMitarbeiter = new Starter().nimmZahlVonMitarbeiter();
				new Starter().fuehreWahlAus(wahlVonMitarbeiter,magicHolidaysReiseAgentur);
			}
	}
	
	/**
	 * Die Methode erzeugeReiseAgentur() soll ein Objekt der Klasse ReiseAgentur erzeugen.
	 * @return magicHolidaysReiseAgentur wird zur\u00fcckgegeben.
	 */
	public ReiseAgentur erzeugeReiseAgentur() {
		ReiseAgentur magicHolidaysReiseAgentur = new ReiseAgentur("DE812524001", "Magic Holidays Reiseagentur", 
				new Adresse("Hauptstra\u00dfe", "5a", 10559, "Berlin"));
		return magicHolidaysReiseAgentur;
	}
	
	/**
	 * Erzeugt schon im Vorfeld 3 unterschiedliche Objekte der Klasse PrivatKunden.
	 * @param magicHolidaysReiseAgentur - nimmt das Objekt der Klasse ReiseAgentur, um auf Methoden dieser Klasse zur\u00fcck zugreifen.
	 */
	public void erzeugeDreiPrivatKunde(ReiseAgentur magicHolidaysReiseAgentur) {
		Kunde privatKundeMax = new PrivatKunde(1,"Herr","Max","Mustermann","max.muster@gmail.com","55442211","01.05.1970");
		privatKundeMax.getName();
		privatKundeMax.setAdresse(new Adresse("Hauptstra\u00dfe","32a",54110,"Frankurt"));
		if(privatKundeMax instanceof PrivatKunde) {
			BezahlMethode bezahlMethodePayPal = new BezahlMethode("Paypal", "max.muster@gmail.com");
			((PrivatKunde) privatKundeMax).storeBezahlMethodeToArray(bezahlMethodePayPal);
		}
		Reservierung maxFlugReservierung = new FlugReservierung(1, "27.11.2019", 320.99, 1, "Berlin Tegel", "Moscow Airport");
		privatKundeMax.storeKundeMitReservierungToArray(maxFlugReservierung);
		
		magicHolidaysReiseAgentur.storeKundeToArray(privatKundeMax);
		
		Kunde privatKundeMaria = new PrivatKunde(2, "Frau", "Maria", "Musterfrau", "maria.muster@gmail.com", "99874114","27.08.1980");
		privatKundeMaria.getName();
		privatKundeMaria.setAdresse(new Adresse("Richardstra\u00dfe", "12b", 13241, "Berlin"));
		if(privatKundeMaria instanceof PrivatKunde) {
			((PrivatKunde) privatKundeMaria).setBezahlMethodeF\u00fcrPrivatKunde(new BezahlMethode("Klarna", "maria.muster@gmail.com"));
			BezahlMethode bezahlMethodePayPal = new BezahlMethode("Paypal", "maria.muster@gmail.com");
			BezahlMethode bezahlMethodeKlarna = new BezahlMethode("Klarna", "maria.muster@gmail.com");
			((PrivatKunde) privatKundeMaria).storeBezahlMethodeToArray(bezahlMethodePayPal);
			((PrivatKunde) privatKundeMaria).storeBezahlMethodeToArray(bezahlMethodeKlarna);
		}
		Reservierung mariaFlugReservierung = new FlugReservierung(2, "27.11.2019", 320.99, 1, "Berlin Tegel", "Moscow Airport");
		Reservierung mariaHotelReservierung = new HotelReservierung(2, "28.11.2019", 2500, "Moscow Grand Palace", "14 Tage");
		privatKundeMaria.storeKundeMitReservierungToArray(mariaFlugReservierung);
		privatKundeMaria.storeKundeMitReservierungToArray(mariaHotelReservierung);
		
		magicHolidaysReiseAgentur.storeKundeToArray(privatKundeMaria);
		
		Kunde privatKundeJohn = new PrivatKunde(3,"Herr","John","Heinrich","john1985@gmail.com","45698174", "30.11.1990");
		privatKundeJohn.getName();
		privatKundeJohn.setAdresse(new Adresse("Musterstra\u00dfe", "01", 33212, "Dortmund"));
		if(privatKundeJohn instanceof PrivatKunde) {
			BezahlMethode bezahlMethodePayPal = new BezahlMethode("Paypal", "john1985@gmail.com");
			BezahlMethode bezahlMethodeKlarna = new BezahlMethode("Klarna", "john1985@gmail.com");
			BezahlMethode bezahlMethodeSofort = new BezahlMethode("Sofort\u00fcberweisung", "john1985@gmail.com");
			((PrivatKunde) privatKundeJohn).storeBezahlMethodeToArray(bezahlMethodePayPal);
			((PrivatKunde) privatKundeJohn).storeBezahlMethodeToArray(bezahlMethodeKlarna);
			((PrivatKunde) privatKundeJohn).storeBezahlMethodeToArray(bezahlMethodeSofort);
		}
		Reservierung johnFlugReservierung = new FlugReservierung(3, "01.01.2020", 510.99, 2, "Berlin Tegel", "New York Airport");
		Reservierung johnR\u00fcckFlugReservierung = new FlugReservierung(3, "22.01.2020" ,510.99, 3, "New York Airport", "Berlin Tegel");
		Reservierung johnHotelReservierung = new HotelReservierung(3, "02.01.2020", 3500.47, "NY-LuxusHotel", "21 Tage");
		privatKundeJohn.storeKundeMitReservierungToArray(johnFlugReservierung);
		privatKundeJohn.storeKundeMitReservierungToArray(johnR\u00fcckFlugReservierung);
		privatKundeJohn.storeKundeMitReservierungToArray(johnHotelReservierung);
		
		magicHolidaysReiseAgentur.storeKundeToArray(privatKundeJohn);
	}
	
	
	/**
	  * Erzeugt schon im Vorfeld 3 unterschiedliche Objekte der Klasse GeschaeftsKunden.
	 * @param magicHolidaysReiseAgentur - nimmt das Objekt der Klasse ReiseAgentur, um auf Methoden dieser Klasse zur\u00fcck zugreifen.
	 */
	public void erzeugeDreiGeschaeftsKunde(ReiseAgentur magicHolidaysReiseAgentur) {
		Kunde geschaeftsKundeTom = new GeschaeftsKunde(4, "Herr", "Tom", "Jeffrey", "tom.jeff@webmail.com", "55598371", "17.08.1990", "Tom & Jerry Group");
		geschaeftsKundeTom.getName();
		geschaeftsKundeTom.setAdresse(new Adresse("Hauptstra\u00dfe", "15", 12332, "Berlin"));
		if(geschaeftsKundeTom instanceof GeschaeftsKunde) {
			BezahlMethode bezahlMethode = new BezahlMethode("Rechnung", "E-Mail");
			((GeschaeftsKunde) geschaeftsKundeTom).storeBezahlMethodeToArray(bezahlMethode);
		}
		Reservierung tomFlugReservierung = new FlugReservierung(1, "21.02.2020", 350, 1, "Berlin Sch\u00f6nefeld", "Swizz Airport");
		geschaeftsKundeTom.storeKundeMitReservierungToArray(tomFlugReservierung);
		magicHolidaysReiseAgentur.storeKundeToArray(geschaeftsKundeTom);
		
		Kunde geschaeftsKundeMatthias = new GeschaeftsKunde(5, "Herr", "Matthias", "Schweigh\u00f6fer", "m.schweigh\u00f6fer@gmail.com", "95174824", "31.01.1988", "Umbrella Corp.");
		geschaeftsKundeMatthias.getName();
		geschaeftsKundeMatthias.setAdresse(new Adresse("Moritzstra\u00dfe", "10b", 33221, "Stuttgart"));
		if(geschaeftsKundeMatthias instanceof GeschaeftsKunde) {
			BezahlMethode bezahlMethode = new BezahlMethode("Rechnung", "E-Mail");
			((GeschaeftsKunde) geschaeftsKundeMatthias).storeBezahlMethodeToArray(bezahlMethode);
		}
		Reservierung matthiasFlugReservierung = new FlugReservierung(2, "01.03.2020", 150, 2, "Stuttgart Airport", "Paris Airport");
		Reservierung matthiasHotelReservierung = new HotelReservierung(2,"01.03.2020",1500.49, "Paris GrandPalace", "7 Tage");
		geschaeftsKundeMatthias.storeKundeMitReservierungToArray(matthiasFlugReservierung);
		geschaeftsKundeMatthias.storeKundeMitReservierungToArray(matthiasHotelReservierung);
		magicHolidaysReiseAgentur.storeKundeToArray(geschaeftsKundeMatthias);
		
		Kunde geschaeftsKundeBrigitte = new GeschaeftsKunde(6, "Frau", "Brigitte", "M\u00fcller", "Briggym\u00fcller@hotmail.com", "32112399", "25.05.1970", "Designer GmbH");
		geschaeftsKundeBrigitte.getName();
		geschaeftsKundeBrigitte.setAdresse(new Adresse("Hauptstra\u00dfe", "19b", 40432, "Hamburg"));
		if(geschaeftsKundeBrigitte instanceof GeschaeftsKunde) {
			BezahlMethode bezahlMethode = new BezahlMethode("Rechnung", "Post");
			((GeschaeftsKunde) geschaeftsKundeBrigitte).storeBezahlMethodeToArray(bezahlMethode);
		}
		Reservierung brigitteFlugReservierung = new FlugReservierung(3, "09.03.2020", 210, 3, "Hamburg Airport", "Malediven Airport");
		Reservierung brigitteR\u00fcckFlugReservierung = new FlugReservierung(3, "30.03.2020", 210, 4, "Malediven Airport", "Hamburg Airport");
		Reservierung brigitteHotelReservierung = new HotelReservierung(3, "10.03.2020",3499.99, "Male Palace", "21-Tage");
		geschaeftsKundeBrigitte.storeKundeMitReservierungToArray(brigitteFlugReservierung);
		geschaeftsKundeBrigitte.storeKundeMitReservierungToArray(brigitteR\u00fcckFlugReservierung);
		geschaeftsKundeBrigitte.storeKundeMitReservierungToArray(brigitteHotelReservierung);
		magicHolidaysReiseAgentur.storeKundeToArray(geschaeftsKundeBrigitte);
	
	}
	
	/**
	 * Die Methode nimmZahlVonMitarbeiter() erlaubt es den Kunden eine Zahl einzugeben.
	 * Es soll die Variable wahlVonMitarbeiter zur\u00fcckgeben.
	 * @return wahlVonMitarbeiter - gibt die Eingabe des Mitarbeiters wieder.
	 */
	public int nimmZahlVonMitarbeiter() {
		Scanner scanner = new Scanner(System.in);
		
		try {
			System.out.println("\nBitte geben Sie eine Zahl ein, um ein entsprechendes Men\u00fc-Punkt auszuf\u00fchren");
			int wahlVonMitarbeiter = scanner.nextInt();
			
			return wahlVonMitarbeiter;
		} catch(Exception e) {
			System.out.println("Bitte geben Sie eine \"Zahl\" ein.");
		}
		return 0;
	}
	
	/**
	 * Die Methode fuehreWahlAus() nimmt die Parameter "wahlVonMitarbeiter" und "magicHolidaysReiseAgentur".
	 * Es gibt eine Switch-Case-Anweisung und je nach Eingabe (1-7) soll der Benutzer die M\u00f6glichkeit haben,
	 * die entsprechende Methode aufzurufen.
	 * Bei Eingabe von 1 ruft es die Methode "addPrivatKunde(magicHolidaysReiseAgentur)" auf,
	 * bei 2 ruft es die Methode "addGeschaeftsKunde(magicHolidaysReiseAgentur)",
	 * usw.
	 * Wenn eine andere Zahl als min.1 und max.7 eingegeben wurde, wird der default aufgerufen und der
	 * Benutzer wird dar\u00fcber informiert.
	 * 
	 * Das 2.Parameter "magicHolidaysReiseAgentur" wird an die anderen Methoden weitergegeben, um in diesen
	 * Methoden eine Verbindung mit der Klasse ReiseAgentur herzustellen.
	 * 
	 * @param wahlVonMitarbeiter - nimmt die Eingabe des Mitarbeiters.
	 * @param magicHolidaysReiseAgentur - nimmt ein Objekt der Klasse ReiseAgentur.
	 */
	public void fuehreWahlAus (int wahlVonMitarbeiter, ReiseAgentur magicHolidaysReiseAgentur) {
			switch(wahlVonMitarbeiter) {
			case 1: addPrivatKunde(magicHolidaysReiseAgentur);
			break;
			case 2: addGeschaeftsKunde(magicHolidaysReiseAgentur);
			break;
			case 3: addReservierungAndAssignKundenNummer(magicHolidaysReiseAgentur);
			break;
			case 4: kundeMitReservierungAnzeigenWahlDurchKundenNummer(magicHolidaysReiseAgentur);
			break;
			case 5: kundeMitReservierungAnzeigenWahlDurchName(magicHolidaysReiseAgentur);
			break;
			case 6: reservierungAnzeigenWahlDurchReservierungsNummer(magicHolidaysReiseAgentur);;
			break;
			case 7: System.exit(0);
			break;
			default: System.out.println("Bitte geben Sie eine Zahl von 1-7 ein.");
			}
	}
	
	/**
	 * Die Methode zeigeMenueOberflaeche() hat einen Array "menueList" mit 7 Elementen von Typ String, au\u00dferdem
	 * wurden diese Elemente auch gleich initialisiert.
	 * 
	 * Die for-each Schleife soll jedes Element in die Variable String "menuePunkt" initialisieren und auf der Konsole
	 * wiedergeben.  
	 */
	public void zeigeMenueOberflaeche() {
		String[] menueList = {"\n(01) Privatekunde anlegen", "(02) Gesch\u00e4ftskunde anlegen", 
				"(03) Reservierung anlegen und Kundennummer zuordnen", "(04) Kunde mit Reservierung anzeigen (Auswahl durch Kundennummer)",
				"(05) Kunde mit Reservierung anzeigen (Auswahl durch Name)", "(06) Reservierung anzeigen (Auswahl durch Reservierungsnummer)",
				"(07) Beenden"};
		for (String menuePunkt : menueList) {
			System.out.println(menuePunkt);
		}
	}
	
	/**
	 * Die Methode addPrivatKunde() hat einen Parameter, unzwar "magicHolidaysReiseAgentur".
	 * Diese Methode soll von der Oberklasse Kunde, die Unterklasse PrivatKunde mit Hilfe von Polymorphismus, erstellen.
	 * Au\u00dferdem wird die Adresse, mit Hilfe der set-Methode aufgerufen und erstellt.
	 * 
	 * Um die BezahlMethode f\u00fcr diesen PrivatKunden anzulegen, wird ein "if-Statement" mit "instanceof" als Bedingung 
	 * festgelegt. 
	 * Dar\u00fcber wird ein Objekt der Klasse BezahlMethode erstellt und der ArrayListe bezahlMethodeF\u00fcrPrivatKundeArrList() hinzugef\u00fcgt.
	 * Der Benutzer kann nur maximal 3 Bezahlmethoden pro Privatkunde anlegen und das wird \u00fcber einem if-Statement und for-Schleife
	 * geregelt.
	 * 
	 * Das erstellte Objekt der Klasse PrivatKunde, wird in die ArrayListe kundeArrList(), das sich im Objekt "magicHolidaysReiseAgentur" 
	 * befindet, hinzugef\u00fcgt.
	 * 
	 * @param magicHolidaysReiseAgentur - nimmt ein Objekt der Klasse Reiseagentur.
	 */
	public void addPrivatKunde(ReiseAgentur magicHolidaysReiseAgentur) {
		try {
			Scanner scanner = new Scanner(System.in);
			System.out.println("Bitte geben Sie die Kundennummer ein: ");
			int kundenNr = scanner.nextInt();
			scanner.nextLine();
			System.out.println("Bitte geben Sie die Anrede ein: ");
			String anrede = scanner.nextLine(); 
			
			System.out.println("Bitte geben Sie den Vorname ein: ");
			String vorname = scanner.nextLine();
			
			System.out.println("Bitte geben Sie den Nachname ein: ");
			String nachname = scanner.nextLine();
			
			System.out.println("Bitte geben Sie die Email Adresse ein: ");
			String emailAdresse = scanner.nextLine();
			
			System.out.println("Bitte geben Sie die Telefonnummer ein: ");
			String telefonNr = scanner.nextLine();
			
			System.out.println("Bitte geben Sie das Geburtsdatum(dd.mm.yyyy) ein: ");
			String geburtsDatum = scanner.nextLine();
			
			System.out.println("Bitte geben Sie die Stra\u00dfe des Kunden ein: ");
			String strasse = scanner.nextLine();
			
			System.out.println("Bitte geben Sie die Hausnummer des Kunden ein: ");
			String hausNr = scanner.nextLine();
			
			System.out.println("Bitte geben Sie die PLZ des Kunden ein: ");
			int plz = scanner.nextInt();
			scanner.nextLine();
			
			System.out.println("Bitte geben Sie den Ort des Kunden ein: ");
			String ort = scanner.nextLine();
			
			
			Kunde privatKunde = new PrivatKunde(kundenNr, anrede, vorname, nachname, emailAdresse, telefonNr, 
					geburtsDatum);
			privatKunde.setAdresse(new Adresse(strasse,hausNr,plz,ort));
			privatKunde.getName();
			
			if(privatKunde instanceof PrivatKunde) {
				System.out.println("Wieviele Bezahlmethoden (von max.3) wollen Sie f\u00fcr diesen Kunden anlegen? ");
				int anzahlDerBezahlMethoden = scanner.nextInt();
				scanner.nextLine();
				if(anzahlDerBezahlMethoden <= 3) {
					for(int i = 1; i <= anzahlDerBezahlMethoden; i++) {
						System.out.println(i + ". Bezahlmethode");
						System.out.println("Bitte geben Sie eine Bezeichnung der Bezahlmethode des Kunden ein: ");
						String bezeichnung = scanner.nextLine();
						
						System.out.println("Bitte geben Sie eine Beschreibung der Bezahlmethode des Kunden ein: ");
						String beschreibung = scanner.nextLine();

						((PrivatKunde) privatKunde).setBezahlMethodeF\u00fcrPrivatKunde(new BezahlMethode(bezeichnung,beschreibung));		
						privatKunde.storeBezahlMethodeToArray(((PrivatKunde) privatKunde).getBezahlMethodeF\u00fcrPrivatKunde());
					}
				}else {
					System.out.println("\nLeider ist die Zahl \"" + anzahlDerBezahlMethoden + "\" zu hoch." );
					System.out.println("Sie k\u00f6nnen leider nur maximal 3 Bezahlmethode anlegen.");
					System.out.println("Versuchen Sie es erneut!\n");
					addPrivatKunde(magicHolidaysReiseAgentur);
				}
			}
			
			magicHolidaysReiseAgentur.storeKundeToArray(privatKunde);
			System.out.println("Privatkunde mit der Kundennummer \"" + privatKunde.getKundenNr() + "\" und dem Nachnamen \"" 
			+ privatKunde.getNachname() + "\" wurde erfolgreich angelegt!");	
			
		}catch(InputMismatchException e) {
			System.out.println("\nBitte geben Sie eine \"Zahl\" ein.");
			System.out.println("Bitte versuchen Sie es erneut.\n");
			addPrivatKunde(magicHolidaysReiseAgentur);
		}catch(Exception e) {
			System.out.println("\nEs tut uns leid.");
			System.out.println("Ein unerwarteter Fehler ist aufgetreten.");
			System.out.println("Beim wieder auftreten des Problems, bitten wir Sie uns zu kontaktieren, "
					+ "damit wir schnellsm\u00f6glich dieses Problem beheben k\u00f6nnen.");
			System.out.println("Bitte versuchen Sie es erneut.\n");
		}	
	}
	
	/**
	 * Die Methode hat einen Parameter "magicHolidaysReiseAgentur". Dadurch wird am Ende gew\u00e4hrleistet, dass das erstellte Objekt,
	 * der Klasse GeschaeftsKunde, der ArrayListe "kundeArrList()" hinzugef\u00fcgt wird.
	 * Diese Methode erstellt von der Oberklasse Kunde, die Unterklasse GeschaeftsKunde durch Polymorphismus.
	 * Au\u00dferdem werden Objekte von der Klasse Adresse und BezahlMethoden erstellt.
	 * 
	 * Die BezahlMethode wird dann dem Array bezahlMethodeF\u00fcrGeschaeftsKundeList() hinzugef\u00fcgt, au\u00dferdem
	 * gibt es keine Restriktion, da die Gesch\u00e4ftskunden nur eine Bezahlmethode haben.
	 * 
	 * 
	 * @param magicHolidaysReiseAgentur - nimmt ein Objekt der Klasse Reiseagentur .
	 */
	public void addGeschaeftsKunde(ReiseAgentur magicHolidaysReiseAgentur) {
		try {
			Scanner scanner = new Scanner(System.in);
			System.out.println("Bitte geben Sie die Kundennummer ein: ");
			int kundenNr = scanner.nextInt();
			
			scanner.nextLine();
			System.out.println("Bitte geben Sie die Anrede ein: ");
			String anrede = scanner.nextLine(); 
			
			System.out.println("Bitte geben Sie den Vorname ein: ");
			String vorname = scanner.nextLine();
			
			System.out.println("Bitte geben Sie den Nachname ein: ");
			String nachname = scanner.nextLine();
			
			System.out.println("Bitte geben Sie die Email Adresse ein: ");
			String emailAdresse = scanner.nextLine();
			
			System.out.println("Bitte geben Sie die Telefonnummer ein: ");
			String telefonNr = scanner.nextLine();
			
			System.out.println("Bitte geben Sie das Geburtsdatum(dd.mm.yyyy) ein: ");
			String geburtsDatum = scanner.nextLine();
			
			System.out.println("Bitte geben Sie den Namen Ihrer Firma ein: ");
			String firmenName = scanner.nextLine();
			
			System.out.println("Bitte geben Sie die Stra\u00dfe des Kunden ein: ");
			String strasse = scanner.nextLine();
			
			System.out.println("Bitte geben Sie die Hausnummer des Kunden ein: ");
			String hausNr = scanner.nextLine();
			
			System.out.println("Bitte geben Sie die PLZ des Kunden ein: ");
			int plz = scanner.nextInt();
			scanner.nextLine();
			
			System.out.println("Bitte geben Sie den Ort des Kunden ein: ");
			String ort = scanner.nextLine();
			
			
			
			Kunde geschaeftsKunde = new GeschaeftsKunde(kundenNr, anrede, vorname, nachname, emailAdresse, telefonNr, 
					geburtsDatum, firmenName);
			geschaeftsKunde.setAdresse(new Adresse(strasse,hausNr,plz,ort));
			geschaeftsKunde.getName();
		if(geschaeftsKunde instanceof GeschaeftsKunde) {
			System.out.println("Bitte geben Sie die Beschreibung der Bezahlmethode des Kunden ein: ");
			String beschreibung = scanner.nextLine();
			
			((GeschaeftsKunde) geschaeftsKunde).setBezahlMethodeF\u00fcrGeschaeftsKunde(new BezahlMethode("Rechnung",beschreibung));
			geschaeftsKunde.storeBezahlMethodeToArray(((GeschaeftsKunde) geschaeftsKunde).getBezahlMethodeF\u00fcrGeschaeftsKunde());
			
		} 
			magicHolidaysReiseAgentur.storeKundeToArray(geschaeftsKunde);
			System.out.println("Gesch\u00e4ftskunde mit der Kundennummer: \"" + geschaeftsKunde.getKundenNr() + "\" und dem Nachnamen \"" 
			+ geschaeftsKunde.getNachname() + "\" wurde erfolgreich angelegt!");
			
		}catch(InputMismatchException e) {
			System.out.println("\nBitte geben Sie eine \"Zahl\" ein.");
			System.out.println("Bitte versuchen Sie es erneut.\n");
			addGeschaeftsKunde(magicHolidaysReiseAgentur);
		}catch(Exception e) {
			System.out.println("\nEs tut uns leid.");
			System.out.println("Ein unerwarteter Fehler ist aufgetreten.");
			System.out.println("Beim wieder auftreten des Problems, bitten wir Sie uns zu kontaktieren, "
					+ "damit wir schnellsm\u00f6glich dieses Problem beheben k\u00f6nnen.");
			System.out.println("Bitte versuchen Sie es erneut.\n");
		}
	}
	
	/**
	 * Die Methode addReservierungAndAssignKundenNummer() soll von der Oberklasse Reservierung, entweder die
	 * Unterklasse Flugreservierung oder die Unterklasse Hotelreservierung (mittels Polymorphismus) anlegen.
	 * Diese Entscheidung erfolgt \u00fcber den Benutzer, der entweder mit einem "f" oder einem "h", das jeweilige Verfahren 
	 * aussuchen kann.
	 * Durch den if-Statement wird das ausgesuchte Verfahren auch angewendet.
	 * 
	 * Diese Methode pr\u00fcft zun\u00e4chst, ob Objekte von der Oberklasse Kunde in der ArrayListe kundeArrList() existieren, wenn nicht wird der 
	 * Benutzer informiert.
	 * Au\u00dferdem wird gepr\u00fcft, ob die eingegebene Kundennummer in der ArrayListe existert. Dadurch wird die Zuordnung gew\u00e4hrleistet. 
	 * 
	 * Des Weiteren wird das erstellte Objekt der ArrayListe kundeInReservierungArrList(), das sich in der Klasse Kunde befindet, hinzugef\u00fcgt.
	 * 
	 * 
	 * @param magicHolidaysReiseAgentur - nimmt ein Objekt der Klasse Reiseagentur.
	 */
	public void addReservierungAndAssignKundenNummer(ReiseAgentur magicHolidaysReiseAgentur) {
		try {
			Scanner scanner = new Scanner(System.in);
			System.out.println("Bitte geben Sie die Kundennummer ein, welche Sie zuordnen m\u00f6chten: ");
			int inputKundenNr = scanner.nextInt();
			scanner.nextLine();
			if(magicHolidaysReiseAgentur.getKundeArrList().isEmpty()) {
				System.out.println("\nEs existieren weder Privat- noch Gesch\u00e4ftskunden.");
				System.out.println("Bitte legen Sie zun\u00e4chst einen Privat- oder Gesch\u00e4ftskunden an, um Reservierungen zuzuordnen.\n");
			}else {
				for(Kunde kunde : magicHolidaysReiseAgentur.getKundeArrList()) {
					if(inputKundenNr == kunde.getKundenNr()) {
						System.out.println("Wenn es sich um eine Flugreservierung handelt, geben Sie bitte \"f\" ein");
						System.out.println("Wenn es sich um eine Hotelreservierung handelt, geben Sie bitte \"h\" ein");
						String auswahlInput = scanner.nextLine().toLowerCase();
						if(auswahlInput.equals("f")) {
							System.out.println("Flugreservierung!");
							System.out.println("Bitte geben Sie die Reservierungsnummer ein: ");
							int reservierungsNr = scanner.nextInt();
							scanner.nextLine();
							
							System.out.println("Bitte geben Sie das Datum(dd.mm.yyyy) ein: ");
							String datum = scanner.nextLine();
							
							System.out.println("Bitte geben Sie die Summe ein: ");
							double summe = scanner.nextDouble();
							scanner.nextLine();
							
							System.out.println("Bitte geben Sie die Flugnummer ein: ");
							int flugNr = scanner.nextInt();
							scanner.nextLine();
							
							System.out.println("Bitte geben Sie den Abflughafen ein: ");
							String abFlugHafen = scanner.nextLine();
							
							System.out.println("Bitte geben Sie den Zielflughafen ein: ");
							String zielFlugHafen = scanner.nextLine();								
							
							Reservierung flugReservierung = new FlugReservierung(reservierungsNr, datum, summe, 
									flugNr, abFlugHafen, zielFlugHafen);
							
							kunde.storeKundeMitReservierungToArray(flugReservierung);
							System.out.println("Sie haben erfolgreich eine Flugreservierung mit die Reservierungsnummer: \"" 
							+ flugReservierung.getReservierungsNr() + "\" angelegt und den Kunden \"" + kunde.getVollstaendigerName() 
							+ "\" mit der Kundennummer: \"" + kunde.getKundenNr() + "\" zugeordnet!");	
						}else if(auswahlInput.equals("h")) {
							System.out.println("Bitte geben Sie die Reservierungsnummer ein: ");
							int reservierungsNr = scanner.nextInt();
							scanner.nextLine();
							
							System.out.println("Bitte geben Sie das Datum(dd.mm.yyyy) ein: ");
							String datum = scanner.nextLine();
							
							System.out.println("Bitte geben Sie die Summe ein: ");
							double summe = scanner.nextDouble();
							scanner.nextLine();
							
							System.out.println("Bitte geben Sie den Hotelnamen ein: ");
							String hotelName = scanner.nextLine();
							
							System.out.println("Bitte geben Sie die Reisedauer ein: ");
							String reiseDauer = scanner.nextLine();
							
							Reservierung hotelReservierung = new HotelReservierung(reservierungsNr, datum, summe, hotelName, reiseDauer);
							
							kunde.storeKundeMitReservierungToArray(hotelReservierung);
							System.out.println("Sie haben erfolgreich eine Hotelreservierung mit die Reservierungsnummer: \"" 
									+ hotelReservierung.getReservierungsNr() + "\" angelegt und den Kunden \"" + kunde.getVollstaendigerName() 
									+ "\" mit der Kundennummer: \"" + kunde.getKundenNr() + "\" zugeordnet!");
						}else{
							System.out.println("\nUng\u00fcltige Eingaben!");
							System.out.println("Bitte geben Sie entweder ein \"f\" oder ein \"h\" ein.");
							System.out.println("Bitte versuchen Sie es erneut! \n");
							addReservierungAndAssignKundenNummer(magicHolidaysReiseAgentur);
						}
					}					
				}
			}	
					}catch(InputMismatchException e) {
						System.out.println("\nSie haben anstelle einer \"Zahl\" etwas anderes eingegeben.");
						System.out.println("Bitte versuchen Sie es erneut! \n");
						addReservierungAndAssignKundenNummer(magicHolidaysReiseAgentur);
					}catch(Exception e) {
						System.out.println("\nEs tut uns leid.");
						System.out.println("Ein unerwarteter Fehler ist aufgetreten.");
						System.out.println("Beim wieder auftreten des Problems, bitten wir Sie uns zu kontaktieren, "
								+ "damit wir schnellsm\u00f6glich dieses Problem beheben k\u00f6nnen.");
						System.out.println("Bitte versuchen Sie es erneut.\n");				
					}
			}
			
	/**
	 * Zeigt die Informationen der Oberklasse Kunden, mit der entsprechenden Informationen der Unterklasse PrivatKunde oder GeschaeftsKunde an.
	 * Diese Entscheidung erfolgt \u00fcber die Eingabe der Kundennummer.
	 * 
	 * Au\u00dferdem werden von der Oberklasse Reservierung, die Unterklassen Flugreservierung und/oder Hotelreservierung angezeigt.
	 * 
	 * Sollte kein Kunde in der ArrayListe kundeArrList() existieren, wird der Benutzer informiert.
	 * Das gleiche gilt f\u00fcr die ArrayListe kundeInReservierungArrList().
	 * 
	 * @param magicHolidaysReiseAgentur - nimmt ein Objekt der Klasse Reiseagentur.
	 */
	public void kundeMitReservierungAnzeigenWahlDurchKundenNummer(ReiseAgentur magicHolidaysReiseAgentur) {
		try {
			Scanner scanner = new Scanner(System.in);
			
			System.out.println("Bitte geben Sie die Kundennummer des Kunde ein: ");		
			int auswahlKundenNr = scanner.nextInt();
			scanner.nextLine();
			
			if(magicHolidaysReiseAgentur.getKundeArrList().isEmpty()) {
				System.out.println("\nEs existieren weder Privat- noch Gesch\u00e4ftskunden.");
				System.out.println("Bitte legen Sie zun\u00e4chst einen Privat- oder Gesch\u00e4ftskunden an, um Kunde mit Reservierungen anzeigen zulassen.\n");
			}else {
				for (Kunde kunde : magicHolidaysReiseAgentur.getKundeArrList()) {
					if(auswahlKundenNr == kunde.getKundenNr()) {
						if(kunde.getKundeInReservierungArrList().isEmpty()) {
							System.out.println("\nEs existieren weder Flug- noch Hotelreservierungen.");
							System.out.println("Bitte legen Sie zun\u00e4chst ein Flug- oder Hotelreservierung an, um Kunde mit Reservierung anzeigen zulassen.\n");
						}else {
							if(kunde instanceof PrivatKunde) {
								PrivatKunde privatKunde = (PrivatKunde) kunde;
								
								System.out.println("\nInformation zum Kunden");
								System.out.println("Privatkunde\tKundenNr.: " + kunde.getKundenNr() + " | " + "Anrede: " +kunde.getAnrede() + " | " + "Vorname: " + kunde.getVorname() 
								+ " | " + "Nachname: " + kunde.getNachname() + " | " +"Vollst\u00e4ndiger Name: " + kunde.getVollstaendigerName() 
								+ " | " + "Geburtsdatum: " + kunde.getGeburtsDatum() + "\n\t\t" + "Email: " + kunde.getEmailAdresse() + " | " + "TelefonNr.: " + kunde.getTelefonNr());
								
								System.out.println("\nAdresse des Kunden");
								System.out.println("\t\tStra\u00dfe: " + kunde.getAdresse().getStra\u00dfe() + " | " + "HausNr.: " + kunde.getAdresse().getHausNr() + " | " + "PLZ: " + kunde.getAdresse().getPlz()
										+ " | " + "Ort: " +kunde.getAdresse().getOrt());
								
								System.out.println("\nBezahlmethode des Kunden");
								for(BezahlMethode bezahlMethode : privatKunde.getBezahlMethodeF\u00fcrPrivatKundeArrList()) {
									System.out.println("\t\tBezeichnung: " + bezahlMethode.getBezeichnung() + " | " + "Beschreibung: " + bezahlMethode.getBeschreibung());
								}
								
							} else if(kunde instanceof GeschaeftsKunde) {
								GeschaeftsKunde geschaeftsKunde = (GeschaeftsKunde) kunde;
								
								System.out.println("\nInformation zum Kunden");
								System.out.println("Gesch\u00e4ftskunde\t"+"KundenNr.: " + kunde.getKundenNr() + " | " + "Firmenname: " + geschaeftsKunde.getFirmenName() + " | " + "Anrede: " +kunde.getAnrede() + " | " + "Vorname: " + kunde.getVorname() 
								+ " | " + "Nachname: " + kunde.getNachname() + " | " +"Vollst\u00e4ndiger Name: " + kunde.getVollstaendigerName() 
								+ " | " + "Geburtsdatum: " + kunde.getGeburtsDatum() + "\n\t\t" + "Email: " + kunde.getEmailAdresse() + " | " + "TelefonNr.: " + kunde.getTelefonNr());
								
								System.out.println("\nAdresse des Kunden");
								System.out.println("\t\tStra\u00dfe: " + kunde.getAdresse().getStra\u00dfe() + " | " + "HausNr.: " +kunde.getAdresse().getHausNr() + " | " + "PLZ: " + kunde.getAdresse().getPlz()
										+ " | " + "Ort: " + kunde.getAdresse().getOrt());
								
								System.out.println("\nBezahlmethode des Kunden");
								for(int i = 0; i < geschaeftsKunde.getBezahlMethodeF\u00fcrGeschaeftsKundeList().length; i++) {
									System.out.println("\t\tBezeichnung: " + geschaeftsKunde.getBezahlMethodeF\u00fcrGeschaeftsKundeList()[i].getBezeichnung() + " | " + "Beschreibung: " 
											+ geschaeftsKunde.getBezahlMethodeF\u00fcrGeschaeftsKundeList()[i].getBeschreibung());
								}
							}
							System.out.println("\nReservierungen des Kunden");
							for(Reservierung reservierung : kunde.getKundeInReservierungArrList()) {
								if(reservierung instanceof FlugReservierung) {
									FlugReservierung flugReservierung = (FlugReservierung) reservierung;
									System.out.println("Flugreservierung\t" + "ReservierungsNr.: " +  flugReservierung.getReservierungsNr() 
									+ " | " + "Datum: " + flugReservierung.getDatum() + " | " + "Summe: " +flugReservierung.getSumme()
									+ " | " + "FlugNr.: " + flugReservierung.getFlugNr() + " | " + "Abflughafen: " + flugReservierung.getAbFlugHafen()
									+ " | " + "Zielflughafen: " + flugReservierung.getZielFlugHafen());
								}
								if(reservierung instanceof HotelReservierung) {
									HotelReservierung hotelReservierung = (HotelReservierung) reservierung;
									System.out.println("Hotelreservierung\t" + "ReservierungsNr.: " +  hotelReservierung.getReservierungsNr() 
									+ " | " + "Datum: " + hotelReservierung.getDatum() + " | " + "Summe: " + hotelReservierung.getSumme()
									+ " | " + "Hotelname: " + hotelReservierung.getHotelName() + " | " + "Reisedauer: " + hotelReservierung.getReiseDauer());
								}							
							}
						}
					}
				}
			}
		}catch(InputMismatchException e) {
			System.out.println("\nSie haben anstelle einer \"Zahl\" etwas anderes eingegeben.");
			System.out.println("Bitte versuchen Sie es erneut! \n");
			kundeMitReservierungAnzeigenWahlDurchKundenNummer(magicHolidaysReiseAgentur);
		}catch(Exception e) {
			System.out.println("\nEs tut uns leid.");
			System.out.println("Ein unerwarteter Fehler ist aufgetreten.");
			System.out.println("Beim wieder auftreten des Problems, bitten wir Sie uns zu kontaktieren, "
					+ "damit wir schnellsm\u00f6glich dieses Problem beheben k\u00f6nnen.");
			System.out.println("Bitte versuchen Sie es erneut.\n");				
		}
	}
	
	/**
	 * Zeigt die Informationen der Oberklasse Kunden, mit der entsprechenden Informationen der Unterklasse PrivatKunde oder GeschaeftsKunde an.
	 * Diese Entscheidung erfolgt \u00fcber die Eingabe des Nachnamens.
	 * 
	 * Au\u00dferdem werden von der Oberklasse Reservierung, die Unterklassen Flugreservierung und/oder Hotelreservierung angezeigt.
	 * 
	 * Sollte kein Kunde in der ArrayListe kundeArrList() existieren, wird der Benutzer informiert.
	 * Das gleiche gilt f\u00fcr die ArrayListe kundeInReservierungArrList().
	 *  
	 * @param magicHolidaysReiseAgentur - nimmt ein Objekt der Klasse Reiseagentur.
	 */
	public void kundeMitReservierungAnzeigenWahlDurchName(ReiseAgentur magicHolidaysReiseAgentur) {
		try {
			Scanner scanner = new Scanner(System.in);
			
			System.out.println("Bitte geben Sie den Nachnamen des Kunden ein: ");
			String kundeNameInput = scanner.nextLine().toLowerCase();
			
			if(magicHolidaysReiseAgentur.getKundeArrList().isEmpty()) {
				System.out.println("\nEs existieren weder Privat- noch Gesch\u00e4ftskunden.");
				System.out.println("Bitte legen Sie zun\u00e4chst einen Privat- oder Gesch\u00e4ftskunden an, um Kunde mit Reservierungen anzeigen zulassen.\n");
			}else {
				for(Kunde kunde : magicHolidaysReiseAgentur.getKundeArrList()) {
					if(kunde.getNachname().toLowerCase().equals(kundeNameInput)) {
						if(kunde.getKundeInReservierungArrList().isEmpty()) {
							System.out.println("\nEs existieren weder Flug- noch Hotelreservierungen.");
							System.out.println("Bitte legen Sie zun\u00e4chst ein Flug- oder Hotelreservierung an, um Kunde mit Reservierung anzeigen zulassen.\n");
						}else {
							if(kunde instanceof PrivatKunde) {
								PrivatKunde privatKunde = (PrivatKunde) kunde;
								System.out.println("\nInformation zum Kunden");
								System.out.println("Privatkunde\tKundenNr.: " + privatKunde.getKundenNr() + " | " + "Anrede: " +privatKunde.getAnrede() + " | " + "Vorname: " + privatKunde.getVorname() 
								+ " | " + "Nachname: " + privatKunde.getNachname() + " | " +"Vollst\u00e4ndiger Name: " + privatKunde.getVollstaendigerName() 
								+ " | " + "Geburtsdatum: " + privatKunde.getGeburtsDatum() + "\n\t\t" + "Email: " + privatKunde.getEmailAdresse() + " | " + "TelefonNr.: " + privatKunde.getTelefonNr());
								System.out.println("\nAdresse des Kunden");
								System.out.println("\t\tStra\u00dfe: " + privatKunde.getAdresse().getStra\u00dfe() + " | " + "HausNr.: " + privatKunde.getAdresse().getHausNr() + " | " + "PLZ: " + privatKunde.getAdresse().getPlz()
										+ " | " + "Ort: " +privatKunde.getAdresse().getOrt());
								
								System.out.println("\nBezahlmethode des Kunden");
								for(BezahlMethode bezahlMethode : privatKunde.getBezahlMethodeF\u00fcrPrivatKundeArrList()) {
									System.out.println("\t\tBezeichnung: " + bezahlMethode.getBezeichnung() + " | " + "Beschreibung: " + bezahlMethode.getBeschreibung());
								}
							}else if(kunde instanceof GeschaeftsKunde) {
								GeschaeftsKunde geschaeftsKunde = (GeschaeftsKunde) kunde;
								
								System.out.println("\nInformation zum Kunden");
								System.out.println("Gesch\u00e4ftskunde\t"+"KundenNr.: " + kunde.getKundenNr() + " | " + "Firmenname: " + geschaeftsKunde.getFirmenName() + " | " + "Anrede: " +kunde.getAnrede() + " | " + "Vorname: " + kunde.getVorname() 
								+ " | " + "Nachname: " + kunde.getNachname() + " | " +"Vollst\u00e4ndiger Name: " + kunde.getVollstaendigerName() 
								+ " | " + "Geburtsdatum: " + kunde.getGeburtsDatum() + "\n\t\t" + "Email: " + kunde.getEmailAdresse() + " | " + "TelefonNr.: " + kunde.getTelefonNr());
								
								System.out.println("\nAdresse des Kunden");
								System.out.println("\t\tStra\u00dfe: " + kunde.getAdresse().getStra\u00dfe() + " | " + "HausNr.: " +kunde.getAdresse().getHausNr() + " | " + "PLZ: " + kunde.getAdresse().getPlz()
										+ " | " + "Ort: " + kunde.getAdresse().getOrt());
								
								System.out.println("\nBezahlmethode des Kunden");
								for(int i = 0; i < geschaeftsKunde.getBezahlMethodeF\u00fcrGeschaeftsKundeList().length; i++) {
									System.out.println("\t\tBezeichnung: " + geschaeftsKunde.getBezahlMethodeF\u00fcrGeschaeftsKundeList()[i].getBezeichnung() + " | " + "Beschreibung: " 
											+ geschaeftsKunde.getBezahlMethodeF\u00fcrGeschaeftsKundeList()[i].getBeschreibung());
								}
							}
							System.out.println("\nReservierung des Kunden");
							for(Reservierung reservierung : kunde.getKundeInReservierungArrList()) {
								if(reservierung instanceof FlugReservierung) {
									FlugReservierung flugReservierung = (FlugReservierung) reservierung;
									System.out.println("Flugreservierung\t" + "ReservierungsNr.: " +  flugReservierung.getReservierungsNr() 
									+ " | " + "Datum: " + flugReservierung.getDatum() + " | " + "Summe: " +flugReservierung.getSumme()
									+ " | " + "FlugNr.: " + flugReservierung.getFlugNr() + " | " + "Abflughafen: " + flugReservierung.getAbFlugHafen()
									+ " | " + "Zielflughafen: " + flugReservierung.getZielFlugHafen());
									
								}else if(reservierung instanceof HotelReservierung) {
									HotelReservierung hotelReservierung = (HotelReservierung) reservierung;
									System.out.println("Hotelreservierung\t" + "ReservierungsNr.: " +  hotelReservierung.getReservierungsNr() 
									+ " | " + "Datum: " + hotelReservierung.getDatum() + " | " + "Summe: " + hotelReservierung.getSumme()
									+ " | " + "Hotelname: " + hotelReservierung.getHotelName() + " | " + "Reisedauer: " + hotelReservierung.getReiseDauer());
								}
							}	
						}
					}
				}
			}
		}catch(InputMismatchException e) {
			System.out.println("\nSie haben anstelle einer \"Zahl\" etwas anderes eingegeben.");
			System.out.println("Bitte versuchen Sie es erneut! \n");
			kundeMitReservierungAnzeigenWahlDurchName(magicHolidaysReiseAgentur);
		}catch(Exception e) {
			System.out.println("\nEs tut uns leid.");
			System.out.println("Ein unerwarteter Fehler ist aufgetreten.");
			System.out.println("Beim wieder auftreten des Problems, bitten wir Sie uns zu kontaktieren, "
					+ "damit wir schnellsm\u00f6glich dieses Problem beheben k\u00f6nnen.");
			System.out.println("Bitte versuchen Sie es erneut.\n");	
			System.out.println(e);
		}
	}
	
	
	
	/**
	 * Zeigt die Information der Oberklasse Reservierung, mit den Unterklassen(falls vorhanden) Flugreservierung oder Hotelreservierung an.
	 * Diese Entscheidung erfolgt \u00fcber die Eingabe der Reservierungsnummer.
	 * 
	 * Sollte kein Kunde in der ArrayListe kundeArrList() existieren, wird der Benutzer informiert.
	 * Das gleiche gilt f\u00fcr die ArrayListe kundeInReservierungArrList(). 
	 * 
	 * @param magicHolidaysReiseAgentur - nimmt ein Objekt der Klasse Reiseagentur.
	 */
	public void reservierungAnzeigenWahlDurchReservierungsNummer(ReiseAgentur magicHolidaysReiseAgentur) {
		try {
			Scanner scanner = new Scanner(System.in);
			
			System.out.println("Bitte geben Sie die Reservierungsnummer ein: ");
			int reservierungsNr = scanner.nextInt();
			scanner.nextLine();
			System.out.println("\nInformation zur Reservierung");
			if(magicHolidaysReiseAgentur.getKundeArrList().isEmpty()) {
				System.out.println("\nEs existieren weder Privat- noch Gesch\u00e4ftskunden.");
				System.out.println("Bitte legen Sie zun\u00e4chst einen Privat- oder Gesch\u00e4ftskunden an, um Kunde mit Reservierungen anzeigen zulassen.\n");
			}else {
				for(Kunde kunde : magicHolidaysReiseAgentur.getKundeArrList()) {
					if(kunde.getKundeInReservierungArrList().isEmpty()) {
						System.out.println("\nEs existieren weder Flug- noch Hotelreservierungen f\u00fcr den Kunden \"" + kunde.getVollstaendigerName() + "\"");
						System.out.println("Bitte legen Sie zun\u00e4chst ein Flug- oder Hotelreservierung an, um den Kunde \"" 
						+ kunde.getVollstaendigerName() + "\" mit Reservierung anzeigen zulassen.\n");
					}else {
						for(Reservierung reservierung : kunde.getKundeInReservierungArrList()) {
							if(reservierungsNr == reservierung.getReservierungsNr()) {
								if(reservierung instanceof FlugReservierung) {
									FlugReservierung flugReservierung = (FlugReservierung) reservierung;
									System.out.println("Flugreservierung\t" + "ReservierungsNr.: " +  flugReservierung.getReservierungsNr() 
									+ " | " + "Datum: " + flugReservierung.getDatum() + " | " + "Summe: " +flugReservierung.getSumme()
									+ " | " + "FlugNr.: " + flugReservierung.getFlugNr() + " | " + "Abflughafen: " + flugReservierung.getAbFlugHafen()
									+ " | " + "Zielflughafen: " + flugReservierung.getZielFlugHafen());
									
								}else if(reservierung instanceof HotelReservierung) {
									HotelReservierung hotelReservierung = (HotelReservierung) reservierung;
									System.out.println("Hotelreservierung\t" + "ReservierungsNr.: " +  hotelReservierung.getReservierungsNr() 
									+ " | " + "Datum: " + hotelReservierung.getDatum() + " | " + "Summe: " + hotelReservierung.getSumme()
									+ " | " + "Hotelname: " + hotelReservierung.getHotelName() + " | " + "Reisedauer: " + hotelReservierung.getReiseDauer());
								}
							}	
						}
					}
				}	
			}
		}catch(InputMismatchException e) {
			System.out.println("\nSie haben anstelle einer \"Zahl\" etwas anderes eingegeben.");
			System.out.println("Bitte versuchen Sie es erneut! \n");
			reservierungAnzeigenWahlDurchReservierungsNummer(magicHolidaysReiseAgentur);
		}catch(Exception e) {
			System.out.println("\nEs tut uns leid.");
			System.out.println("Ein unerwarteter Fehler ist aufgetreten.");
			System.out.println("Beim wieder auftreten des Problems, bitten wir Sie uns zu kontaktieren, "
					+ "damit wir schnellsm\u00f6glich dieses Problem beheben k\u00f6nnen.");
			System.out.println("Bitte versuchen Sie es erneut.\n");	
		}
	}
}
