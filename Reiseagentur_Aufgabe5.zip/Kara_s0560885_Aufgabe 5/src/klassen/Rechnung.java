package klassen;

/**
 * Die Klasse Rechnung implementiert das Interface IBezahlStrategie.
 * 
 * @author S0560885 Kaan Kara
 * @eclipseVersion 2019-09 R (4.13.0)
 * @javaVersion 12
 * @runTime 33
 * @erstellungsDatum 21.10.2019
 * @letzte\u00c4nderungsDatum 10.01.2020
 *
 */
public class Rechnung implements IBezahlStrategie {
	private String artDesBezahlens;

	/**
	 * Der Konstruktor nimmt einen String "artDesBezahlens" als Parameter.
	 * 
	 * @param artDesBezahlens wird ben\u00f6tigt, um ein Objekt der Klasse Rechnung
	 *                        zu erstellen
	 */
	public Rechnung(String artDesBezahlens) {
		super();
		this.artDesBezahlens = artDesBezahlens;
	}

	@Override
	public double zahlen(double betrag) {

		return betrag;
	}

	@Override
	public String checkOutMessage(String bezeichnung, double betrag) {
		String message = "Der Betrag " + betrag + " Euro wird mit der Bezahlstrategie " + this.getArtDesBezahlens()
				+ " bezahlt.";

		return message;
	}

	/**
	 * @return gibt artDesBezahlens wieder.
	 */
	public String getArtDesBezahlens() {
		return artDesBezahlens;
	}

	/**
	 * @param setzt artDesBezahlens ein.
	 */
	public void setArtDesBezahlens(String artDesBezahlens) {
		this.artDesBezahlens = artDesBezahlens;
	}

}
