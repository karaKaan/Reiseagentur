package klassen;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * Die Klasse GeschaeftsKunde erbt von der abstrakten Klasse Kunde. Durch diese
 * Klasse, kann man ein Objekt der Klasse GeschaeftsKunde erstellen.
 * 
 * @author S0560885 Kaan Kara
 * @eclipseVersion 2019-09 R (4.13.0)
 * @javaVersion 12
 * @runTime 33
 * @erstellungsDatum 21.10.2019
 * @letzte\u00c4nderungsDatum 11.01.2020
 *
 */

public class GeschaeftsKunde extends Kunde implements Serializable {
	private String firmenName;

	/**
	 * Die Signatur des Konstruktors muss erf\u00fcllt werden, damit ein Objekt der
	 * Klasse Adresse entstehen kann. Daf\u00fcr m\u00fcssen die Parameter(siehe
	 * unten) vollst\u00e4ndig ausgef\u00fcllt werden.
	 * 
	 * @param kundenNr                             wird ben\u00f6tigt.
	 * @param anrede                               wird ben\u00f6tigt.
	 * @param vornamen                             wird ben\u00f6tigt.
	 * @param nachnamen                            wird ben\u00f6tigt.
	 * @param emailAdresse                         wird ben\u00f6tigt.
	 * @param telefonNr                            wird ben\u00f6tigt.
	 * @param geburtsDatum                         wird ben\u00f6tigt.
	 * @param privateAdresse                       wird ben\u00f6tigt.
	 * @param firmenName                           wird ben\u00f6tigt.
	 * @param bezahlMethodeF\u00fcrGeschaeftsKunde wird ben\u00f6tigt.
	 */
	public GeschaeftsKunde(int kundenNr, String anrede, String vorname, String nachname, String emailAdresse,
			String telefonNr, LocalDate geburtsDatum, String firmenName) {
		super(kundenNr, anrede, vorname, nachname, emailAdresse, telefonNr, geburtsDatum);
		this.firmenName = firmenName;

	}

	@Override
	public void getName() {
		super.setVollstaendigerName(this.getVorname() + " " + this.getNachname() + " - " + this.getFirmenName());
	}

	/**
	 * Gibt die Variable firmenName zur\u00fcck.
	 * 
	 * @return firmenName wird zur\u00fcckgegeben.
	 */
	public String getFirmenName() {
		return firmenName;
	}

	/**
	 * Legt die Variable firmenName an.
	 * 
	 * @param firmenName wird ben\u00f6tigt.
	 */
	public void setFirmenName(String firmenName) {
		this.firmenName = firmenName;
	}

}
