package klassen;

import java.util.ArrayList;
import java.util.List;

/**
 * Die Klasse Auditing implementiert das Interface IObserver.
 * 
 * @author S0560885 Kaan Kara
 * @eclipseVersion 2019-09 R (4.13.0)
 * @javaVersion 12
 * @runTime 33
 * @erstellungsDatum 21.10.2019
 * @letzte\u00c4nderungsDatum 10.01.2020
 *
 */
public class Auditing implements IObserver {

	private static Auditing auditing = null;
	private List<Zahlung> zahlungAuditList;

	/**
	 * Der Konstruktor instanziiert nur die ArrayListe.
	 */
	private Auditing() {
		zahlungAuditList = new ArrayList<Zahlung>();
	}

	/**
	 * Es erstellt ein Objekt der Klasse Auditing, falls es null ist. Ansonsten
	 * referenziert es nur das schon erstellte Objekt.
	 * 
	 * @return das Objekt der Klasse Auditing
	 */
	public static Auditing getInstance() {
		if (auditing == null) {
			auditing = new Auditing();
		}

		return auditing;
	}

	@Override
	public void updateObserver(Zahlung zahlung, double betrag) {
		zahlungAuditList.add(zahlung);
	}

	/**
	 * @return gibt zahlungAuditList wieder.
	 */
	public List<Zahlung> getZahlungAuditList() {
		return zahlungAuditList;
	}

	/**
	 * @param setzt zahlungAuditList ein.
	 */
	public void setZahlungAuditList(List<Zahlung> zahlungAuditList) {
		this.zahlungAuditList = zahlungAuditList;
	}

}
