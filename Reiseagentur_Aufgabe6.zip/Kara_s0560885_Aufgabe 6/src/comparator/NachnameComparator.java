/**
 * 
 */
package comparator;

import java.util.Comparator;

import klassen.Kunde;

/***
 * Sortiert eine ArrayListe von Kunden
 * 
 * @author S0560885 Kaan Kara
 * @eclipseVersion 2019-09 R (4.13.0)
 * @javaVersion 12
 * @runTime 33
 * @erstellungsDatum 21.10.2019
 * @letzte\u00c4nderungsDatum 07.12.2019
 * 
 */
public class NachnameComparator implements Comparator<Kunde> {

	/**
	 * Nimmt zwei Parameter Kunde o1 und Kunde o2 an. Diese Methode vergleicht die
	 * beiden Nachnamen und sortiert die aufsteigend.
	 */
	@Override
	public int compare(Kunde o1, Kunde o2) {

		int compareNachname = o1.getNachname().toLowerCase().compareTo(o2.getNachname().toLowerCase());

		return compareNachname;
	}

}
