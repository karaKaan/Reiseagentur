package starter;

import java.util.ArrayList;
import java.util.Collections;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import comparator.BezahlMethodeComparator;
import comparator.KundenComparator;
import gui.GuiStarter;

import java.util.Scanner;
import java.util.Set;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

import klassen.Adresse;
import klassen.Auditing;
import klassen.Buchhaltung;
import klassen.FlugReservierung;
import klassen.GeschaeftsKunde;
import klassen.HotelReservierung;
import klassen.Kasse;
import klassen.Kunde;
import klassen.PrivatKunde;
import klassen.ReiseAgentur;
import klassen.Reservierung;
import klassen.Zahlung;
import util.IOUtils;

/***
 *
 * Die Starter-Klasse legt die Objekte der jeweiligen Klassen an und gibt die
 * Informationen auf der Konsole wieder.
 * 
 * @author S0560885 Kaan Kara
 * @eclipseVersion 2019-09 R (4.13.0)
 * @javaVersion 12
 * @runTime 33
 * @erstellungsDatum 21.10.2019
 * @letzte\u00c4nderungsDatum 24.01.2020
 * 
 */

public class Starter {
	private static ReiseAgentur magicHolidaysReiseAgentur;

	/**
	 * In der main-Methode wird die Methode "erzeugeReiseAgentur()" aufgerufen,
	 * dadurch wird ein Objekt der Klasse ReiseAgentur erzeugt. Es ist
	 * au\u00dferhalb der while-Schleife, da wir nur ein Objekt der Klasse
	 * ReiseAgentur ben\u00f6tigen. Die While-Schleife ist immer "true" und es
	 * werden die Methoden zeigeMenueOberflaeche(), nimmZahlVonMitarbeiter() und
	 * fuehreWahlAus() aufgerufen.
	 * 
	 * Die Konsole zeigt zun\u00e4chst die Men\u00fcoberfl\u00e4che und der Benutzer
	 * kann dann eine Zahl eingeben. Diese Zahl wird dann in der Variable
	 * "wahlVonMitarbeiter" initialisiert. Diese Variable wird dann an die Methode
	 * "fuehreWahlAus()" als Parameter weitergegeben, au\u00dferdem das Objekt
	 * "magicHolidaysReiseAgentur" wird ebenso als Parameter weitergegeben.
	 * 
	 * @param args wird ben\u00f6tigt.
	 * 
	 */
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		magicHolidaysReiseAgentur = new Starter().erzeugeReiseAgentur();

		new Starter().erzeugeDreiPrivatKunde(magicHolidaysReiseAgentur);
		new Starter().erzeugeDreiGeschaeftsKunde(magicHolidaysReiseAgentur);

		System.out.println("Wollen Sie per Konsole arbeiten, dann geben Sie " + "\"cli" + "\" ein.");
		System.out.println("Wollen Sie per Benutzeroberfl\u00e4che(GUI) arbeiten, dann geben Sie " + "\"gui" + "\" ein.");

		String userInput = scanner.nextLine();

		if (userInput.equalsIgnoreCase("gui")) {
			new GuiStarter(magicHolidaysReiseAgentur);
		} else if (userInput.equalsIgnoreCase("cli")) {
			while (true) {
				new Starter().zeigeMenueOberflaeche();
				int wahlVonMitarbeiter = new Starter().nimmZahlVonMitarbeiter();
				new Starter().fuehreWahlAus(wahlVonMitarbeiter, magicHolidaysReiseAgentur);

			}
		} else {
			System.out.println("Sie haben eine falsche Eingabe eingegeben.");
			System.out.println("Bitte probieren Sie es erneut.\n");
			main(args);
		}
	}

	/**
	 * Die Methode erzeugeReiseAgentur() soll ein Objekt der Klasse ReiseAgentur
	 * erzeugen.
	 * 
	 * @return magicHolidaysReiseAgentur wird zur\u00fcckgegeben.
	 */
	public ReiseAgentur erzeugeReiseAgentur() {
		ReiseAgentur magicHolidaysReiseAgentur = new ReiseAgentur("DE812524001", "Magic Holidays Reiseagentur",
				new Adresse("Hauptstra\u00dfe", "5a", 10559, "Berlin"));
		return magicHolidaysReiseAgentur;
	}

	/**
	 * Erzeugt schon im Vorfeld 3 unterschiedliche Objekte der Klasse PrivatKunden.
	 * 
	 * @param magicHolidaysReiseAgentur - nimmt das Objekt der Klasse ReiseAgentur,
	 *                                  um auf Methoden dieser Klasse zur\u00fcck
	 *                                  zugreifen.
	 */
	public void erzeugeDreiPrivatKunde(ReiseAgentur magicHolidaysReiseAgentur) {
		Kunde privatKundeMax = new PrivatKunde(1, "Herr", "Max", "Mustermann", "max.muster@gmail.com", "55442211",
				LocalDate.of(1970, 5, 1));
		privatKundeMax.getName();
		privatKundeMax.setAdresse(new Adresse("Hauptstra\u00dfe", "32a", 54110, "Frankurt"));

		Reservierung maxFlugReservierung = new FlugReservierung(1, LocalDate.of(2019, 11, 27), 320.99, 1,
				"Berlin Tegel", "Moscow Airport");
		privatKundeMax.storeKundeMitReservierungToArray(maxFlugReservierung);

		magicHolidaysReiseAgentur.storeKundeToArrList(privatKundeMax);

		Kunde privatKundeMaria = new PrivatKunde(2, "Frau", "Maria", "Musterfrau", "maria.muster@gmail.com", "99874114",
				LocalDate.of(1980, 8, 27));
		privatKundeMaria.getName();
		privatKundeMaria.setAdresse(new Adresse("Richardstra\u00dfe", "12b", 13241, "Berlin"));
		if (privatKundeMaria instanceof PrivatKunde) {

			Reservierung mariaFlugReservierung = new FlugReservierung(2, LocalDate.of(2019, 11, 27), 320.99, 1,
					"Berlin Tegel", "Moscow Airport");
			Reservierung mariaHotelReservierung = new HotelReservierung(2, LocalDate.of(2019, 11, 28), 2500,
					"Moscow Grand Palace", "14 Tage");
			privatKundeMaria.storeKundeMitReservierungToArray(mariaFlugReservierung);
			privatKundeMaria.storeKundeMitReservierungToArray(mariaHotelReservierung);

			magicHolidaysReiseAgentur.storeKundeToArrList(privatKundeMaria);

			Kunde privatKundeJohn = new PrivatKunde(3, "Herr", "John", "Heinrich", "john1985@gmail.com", "45698174",
					LocalDate.of(1990, 11, 30));
			privatKundeJohn.getName();
			privatKundeJohn.setAdresse(new Adresse("Musterstra\u00dfe", "01", 33212, "Dortmund"));

			Reservierung johnFlugReservierung = new FlugReservierung(3, LocalDate.of(2020, 1, 1), 510.99, 2,
					"Berlin Tegel", "New York Airport");
			Reservierung johnRueckFlugReservierung = new FlugReservierung(3, LocalDate.of(2020, 1, 22), 510.99, 3,
					"New York Airport", "Berlin Tegel");
			Reservierung johnHotelReservierung = new HotelReservierung(3, LocalDate.of(2020, 1, 2), 3500.47,
					"NY-LuxusHotel", "21 Tage");
			privatKundeJohn.storeKundeMitReservierungToArray(johnFlugReservierung);
			privatKundeJohn.storeKundeMitReservierungToArray(johnRueckFlugReservierung);
			privatKundeJohn.storeKundeMitReservierungToArray(johnHotelReservierung);

			magicHolidaysReiseAgentur.storeKundeToArrList(privatKundeJohn);
		}
	}

	/**
	 * Erzeugt schon im Vorfeld 3 unterschiedliche Objekte der Klasse
	 * GeschaeftsKunden.
	 * 
	 * @param magicHolidaysReiseAgentur - nimmt das Objekt der Klasse ReiseAgentur,
	 *                                  um auf Methoden dieser Klasse zur\u00fcck
	 *                                  zugreifen.
	 */
	public void erzeugeDreiGeschaeftsKunde(ReiseAgentur magicHolidaysReiseAgentur) {
		Kunde geschaeftsKundeTom = new GeschaeftsKunde(4, "Herr", "Tom", "Jeffrey", "tom.jeff@webmail.com", "55598371",
				LocalDate.of(1990, 8, 17), "Tom & Jerry Group");
		geschaeftsKundeTom.getName();
		geschaeftsKundeTom.setAdresse(new Adresse("Hauptstra\u00dfe", "15", 12332, "Berlin"));

		Reservierung tomFlugReservierung = new FlugReservierung(1, LocalDate.of(2020, 1, 3), 350, 1,
				"Berlin Sch\u00f6nefeld", "Swizz Airport");
		geschaeftsKundeTom.storeKundeMitReservierungToArray(tomFlugReservierung);
		magicHolidaysReiseAgentur.storeKundeToArrList(geschaeftsKundeTom);

		Kunde geschaeftsKundeMatthias = new GeschaeftsKunde(5, "Herr", "Matthias", "Schweigh\u00f6fer",
				"m.schweigh\u00f6fer@gmail.com", "95174824", LocalDate.of(1988, 1, 31), "Umbrella Corp.");
		geschaeftsKundeMatthias.getName();
		geschaeftsKundeMatthias.setAdresse(new Adresse("Moritzstra\u00dfe", "10b", 33221, "Stuttgart"));

		Reservierung matthiasFlugReservierung = new FlugReservierung(2, LocalDate.of(2020, 1, 20), 150, 2,
				"Stuttgart Airport", "Paris Airport");
		Reservierung matthiasHotelReservierung = new HotelReservierung(2, LocalDate.of(2020, 3, 1), 1500.49,
				"Paris GrandPalace", "7 Tage");
		geschaeftsKundeMatthias.storeKundeMitReservierungToArray(matthiasFlugReservierung);
		geschaeftsKundeMatthias.storeKundeMitReservierungToArray(matthiasHotelReservierung);
		magicHolidaysReiseAgentur.storeKundeToArrList(geschaeftsKundeMatthias);

		Kunde geschaeftsKundeBrigitte = new GeschaeftsKunde(6, "Frau", "Brigitte", "M\u00fcller",
				"Briggym\u00fcller@hotmail.com", "32112399", LocalDate.of(1970, 5, 25), "Designer GmbH");
		geschaeftsKundeBrigitte.getName();
		geschaeftsKundeBrigitte.setAdresse(new Adresse("Hauptstra\u00dfe", "19b", 40432, "Hamburg"));

		Reservierung brigitteFlugReservierung = new FlugReservierung(3, LocalDate.of(2020, 3, 9), 210, 3,
				"Hamburg Airport", "Malediven Airport");
		Reservierung brigitteRueckFlugReservierung = new FlugReservierung(3, LocalDate.of(2020, 3, 30), 210, 4,
				"Malediven Airport", "Hamburg Airport");
		Reservierung brigitteHotelReservierung = new HotelReservierung(3, LocalDate.of(2020, 3, 10), 3499.99,
				"Male Palace", "21-Tage");
		geschaeftsKundeBrigitte.storeKundeMitReservierungToArray(brigitteFlugReservierung);
		geschaeftsKundeBrigitte.storeKundeMitReservierungToArray(brigitteRueckFlugReservierung);
		geschaeftsKundeBrigitte.storeKundeMitReservierungToArray(brigitteHotelReservierung);
		magicHolidaysReiseAgentur.storeKundeToArrList(geschaeftsKundeBrigitte);

	}

	/**
	 * Die Methode nimmZahlVonMitarbeiter() erlaubt es den Kunden eine Zahl
	 * einzugeben. Es soll die Variable wahlVonMitarbeiter zur\u00fcckgeben.
	 * 
	 * @return wahlVonMitarbeiter - gibt die Eingabe des Mitarbeiters wieder.
	 */
	public int nimmZahlVonMitarbeiter() {
		Scanner scanner = new Scanner(System.in);

		try {
			System.out
					.println("\nBitte geben Sie eine Zahl ein, um ein entsprechendes Men\u00fc-Punkt auszuf\u00fchren");
			int wahlVonMitarbeiter = scanner.nextInt();

			return wahlVonMitarbeiter;
		} catch (Exception e) {
			System.out.println("Bitte geben Sie eine \"Zahl\" ein.");
		}
		return 0;
	}

	/**
	 * Die Methode fuehreWahlAus() nimmt die Parameter "wahlVonMitarbeiter" und
	 * "magicHolidaysReiseAgentur". Es gibt eine Switch-Case-Anweisung und je nach
	 * Eingabe soll der Benutzer die M\u00f6glichkeit haben, die entsprechende
	 * Methode aufzurufen. Bei Eingabe von 1 ruft es die Methode
	 * "addPrivatKunde(magicHolidaysReiseAgentur)" auf, bei 2 ruft es die Methode
	 * "addGeschaeftsKunde(magicHolidaysReiseAgentur)", usw. Wenn eine andere Zahl
	 * als die im Case vorhanden Zahlen eingegeben wurde, wird der default
	 * aufgerufen und der Benutzer wird dar\u00fcber informiert.
	 * 
	 * Das 2.Parameter "magicHolidaysReiseAgentur" wird an die anderen Methoden
	 * weitergegeben, um in diesen Methoden eine Verbindung mit der Klasse
	 * ReiseAgentur herzustellen.
	 * 
	 * @param wahlVonMitarbeiter        - nimmt die Eingabe des Mitarbeiters.
	 * @param magicHolidaysReiseAgentur - nimmt ein Objekt der Klasse ReiseAgentur.
	 */
	public void fuehreWahlAus(int wahlVonMitarbeiter, ReiseAgentur magicHolidaysReiseAgentur) {
		switch (wahlVonMitarbeiter) {
		case 1:
			addPrivatKunde(magicHolidaysReiseAgentur);
			break;
		case 2:
			addGeschaeftsKunde(magicHolidaysReiseAgentur);
			break;
		case 3:
			addReservierungAndAssignKundenNummer(magicHolidaysReiseAgentur);
			break;
		case 4:
			kundeMitReservierungAnzeigenWahlDurchKundenNummer(magicHolidaysReiseAgentur);
			break;
		case 5:
			kundeMitReservierungAnzeigenWahlDurchName(magicHolidaysReiseAgentur);
			break;
		case 6:
			reservierungAnzeigenWahlDurchReservierungsNummer(magicHolidaysReiseAgentur);
			break;
		case 7:
			alleKundenSortiertAnzeigen(magicHolidaysReiseAgentur);
			break;
		case 8:
			bezahlMethodeSortiertAnzeigen(magicHolidaysReiseAgentur);
			break;
		case 9:
			alleReservierungenSortiertAnzeigen(magicHolidaysReiseAgentur);
			break;
		case 10:
			exportData(magicHolidaysReiseAgentur);
			break;
		case 11:
			importData();
			break;
		case 12:
			exportSortedKundeAsCsv(magicHolidaysReiseAgentur);
			break;
		case 13:
			reservierungCheckOut();
			break;
		case 14:
			showBuchhaltungsListe();
			break;
		case 15:
			showAuditList();
			break;
		case 16:
			System.exit(0);
			break;
		default:
			System.out.println("Bitte geben Sie eine Zahl von 1-16 ein.");
		}
	}

	/**
	 * Die Methode zeigeMenueOberflaeche() hat einen Array "menueList" Typ String,
	 * au\u00dferdem wurden diese Elemente auch gleich initialisiert.
	 * 
	 * Die for-each Schleife soll jedes Element in die Variable String "menuePunkt"
	 * initialisieren und auf der Konsole wiedergeben.
	 */
	public void zeigeMenueOberflaeche() {
		String[] menueList = { "\n(01) Privatekunde anlegen", "(02) Gesch\u00e4ftskunde anlegen",
				"(03) Reservierung anlegen und Kundennummer zuordnen",
				"(04) Kunde mit Reservierung anzeigen (Auswahl durch Kundennummer)",
				"(05) Kunde mit Reservierung anzeigen (Auswahl durch Name)",
				"(06) Reservierung anzeigen (Auswahl durch Reservierungsnummer)",
				"(07) Alle Kunden sortiert nach aufsteigendem Vornamen,\n\taufsteigendem Nachnamen zeigen",
				"(08) \u00dcbersicht der Bezahlmethoden (Bezeichnungen)"
						+ " sortiert nach \n\tabsteigender H\u00e4ufigkeit zeigen",
				"(09) Alle Reservierungen eines Datums sortiert nach Nachnamen der \n\tKunden zeigen",
				"(10) Daten Export", "(11) Daten Import",
				"(12) Kunden nach Nachname sortiert als CSV-Datei exportieren.", "(13) Reservierung Checkout",
				"(14) Buchhaltungsliste zeigen", "(15) Auditingliste zeigen", "(16) Beenden" };
		for (String menuePunkt : menueList) {
			System.out.println(menuePunkt);
		}
	}

	/**
	 * Die Methode addPrivatKunde() hat einen Parameter, unzwar
	 * "magicHolidaysReiseAgentur". Diese Methode soll von der Oberklasse Kunde, die
	 * Unterklasse PrivatKunde mit Hilfe von Polymorphismus, erstellen.
	 * Au\u00dferdem wird die Adresse, mit Hilfe der set-Methode aufgerufen und
	 * erstellt.
	 * 
	 * Um die BezahlMethode f\u00fcr diesen PrivatKunden anzulegen, wird ein
	 * "if-Statement" mit "instanceof" als Bedingung festgelegt. Dar\u00fcber wird
	 * ein Objekt der Klasse BezahlMethode erstellt und der ArrayListe
	 * bezahlMethodeF\u00fcrPrivatKundeArrList() hinzugef\u00fcgt. Der Benutzer kann
	 * nur maximal 3 Bezahlmethoden pro Privatkunde anlegen und das wird \u00fcber
	 * einem if-Statement und for-Schleife geregelt.
	 * 
	 * Das erstellte Objekt der Klasse PrivatKunde, wird in die ArrayListe
	 * kundeArrList(), das sich im Objekt "magicHolidaysReiseAgentur" befindet,
	 * hinzugef\u00fcgt.
	 * 
	 * @param magicHolidaysReiseAgentur - nimmt ein Objekt der Klasse Reiseagentur.
	 */
	public void addPrivatKunde(ReiseAgentur magicHolidaysReiseAgentur) {
		try {
			Scanner scanner = new Scanner(System.in);
			System.out.println("Bitte geben Sie die Kundennummer ein: ");
			int kundenNr = scanner.nextInt();
			scanner.nextLine();
			System.out.println("Bitte geben Sie die Anrede ein: ");
			String anrede = scanner.nextLine();

			System.out.println("Bitte geben Sie den Vorname ein: ");
			String vorname = scanner.nextLine();

			System.out.println("Bitte geben Sie den Nachname ein: ");
			String nachname = scanner.nextLine();

			System.out.println("Bitte geben Sie die Email Adresse ein: ");
			String emailAdresse = scanner.nextLine();

			System.out.println("Bitte geben Sie die Telefonnummer ein: ");
			String telefonNr = scanner.nextLine();

			System.out.println("Bitte geben Sie das Geburtsdatum(yyyy-mm-dd) ein: ");
			String geburtsDatumInput = scanner.nextLine();
			LocalDate geburtsDatum = LocalDate.parse(geburtsDatumInput);

			System.out.println("Bitte geben Sie die Stra\u00dfe des Kunden ein: ");
			String strasse = scanner.nextLine();

			System.out.println("Bitte geben Sie die Hausnummer des Kunden ein: ");
			String hausNr = scanner.nextLine();

			System.out.println("Bitte geben Sie die PLZ des Kunden ein: ");
			int plz = scanner.nextInt();
			scanner.nextLine();

			System.out.println("Bitte geben Sie den Ort des Kunden ein: ");
			String ort = scanner.nextLine();

			Kunde privatKunde = new PrivatKunde(kundenNr, anrede, vorname, nachname, emailAdresse, telefonNr,
					geburtsDatum);
			privatKunde.setAdresse(new Adresse(strasse, hausNr, plz, ort));
			privatKunde.getName();

			magicHolidaysReiseAgentur.storeKundeToArrList(privatKunde);
			System.out.println("Privatkunde mit der Kundennummer \"" + privatKunde.getKundenNr()
					+ "\" und dem Nachnamen \"" + privatKunde.getNachname() + "\" wurde erfolgreich angelegt!");

		} catch (InputMismatchException e) {
			System.out.println("\nBitte geben Sie eine \"Zahl\" ein.");
			System.out.println("Bitte versuchen Sie es erneut.\n");
			addPrivatKunde(magicHolidaysReiseAgentur);
		} catch (DateTimeParseException e) {
			System.out.println(
					"\nSie haben entweder eine falsche Zahl als Monat oder als Tag eingegeben, oder den Format nicht beibehalten.");
			System.out.println("Bitte geben Sie als Monat eine Zahl von 1 bis 12 ein und als Tag von 1 bis 31.");
			System.out.println("Bitte achten Sie auf das Format (yyyy-mm-dd).");
			System.out.println("Bitte versuchen Sie es erneut.\n");
			addPrivatKunde(magicHolidaysReiseAgentur);
		} catch (Exception e) {
			System.out.println(e);
			System.out.println("\nEs tut uns leid.");
			System.out.println("Ein unerwarteter Fehler ist aufgetreten.");
			System.out.println("Beim wieder auftreten des Problems, bitten wir Sie uns zu kontaktieren, "
					+ "damit wir schnellsm\u00f6glich dieses Problem beheben k\u00f6nnen.");
			System.out.println("Bitte versuchen Sie es erneut.\n");
		}
	}

	/**
	 * Die Methode hat einen Parameter "magicHolidaysReiseAgentur". Dadurch wird am
	 * Ende gew\u00e4hrleistet, dass das erstellte Objekt, der Klasse
	 * GeschaeftsKunde, der ArrayListe "kundeArrList()" hinzugef\u00fcgt wird. Diese
	 * Methode erstellt von der Oberklasse Kunde, die Unterklasse GeschaeftsKunde
	 * durch Polymorphismus. Au\u00dferdem werden Objekte von der Klasse Adresse und
	 * BezahlMethoden erstellt.
	 * 
	 * Die BezahlMethode wird dann dem Array
	 * bezahlMethodeF\u00fcrGeschaeftsKundeList() hinzugef\u00fcgt, au\u00dferdem
	 * gibt es keine Restriktion, da die Gesch\u00e4ftskunden nur eine Bezahlmethode
	 * haben.
	 * 
	 * 
	 * @param magicHolidaysReiseAgentur - nimmt ein Objekt der Klasse Reiseagentur .
	 */
	public void addGeschaeftsKunde(ReiseAgentur magicHolidaysReiseAgentur) {
		try {
			Scanner scanner = new Scanner(System.in);
			System.out.println("Bitte geben Sie die Kundennummer ein: ");
			int kundenNr = scanner.nextInt();

			scanner.nextLine();
			System.out.println("Bitte geben Sie die Anrede ein: ");
			String anrede = scanner.nextLine();

			System.out.println("Bitte geben Sie den Vorname ein: ");
			String vorname = scanner.nextLine();

			System.out.println("Bitte geben Sie den Nachname ein: ");
			String nachname = scanner.nextLine();

			System.out.println("Bitte geben Sie die Email Adresse ein: ");
			String emailAdresse = scanner.nextLine();

			System.out.println("Bitte geben Sie die Telefonnummer ein: ");
			String telefonNr = scanner.nextLine();

			System.out.println("Bitte geben Sie das Geburtsdatum(yyyy-mm-dd) ein: ");
			String geburtsDatumInput = scanner.nextLine();
			LocalDate geburtsDatum = LocalDate.parse(geburtsDatumInput);

			System.out.println("Bitte geben Sie den Namen Ihrer Firma ein: ");
			String firmenName = scanner.nextLine();

			System.out.println("Bitte geben Sie die Stra\u00dfe des Kunden ein: ");
			String strasse = scanner.nextLine();

			System.out.println("Bitte geben Sie die Hausnummer des Kunden ein: ");
			String hausNr = scanner.nextLine();

			System.out.println("Bitte geben Sie die PLZ des Kunden ein: ");
			int plz = scanner.nextInt();
			scanner.nextLine();

			System.out.println("Bitte geben Sie den Ort des Kunden ein: ");
			String ort = scanner.nextLine();

			Kunde geschaeftsKunde = new GeschaeftsKunde(kundenNr, anrede, vorname, nachname, emailAdresse, telefonNr,
					geburtsDatum, firmenName);
			geschaeftsKunde.setAdresse(new Adresse(strasse, hausNr, plz, ort));
			geschaeftsKunde.getName();

			magicHolidaysReiseAgentur.storeKundeToArrList(geschaeftsKunde);
			System.out.println("Gesch\u00e4ftskunde mit der Kundennummer: \"" + geschaeftsKunde.getKundenNr()
					+ "\" und dem Nachnamen \"" + geschaeftsKunde.getNachname() + "\" wurde erfolgreich angelegt!");

		} catch (InputMismatchException e) {
			System.out.println("\nBitte geben Sie eine \"Zahl\" ein.");
			System.out.println("Bitte versuchen Sie es erneut.\n");
			addGeschaeftsKunde(magicHolidaysReiseAgentur);
		} catch (DateTimeParseException e) {
			System.out.println(
					"\nSie haben entweder eine falsche Zahl als Monat oder als Tag eingegeben, oder den Format nicht beibehalten.");
			System.out.println("Bitte geben Sie als Monat eine Zahl von 1 bis 12 ein und als Tag von 1 bis 31.");
			System.out.println("Bitte achten Sie auf das Format (yyyy-mm-dd).");
			System.out.println("Bitte versuchen Sie es erneut.\n");
			addGeschaeftsKunde(magicHolidaysReiseAgentur);
		} catch (Exception e) {
			System.out.println("\nEs tut uns leid.");
			System.out.println("Ein unerwarteter Fehler ist aufgetreten.");
			System.out.println("Beim wieder auftreten des Problems, bitten wir Sie uns zu kontaktieren, "
					+ "damit wir schnellsm\u00f6glich dieses Problem beheben k\u00f6nnen.");
			System.out.println("Bitte versuchen Sie es erneut.\n");
		}
	}

	/**
	 * Die Methode addReservierungAndAssignKundenNummer() soll von der Oberklasse
	 * Reservierung, entweder die Unterklasse Flugreservierung oder die Unterklasse
	 * Hotelreservierung (mittels Polymorphismus) anlegen. Diese Entscheidung
	 * erfolgt \u00fcber den Benutzer, der entweder mit einem "f" oder einem "h",
	 * das jeweilige Verfahren aussuchen kann. Durch den if-Statement wird das
	 * ausgesuchte Verfahren auch angewendet.
	 * 
	 * Diese Methode pr\u00fcft zun\u00e4chst, ob Objekte von der Oberklasse Kunde
	 * in der ArrayListe kundeArrList() existieren, wenn nicht wird der Benutzer
	 * informiert. Au\u00dferdem wird gepr\u00fcft, ob die eingegebene Kundennummer
	 * in der ArrayListe existert. Dadurch wird die Zuordnung gew\u00e4hrleistet.
	 * 
	 * Des Weiteren wird das erstellte Objekt der ArrayListe
	 * kundeInReservierungArrList(), das sich in der Klasse Kunde befindet,
	 * hinzugef\u00fcgt.
	 * 
	 * 
	 * @param magicHolidaysReiseAgentur - nimmt ein Objekt der Klasse Reiseagentur.
	 */
	public void addReservierungAndAssignKundenNummer(ReiseAgentur magicHolidaysReiseAgentur) {
		try {
			Scanner scanner = new Scanner(System.in);
			System.out.println("Bitte geben Sie die Kundennummer ein, welche Sie zuordnen m\u00f6chten: ");
			int inputKundenNr = scanner.nextInt();
			scanner.nextLine();
			if (magicHolidaysReiseAgentur.getKundeArrList().isEmpty()) {
				System.out.println("\nEs existieren weder Privat- noch Gesch\u00e4ftskunden.");
				System.out.println(
						"Bitte legen Sie zun\u00e4chst einen Privat- oder Gesch\u00e4ftskunden an, um Reservierungen zuzuordnen.\n");
			} else {
				for (Kunde kunde : magicHolidaysReiseAgentur.getKundeArrList()) {
					if (inputKundenNr == kunde.getKundenNr()) {
						System.out.println("Wenn es sich um eine Flugreservierung handelt, geben Sie bitte \"f\" ein");
						System.out.println("Wenn es sich um eine Hotelreservierung handelt, geben Sie bitte \"h\" ein");
						String auswahlInput = scanner.nextLine().toLowerCase();
						if (auswahlInput.equals("f")) {
							System.out.println("Flugreservierung!");
							System.out.println("Bitte geben Sie die Reservierungsnummer ein: ");
							int reservierungsNr = scanner.nextInt();
							scanner.nextLine();

							System.out.println("Bitte geben Sie das Datum(yyyy-mm-dd) ein: ");
							String datumInput = scanner.nextLine();
							LocalDate datum = LocalDate.parse(datumInput);

							System.out.println("Bitte geben Sie die Summe ein: ");
							double summe = scanner.nextDouble();
							scanner.nextLine();

							System.out.println("Bitte geben Sie die Flugnummer ein: ");
							int flugNr = scanner.nextInt();
							scanner.nextLine();

							System.out.println("Bitte geben Sie den Abflughafen ein: ");
							String abFlugHafen = scanner.nextLine();

							System.out.println("Bitte geben Sie den Zielflughafen ein: ");
							String zielFlugHafen = scanner.nextLine();

							Reservierung flugReservierung = new FlugReservierung(reservierungsNr, datum, summe, flugNr,
									abFlugHafen, zielFlugHafen);

							kunde.storeKundeMitReservierungToArray(flugReservierung);
							System.out.println(
									"Sie haben erfolgreich eine Flugreservierung mit die Reservierungsnummer: \""
											+ flugReservierung.getReservierungsNr() + "\" angelegt und den Kunden \""
											+ kunde.getVollstaendigerName() + "\" mit der Kundennummer: \""
											+ kunde.getKundenNr() + "\" zugeordnet!");
						} else if (auswahlInput.equals("h")) {
							System.out.println("Bitte geben Sie die Reservierungsnummer ein: ");
							int reservierungsNr = scanner.nextInt();
							scanner.nextLine();

							System.out.println("Bitte geben Sie das Datum(yyyy-mm-dd) ein: ");
							String datumInput = scanner.nextLine();
							LocalDate datum = LocalDate.parse(datumInput);

							System.out.println("Bitte geben Sie die Summe ein: ");
							double summe = scanner.nextDouble();
							scanner.nextLine();

							System.out.println("Bitte geben Sie den Hotelnamen ein: ");
							String hotelName = scanner.nextLine();

							System.out.println("Bitte geben Sie die Reisedauer ein: ");
							String reiseDauer = scanner.nextLine();

							Reservierung hotelReservierung = new HotelReservierung(reservierungsNr, datum, summe,
									hotelName, reiseDauer);

							kunde.storeKundeMitReservierungToArray(hotelReservierung);
							System.out.println(
									"Sie haben erfolgreich eine Hotelreservierung mit die Reservierungsnummer: \""
											+ hotelReservierung.getReservierungsNr() + "\" angelegt und den Kunden \""
											+ kunde.getVollstaendigerName() + "\" mit der Kundennummer: \""
											+ kunde.getKundenNr() + "\" zugeordnet!");
						} else {
							System.out.println("\nUng\u00fcltige Eingaben!");
							System.out.println("Bitte geben Sie entweder ein \"f\" oder ein \"h\" ein.");
							System.out.println("Bitte versuchen Sie es erneut! \n");
							addReservierungAndAssignKundenNummer(magicHolidaysReiseAgentur);
						}
					}
				}
			}
		} catch (InputMismatchException e) {
			System.out.println("\nSie haben anstelle einer \"Zahl\" etwas anderes eingegeben.");
			System.out.println("Bitte versuchen Sie es erneut! \n");
			addReservierungAndAssignKundenNummer(magicHolidaysReiseAgentur);
		} catch (Exception e) {
			System.out.println("\nEs tut uns leid.");
			System.out.println("Ein unerwarteter Fehler ist aufgetreten.");
			System.out.println("Beim wieder auftreten des Problems, bitten wir Sie uns zu kontaktieren, "
					+ "damit wir schnellsm\u00f6glich dieses Problem beheben k\u00f6nnen.");
			System.out.println("Bitte versuchen Sie es erneut.\n");
		}
	}

	/**
	 * Zeigt die Informationen der Oberklasse Kunden, mit der entsprechenden
	 * Informationen der Unterklasse PrivatKunde oder GeschaeftsKunde an. Diese
	 * Entscheidung erfolgt \u00fcber die Eingabe der Kundennummer.
	 * 
	 * Au\u00dferdem werden von der Oberklasse Reservierung, die Unterklassen
	 * Flugreservierung und/oder Hotelreservierung angezeigt.
	 * 
	 * Sollte kein Kunde in der ArrayListe kundeArrList() existieren, wird der
	 * Benutzer informiert. Das gleiche gilt f\u00fcr die ArrayListe
	 * kundeInReservierungArrList().
	 * 
	 * @param magicHolidaysReiseAgentur - nimmt ein Objekt der Klasse Reiseagentur.
	 */
	public void kundeMitReservierungAnzeigenWahlDurchKundenNummer(ReiseAgentur magicHolidaysReiseAgentur) {
		try {
			Scanner scanner = new Scanner(System.in);

			System.out.println("Bitte geben Sie die Kundennummer des Kunde ein: ");
			int auswahlKundenNr = scanner.nextInt();
			scanner.nextLine();

			if (magicHolidaysReiseAgentur.getKundeArrList().isEmpty()) {
				System.out.println("\nEs existieren weder Privat- noch Gesch\u00e4ftskunden.");
				System.out.println(
						"Bitte legen Sie zun\u00e4chst einen Privat- oder Gesch\u00e4ftskunden an, um Kunde mit Reservierungen anzeigen zulassen.\n");
			} else {
				for (Kunde kunde : magicHolidaysReiseAgentur.getKundeArrList()) {
					if (auswahlKundenNr == kunde.getKundenNr()) {
						if (kunde.getKundeInReservierungArrList().isEmpty()) {
							System.out.println("\nEs existieren weder Flug- noch Hotelreservierungen.");
							System.out.println(
									"Bitte legen Sie zun\u00e4chst ein Flug- oder Hotelreservierung an, um Kunde mit Reservierung anzeigen zulassen.\n");
						} else {
							if (kunde instanceof PrivatKunde) {
								PrivatKunde privatKunde = (PrivatKunde) kunde;

								System.out.println("\nInformation zum Kunden");
								System.out.println("Privatkunde\tKundenNr.: " + kunde.getKundenNr() + " | " + "Anrede: "
										+ kunde.getAnrede() + " | " + "Vorname: " + kunde.getVorname() + " | "
										+ "Nachname: " + kunde.getNachname() + " | " + "Vollst\u00e4ndiger Name: "
										+ kunde.getVollstaendigerName() + " | " + "Geburtsdatum: "
										+ kunde.getGeburtsDatum() + "\n\t\t" + "Email: " + kunde.getEmailAdresse()
										+ " | " + "TelefonNr.: " + kunde.getTelefonNr());

								System.out.println("\nAdresse des Kunden");
								System.out.println("\t\tStra\u00dfe: " + kunde.getAdresse().getStrasse() + " | "
										+ "HausNr.: " + kunde.getAdresse().getHausNr() + " | " + "PLZ: "
										+ kunde.getAdresse().getPlz() + " | " + "Ort: " + kunde.getAdresse().getOrt());

							} else if (kunde instanceof GeschaeftsKunde) {
								GeschaeftsKunde geschaeftsKunde = (GeschaeftsKunde) kunde;

								System.out.println("\nInformation zum Kunden");
								System.out.println("Gesch\u00e4ftskunde\t" + "KundenNr.: " + kunde.getKundenNr() + " | "
										+ "Firmenname: " + geschaeftsKunde.getFirmenName() + " | " + "Anrede: "
										+ kunde.getAnrede() + " | " + "Vorname: " + kunde.getVorname() + " | "
										+ "Nachname: " + kunde.getNachname() + " | " + "Vollst\u00e4ndiger Name: "
										+ kunde.getVollstaendigerName() + " | " + "Geburtsdatum: "
										+ kunde.getGeburtsDatum() + "\n\t\t" + "Email: " + kunde.getEmailAdresse()
										+ " | " + "TelefonNr.: " + kunde.getTelefonNr());

								System.out.println("\nAdresse des Kunden");
								System.out.println("\t\tStra\u00dfe: " + kunde.getAdresse().getStrasse() + " | "
										+ "HausNr.: " + kunde.getAdresse().getHausNr() + " | " + "PLZ: "
										+ kunde.getAdresse().getPlz() + " | " + "Ort: " + kunde.getAdresse().getOrt());

							}
							System.out.println("\nReservierungen des Kunden");
							for (Reservierung reservierung : kunde.getKundeInReservierungArrList()) {
								if (reservierung instanceof FlugReservierung) {
									FlugReservierung flugReservierung = (FlugReservierung) reservierung;
									System.out.println("Flugreservierung\t" + "ReservierungsNr.: "
											+ flugReservierung.getReservierungsNr() + " | " + "Datum: "
											+ flugReservierung.getDatum() + " | " + "Summe: "
											+ flugReservierung.getSumme() + " | " + "FlugNr.: "
											+ flugReservierung.getFlugNr() + " | " + "Abflughafen: "
											+ flugReservierung.getAbFlugHafen() + " | " + "Zielflughafen: "
											+ flugReservierung.getZielFlugHafen());
								}
								if (reservierung instanceof HotelReservierung) {
									HotelReservierung hotelReservierung = (HotelReservierung) reservierung;
									System.out.println("Hotelreservierung\t" + "ReservierungsNr.: "
											+ hotelReservierung.getReservierungsNr() + " | " + "Datum: "
											+ hotelReservierung.getDatum() + " | " + "Summe: "
											+ hotelReservierung.getSumme() + " | " + "Hotelname: "
											+ hotelReservierung.getHotelName() + " | " + "Reisedauer: "
											+ hotelReservierung.getReiseDauer());
								}
							}
						}
					}
				}
			}
		} catch (InputMismatchException e) {
			System.out.println("\nSie haben anstelle einer \"Zahl\" etwas anderes eingegeben.");
			System.out.println("Bitte versuchen Sie es erneut! \n");
			kundeMitReservierungAnzeigenWahlDurchKundenNummer(magicHolidaysReiseAgentur);
		} catch (Exception e) {
			System.out.println("\nEs tut uns leid.");
			System.out.println("Ein unerwarteter Fehler ist aufgetreten.");
			System.out.println("Beim wieder auftreten des Problems, bitten wir Sie uns zu kontaktieren, "
					+ "damit wir schnellsm\u00f6glich dieses Problem beheben k\u00f6nnen.");
			System.out.println("Bitte versuchen Sie es erneut.\n");
		}
	}

	/**
	 * Zeigt die Informationen der Oberklasse Kunden, mit der entsprechenden
	 * Informationen der Unterklasse PrivatKunde oder GeschaeftsKunde an. Diese
	 * Entscheidung erfolgt \u00fcber die Eingabe des Nachnamens.
	 * 
	 * Au\u00dferdem werden von der Oberklasse Reservierung, die Unterklassen
	 * Flugreservierung und/oder Hotelreservierung angezeigt.
	 * 
	 * Sollte kein Kunde in der ArrayListe kundeArrList() existieren, wird der
	 * Benutzer informiert. Das gleiche gilt f\u00fcr die ArrayListe
	 * kundeInReservierungArrList().
	 * 
	 * @param magicHolidaysReiseAgentur - nimmt ein Objekt der Klasse Reiseagentur.
	 */
	public void kundeMitReservierungAnzeigenWahlDurchName(ReiseAgentur magicHolidaysReiseAgentur) {
		try {
			Scanner scanner = new Scanner(System.in);

			System.out.println("Bitte geben Sie den Nachnamen des Kunden ein: ");
			String kundeNameInput = scanner.nextLine().toLowerCase();

			if (magicHolidaysReiseAgentur.getKundeArrList().isEmpty()) {
				System.out.println("\nEs existieren weder Privat- noch Gesch\u00e4ftskunden.");
				System.out.println(
						"Bitte legen Sie zun\u00e4chst einen Privat- oder Gesch\u00e4ftskunden an, um Kunde mit Reservierungen anzeigen zulassen.\n");
			} else {
				for (Kunde kunde : magicHolidaysReiseAgentur.getKundeArrList()) {
					if (kunde.getNachname().toLowerCase().equals(kundeNameInput)) {
						if (kunde.getKundeInReservierungArrList().isEmpty()) {
							System.out.println("\nEs existieren weder Flug- noch Hotelreservierungen.");
							System.out.println(
									"Bitte legen Sie zun\u00e4chst ein Flug- oder Hotelreservierung an, um Kunde mit Reservierung anzeigen zulassen.\n");
						} else {
							if (kunde instanceof PrivatKunde) {
								PrivatKunde privatKunde = (PrivatKunde) kunde;
								System.out.println("\nInformation zum Kunden");
								System.out.println("Privatkunde\tKundenNr.: " + privatKunde.getKundenNr() + " | "
										+ "Anrede: " + privatKunde.getAnrede() + " | " + "Vorname: "
										+ privatKunde.getVorname() + " | " + "Nachname: " + privatKunde.getNachname()
										+ " | " + "Vollst\u00e4ndiger Name: " + privatKunde.getVollstaendigerName()
										+ " | " + "Geburtsdatum: " + privatKunde.getGeburtsDatum() + "\n\t\t"
										+ "Email: " + privatKunde.getEmailAdresse() + " | " + "TelefonNr.: "
										+ privatKunde.getTelefonNr());
								System.out.println("\nAdresse des Kunden");
								System.out.println("\t\tStra\u00dfe: " + privatKunde.getAdresse().getStrasse() + " | "
										+ "HausNr.: " + privatKunde.getAdresse().getHausNr() + " | " + "PLZ: "
										+ privatKunde.getAdresse().getPlz() + " | " + "Ort: "
										+ privatKunde.getAdresse().getOrt());

							} else if (kunde instanceof GeschaeftsKunde) {
								GeschaeftsKunde geschaeftsKunde = (GeschaeftsKunde) kunde;

								System.out.println("\nInformation zum Kunden");
								System.out.println("Gesch\u00e4ftskunde\t" + "KundenNr.: " + kunde.getKundenNr() + " | "
										+ "Firmenname: " + geschaeftsKunde.getFirmenName() + " | " + "Anrede: "
										+ kunde.getAnrede() + " | " + "Vorname: " + kunde.getVorname() + " | "
										+ "Nachname: " + kunde.getNachname() + " | " + "Vollst\u00e4ndiger Name: "
										+ kunde.getVollstaendigerName() + " | " + "Geburtsdatum: "
										+ kunde.getGeburtsDatum() + "\n\t\t" + "Email: " + kunde.getEmailAdresse()
										+ " | " + "TelefonNr.: " + kunde.getTelefonNr());

								System.out.println("\nAdresse des Kunden");
								System.out.println("\t\tStra\u00dfe: " + kunde.getAdresse().getStrasse() + " | "
										+ "HausNr.: " + kunde.getAdresse().getHausNr() + " | " + "PLZ: "
										+ kunde.getAdresse().getPlz() + " | " + "Ort: " + kunde.getAdresse().getOrt());

							}
							System.out.println("\nReservierung des Kunden");
							for (Reservierung reservierung : kunde.getKundeInReservierungArrList()) {
								if (reservierung instanceof FlugReservierung) {
									FlugReservierung flugReservierung = (FlugReservierung) reservierung;
									System.out.println("Flugreservierung\t" + "ReservierungsNr.: "
											+ flugReservierung.getReservierungsNr() + " | " + "Datum: "
											+ flugReservierung.getDatum() + " | " + "Summe: "
											+ flugReservierung.getSumme() + " | " + "FlugNr.: "
											+ flugReservierung.getFlugNr() + " | " + "Abflughafen: "
											+ flugReservierung.getAbFlugHafen() + " | " + "Zielflughafen: "
											+ flugReservierung.getZielFlugHafen());

								} else if (reservierung instanceof HotelReservierung) {
									HotelReservierung hotelReservierung = (HotelReservierung) reservierung;
									System.out.println("Hotelreservierung\t" + "ReservierungsNr.: "
											+ hotelReservierung.getReservierungsNr() + " | " + "Datum: "
											+ hotelReservierung.getDatum() + " | " + "Summe: "
											+ hotelReservierung.getSumme() + " | " + "Hotelname: "
											+ hotelReservierung.getHotelName() + " | " + "Reisedauer: "
											+ hotelReservierung.getReiseDauer());
								}
							}
						}
					}
				}
			}
		} catch (InputMismatchException e) {
			System.out.println("\nSie haben anstelle einer \"Zahl\" etwas anderes eingegeben.");
			System.out.println("Bitte versuchen Sie es erneut! \n");
			kundeMitReservierungAnzeigenWahlDurchName(magicHolidaysReiseAgentur);
		} catch (Exception e) {
			System.out.println("\nEs tut uns leid.");
			System.out.println("Ein unerwarteter Fehler ist aufgetreten.");
			System.out.println("Beim wieder auftreten des Problems, bitten wir Sie uns zu kontaktieren, "
					+ "damit wir schnellsm\u00f6glich dieses Problem beheben k\u00f6nnen.");
			System.out.println("Bitte versuchen Sie es erneut.\n");
			System.out.println(e);
		}
	}

	/**
	 * Zeigt die Information der Oberklasse Reservierung, mit den Unterklassen(falls
	 * vorhanden) Flugreservierung oder Hotelreservierung an. Diese Entscheidung
	 * erfolgt \u00fcber die Eingabe der Reservierungsnummer.
	 * 
	 * Sollte kein Kunde in der ArrayListe kundeArrList() existieren, wird der
	 * Benutzer informiert. Das gleiche gilt f\u00fcr die ArrayListe
	 * kundeInReservierungArrList().
	 * 
	 * @param magicHolidaysReiseAgentur - nimmt ein Objekt der Klasse Reiseagentur.
	 */
	public void reservierungAnzeigenWahlDurchReservierungsNummer(ReiseAgentur magicHolidaysReiseAgentur) {
		try {
			Scanner scanner = new Scanner(System.in);

			System.out.println("Bitte geben Sie die Reservierungsnummer ein: ");
			int reservierungsNr = scanner.nextInt();
			scanner.nextLine();
			System.out.println("\nInformation zur Reservierung");
			if (magicHolidaysReiseAgentur.getKundeArrList().isEmpty()) {
				System.out.println("\nEs existieren weder Privat- noch Gesch\u00e4ftskunden.");
				System.out.println(
						"Bitte legen Sie zun\u00e4chst einen Privat- oder Gesch\u00e4ftskunden an, um Kunde mit Reservierungen anzeigen zulassen.\n");
			} else {
				for (Kunde kunde : magicHolidaysReiseAgentur.getKundeArrList()) {
					if (kunde.getKundeInReservierungArrList().isEmpty()) {
						System.out.println("\nEs existieren weder Flug- noch Hotelreservierungen f\u00fcr den Kunden \""
								+ kunde.getVollstaendigerName() + "\"");
						System.out.println(
								"Bitte legen Sie zun\u00e4chst ein Flug- oder Hotelreservierung an, um den Kunde \""
										+ kunde.getVollstaendigerName() + "\" mit Reservierung anzeigen zulassen.\n");
					} else {
						for (Reservierung reservierung : kunde.getKundeInReservierungArrList()) {
							if (reservierungsNr == reservierung.getReservierungsNr()) {
								if (reservierung instanceof FlugReservierung) {
									FlugReservierung flugReservierung = (FlugReservierung) reservierung;
									System.out.println("Flugreservierung\t" + "ReservierungsNr.: "
											+ flugReservierung.getReservierungsNr() + " | " + "Datum: "
											+ flugReservierung.getDatum() + " | " + "Summe: "
											+ flugReservierung.getSumme() + " | " + "FlugNr.: "
											+ flugReservierung.getFlugNr() + " | " + "Abflughafen: "
											+ flugReservierung.getAbFlugHafen() + " | " + "Zielflughafen: "
											+ flugReservierung.getZielFlugHafen());

								} else if (reservierung instanceof HotelReservierung) {
									HotelReservierung hotelReservierung = (HotelReservierung) reservierung;
									System.out.println("Hotelreservierung\t" + "ReservierungsNr.: "
											+ hotelReservierung.getReservierungsNr() + " | " + "Datum: "
											+ hotelReservierung.getDatum() + " | " + "Summe: "
											+ hotelReservierung.getSumme() + " | " + "Hotelname: "
											+ hotelReservierung.getHotelName() + " | " + "Reisedauer: "
											+ hotelReservierung.getReiseDauer());
								}
							}
						}
					}
				}
			}
		} catch (InputMismatchException e) {
			System.out.println("\nSie haben anstelle einer \"Zahl\" etwas anderes eingegeben.");
			System.out.println("Bitte versuchen Sie es erneut! \n");
			reservierungAnzeigenWahlDurchReservierungsNummer(magicHolidaysReiseAgentur);
		} catch (Exception e) {
			System.out.println("\nEs tut uns leid.");
			System.out.println("Ein unerwarteter Fehler ist aufgetreten.");
			System.out.println("Beim wieder auftreten des Problems, bitten wir Sie uns zu kontaktieren, "
					+ "damit wir schnellsm\u00f6glich dieses Problem beheben k\u00f6nnen.");
			System.out.println("Bitte versuchen Sie es erneut.\n");
		}
	}

	/**
	 * Sortiert die ArrayListe der Kunden. Gibt die die sortierte Liste der Kunden
	 * wieder.
	 * 
	 * @param magicHolidaysReiseAgentur - nimmt ein Objekt der Klasse Reiseagentur.
	 */
	public void alleKundenSortiertAnzeigen(ReiseAgentur magicHolidaysReiseAgentur) {
		Collections.sort(magicHolidaysReiseAgentur.getKundeArrList(), new KundenComparator());
		System.out.println("\n");
		for (Kunde kunde : magicHolidaysReiseAgentur.getKundeArrList()) {
			System.out.println(kunde.getVorname() + " " + kunde.getNachname());
		}

	}

	/**
	 * Sortiert den Map absteigend der Anzahl an BezahlMethoden. Iteriert
	 * au\u00dferdem durch den Hashmap und gibt den Key sowie den Value wieder.
	 * 
	 * @param magicHolidaysReiseAgentur - nimmt ein Objekt der Klasse Reiseagentur.
	 */
	public void bezahlMethodeSortiertAnzeigen(ReiseAgentur magicHolidaysReiseAgentur) {
		Set<Entry<String, Integer>> BezahlMethodeMapToSet = magicHolidaysReiseAgentur.getAnzahlBezahlMethodeMap()
				.entrySet();
		List<Entry<String, Integer>> sortedBezahlMethode = new ArrayList<Map.Entry<String, Integer>>(
				BezahlMethodeMapToSet);

		Collections.sort(sortedBezahlMethode, new BezahlMethodeComparator());

		for (Entry<String, Integer> entry : sortedBezahlMethode) {
			System.out.println(entry.getKey() + " | " + entry.getValue());
		}

	}

	/**
	 * Iteriert durch den LinkedHashMap und gibt den Key and den jeweiligen Value
	 * wieder.
	 * 
	 * @param magicHolidaysReiseAgentur - nimmt ein Objekt der Klasse Reiseagentur.
	 */
	public void alleReservierungenSortiertAnzeigen(ReiseAgentur magicHolidaysReiseAgentur) {
		magicHolidaysReiseAgentur.storeSortedReservierungInIndex();
		for (Map.Entry<LocalDate, Set<Reservierung>> a : magicHolidaysReiseAgentur.getReservierungsIndex().entrySet())
			System.out.println(a.getKey() + " | " + a.getValue());

	}

	/**
	 * Die Methode exportData() f\u00fchrt die Methoden im util Paket, der Klasse
	 * IOUtils aus. Als erstes wird der Dateipfad gefragt, danach wird dies der 2
	 * Methode \u00fcbergeben.
	 * 
	 * @param magicHolidaysReiseAgentur als parameter.
	 */
	public void exportData(ReiseAgentur magicHolidaysReiseAgentur) {
		String filePath = IOUtils.filePath();
		boolean result = IOUtils.exportData(magicHolidaysReiseAgentur, filePath);
		System.out.println("Der Export hat " + (result ? "" : "nicht ") + "funktioniert.");
	}

	/**
	 * Die importData() Methode f\u00fchrt die Methoden des IOUtils aus und ersetzt
	 * die private static deklarierte Variable.
	 */
	public void importData() {
		magicHolidaysReiseAgentur = IOUtils.importData();
		System.out.println("Der Import hat " + (magicHolidaysReiseAgentur != null ? "" : "nicht ") + "funktioniert.");
	}

	/**
	 * Es f\u00fchrt 2 Methoden der Klasse IOUtils aus. Die erste sorgt f\u00fcr die
	 * Abfrage des Dateipfades und die wird der 2.Methode \u00fcbergeben.
	 * 
	 * @param magicHolidaysReiseAgentur als parameter.
	 */
	public void exportSortedKundeAsCsv(ReiseAgentur magicHolidaysReiseAgentur) {
		String filePath = IOUtils.filePath();
		IOUtils.exportSortedKundeAsCsv(magicHolidaysReiseAgentur, filePath);
	}

	/**
	 * Es wird ein Objekt der Klasse Auditing erstellt. Es wird durch die Array
	 * Liste iteriert und jede Zahlung wird wiedergegeben.
	 */
	public void showAuditList() {
		Auditing audit = Auditing.getInstance();

		if (audit.getZahlungAuditList().isEmpty()) {
			System.out.println(
					"Bitte fuehren Sie zuerst einige Checkouts(Menuepunkt: 13) durch, um die Liste anzuzeigen.");
		} else {

			for (Zahlung zahlung : audit.getZahlungAuditList()) {
				System.out.println("Bezahlmethode: " + zahlung.toString(zahlung.getBezahlMethode()) + " | Betrag: "
						+ zahlung.getBetrag());
			}
		}

	}

	/**
	 * Es erstellt ein Objekt der Klasse Buchhaltung. Es wird durch die Array Liste
	 * iteriert und jede Zahlung wird wiedergegeben.
	 */
	public void showBuchhaltungsListe() {
		Buchhaltung buchhaltung = Buchhaltung.getInstance();
		if (buchhaltung.getZahlungBuchHaltungList().isEmpty()) {
			System.out.println(
					"Bitte fuehren Sie zuerst einige Checkouts(Menuepunkt: 13) durch, um die Liste anzuzeigen.");
		} else {

			for (Zahlung zahlung : buchhaltung.getZahlungBuchHaltungList()) {
				System.out.println("Bezahlmethode: " + zahlung.toString(zahlung.getBezahlMethode()) + " | Betrag: "
						+ zahlung.getBetrag());
			}
		}

	}

	/**
	 * Diese Methode iteriert durch die Array Liste der Kunden und dann nochmals
	 * durch die Array Liste der Reservierungen der Kunden. Durch die Eingabe des
	 * Nutzers wird gepr\u00fcft, ob die Reservierung \u00fcbereinstimmen. Da durch
	 * wird gew\u00e4hrleistet, dass die Summe in HotelReservierung und die Summe in
	 * FlugReservierung zusammen gerechnet werden.
	 * 
	 * Die Summe wird dem checkOutMenue() weitergegeben.
	 */
	public void reservierungCheckOut() {
		try {
			Scanner scanner = new Scanner(System.in);
			double totalSumme = 0;

			System.out.println("Bitte geben Sie die Reservierungsnummer ein: ");
			int reservierungsNrInput = scanner.nextInt();
			scanner.nextLine();

			Kasse kasse = Kasse.getInstance();

			for (Kunde kunde : magicHolidaysReiseAgentur.getKundeArrList()) {
				for (Reservierung reservierung : kunde.getKundeInReservierungArrList()) {
					if (reservierung.getReservierungsNr() == reservierungsNrInput) {
						if (reservierung instanceof FlugReservierung) {
							totalSumme = reservierung.getSumme();
						}
						if (reservierung instanceof HotelReservierung) {
							totalSumme += reservierung.getSumme();
						}

					}
				}

			}

			System.out.println("Wie soll die Summe " + totalSumme + " Euro der Reservierung " + reservierungsNrInput
					+ " bezahlt werden?");
			checkOutMenue(totalSumme);
		} catch (Exception e) {
			System.out.println("\nLeider haben Sie eine falsche Reservierungsnummer eingegeben.");
			System.out.println("Versuchen Sie es erneut.\n");
			reservierungCheckOut();
		}

	}

	/**
	 * Stellt die Men\u00fc Oberfl\u00e4che f\u00fcr den Reservierung Checkout
	 * bereit. Au\u00dferdem werden die Eingabe "bezahlungChoice" und der "betrag",
	 * welches von dem Parameter weitergegeben wird, in der Methode "bezahlen()",
	 * das sich in der Klasse Kasse befindet, weitergegeben.
	 * 
	 * @param betrag - wird von der Methode "reservierungCheckOut()" weitergegeben
	 */
	public void checkOutMenue(double betrag) {
		try {
			Scanner scanner = new Scanner(System.in);

			Kasse kasse = Kasse.getInstance();

			String[] checkOutMenueList = { "1. Kreditkarte", "2. ECKarte", "3. Rechnung", "4. Zurueck" };
			for (int i = 0; i < checkOutMenueList.length; i++) {
				System.out.println(checkOutMenueList[i]);
			}

			System.out.println("\nBezahlmethode: ");

			int bezahlungChoice = scanner.nextInt();
			kasse.bezahlen(bezahlungChoice, betrag);
		} catch (Exception e) {
			System.out.println("\nBitte geben Sie eine Zahl zwischen 1-4 ein.");
			System.out.println("Versuchen Sie es erneut.\n");
			checkOutMenue(betrag);
		}

	}

}
