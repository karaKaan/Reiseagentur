package klassen;

import starter.Starter;

/**
 * Die Klasse Kasse erm\u00f6glicht es den Kunden, die Bezahlungen
 * durchzuf\u00fchren
 * 
 * @author S0560885 Kaan Kara
 * @eclipseVersion 2019-09 R (4.13.0)
 * @javaVersion 12
 * @runTime 33
 * @erstellungsDatum 21.10.2019
 * @letzte\u00c4nderungsDatum 10.01.2020
 *
 */
public class Kasse {
	private static Kasse kasse = null;
	

	/**
	 * Der Konstruktor wird ben\u00f6tigt, um ein Objekt der Klasse Kasse zu
	 * erstellen.
	 * 
	 */
	public Kasse() {

	}

	/**
	 * Erstellt ein Objekt der Klasse Kasse, wenn sie nicht schon erstellt wurde.
	 * Wenn das Objekt schon erstellt ist, wird dieser referenziert.
	 */
	public static Kasse getInstance() {
		if (kasse == null) {
			kasse = new Kasse();

		}

		return kasse;
	}

	/**
	 * Besitzt eine Switch-Case Anweisung, damit der Nutzer eine Art der Bezahlung
	 * ausw\u00e4hlen kann. Die jeweilige Klasse die, das Interface IBezahlStrategie
	 * implementiert hat wird erstellt.
	 * 
	 * Hier erfolgt ebenfalls die Benachrichtigung, bei erfolgreicher Einzahlung.
	 * 
	 * Der "betrag" und das erstellte Objekt wird der Methode "ordneBezahlung()"
	 * weitergegeben.
	 * 
	 * @param key
	 * @param betrag
	 */
	public void bezahlen(int key, double betrag) {
		switch (key) {
		case 1:
			KreditKarte kreditKarte = new KreditKarte("Kreditkarte");
			kreditKarte.zahlen(betrag);
			String kreditKarteMessage = kreditKarte.checkOutMessage(kreditKarte.getArtDesBezahlens(), betrag);
			System.out.println(kreditKarteMessage);
			this.ordneBezahlung(betrag, kreditKarte);
			break;
		case 2:
			ECKarte ecKarte = new ECKarte("ECKarte");
			ecKarte.zahlen(betrag);
			String ecKarteMessage = ecKarte.checkOutMessage(ecKarte.getArtDesBezahlens(), betrag);
			System.out.println(ecKarteMessage);
			this.ordneBezahlung(betrag, ecKarte);
			break;
		case 3:
			Rechnung rechnung = new Rechnung("Rechnung");
			rechnung.zahlen(betrag);
			String rechnungMessage = rechnung.checkOutMessage(rechnung.getArtDesBezahlens(), betrag);
			System.out.println(rechnungMessage);
			this.ordneBezahlung(betrag, rechnung);
			break;
		case 4:
			new Starter().reservierungCheckOut();
			break;
		default:
			System.out.println("Sie haben etwas anderes eingegeben, als die Zahlen 1 bis 4.");
			System.out.println("Bitte versuchen Sie es erneut.\n");
			new Starter().checkOutMenue(betrag);
			break;
		}
	}

	/**
	 * Es wird gepr\u00fcft, ob der weitergereichte "betrag" unter oder gleich 1000
	 * ist, wenn ja soll die Klasse Buchhaltung instanziiert werden. Die Buchhaltung
	 * wird der Methode "addObserver()" weitergegeben, welches sich in der Klasse
	 * Zahlung befindet. Die Variable "zahlung" und "betrag" werden der Methode
	 * "notifyObserver()" weitergegeben.
	 * 
	 * Analog dazu passiert das gleiche, wenn die Variable "betrag" um \u00fcber
	 * 1000 ist. Es wird ein Objekt der Klasse Auditing instanziiert und in die
	 * Methoden weitergegeben.
	 * 
	 * @param betrag
	 * @param bezahlMethode
	 */
	public void ordneBezahlung(double betrag, IBezahlStrategie bezahlMethode) {
		if (betrag <= 1000) {
			Zahlung zahlung = new Zahlung(betrag, bezahlMethode);
			Buchhaltung buchHaltung = Buchhaltung.getInstance();
			zahlung.addObserver(buchHaltung);
			zahlung.notifyObserver(zahlung, betrag);
		} else {
			Zahlung zahlung = new Zahlung(betrag, bezahlMethode);
			Auditing audit = Auditing.getInstance();
			zahlung.addObserver(audit);
			zahlung.notifyObserver(zahlung, betrag);
		}
	}

}
