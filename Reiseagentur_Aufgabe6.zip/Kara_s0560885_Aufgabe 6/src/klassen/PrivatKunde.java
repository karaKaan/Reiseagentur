package klassen;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Die Klasse PrivatKunde erbt von der abstrakten Klasse Kunde. Durch diese
 * Klasse, kann man ein Objekt der Klasse PrivatKunden erstellen.
 * 
 * 
 * @author S0560885 Kaan Kara
 * @eclipseVersion 2019-09 R (4.13.0)
 * @javaVersion 12
 * @runTime 33
 * @erstellungsDatum 21.10.2019
 * @letzte\u00c4nderungsDatum 07.12.2019
 *
 */
public class PrivatKunde extends Kunde implements Serializable {

	/**
	 * Die Signatur des Konstruktors muss erf\u00fcllt werden, damit ein Objekt der
	 * Klasse Adresse entstehen kann. Daf\u00fcr m\u00fcssen die Parameter(siehe
	 * unten) vollst\u00e4ndig ausgef\u00fcllt werden.
	 * 
	 * @param kundenNr                         wird ben\u00f6tigt.
	 * @param anrede                           wird ben\u00f6tigt.
	 * @param vornamen                         wird ben\u00f6tigt.
	 * @param nachnamen                        wird ben\u00f6tigt.
	 * @param emailAdresse                     wird ben\u00f6tigt.
	 * @param telefonNr                        wird ben\u00f6tigt.
	 * @param geburtsDatum                     wird ben\u00f6tigt.
	 * @param privateAdresse                   wird ben\u00f6tigt.
	 * @param bezahlMethodeF\u00fcrPrivatKunde wird ben\u00f6tigt.
	 */
	public PrivatKunde(int kundenNr, String anrede, String vorname, String nachname, String emailAdresse,
			String telefonNr, LocalDate geburtsDatum) {
		super(kundenNr, anrede, vorname, nachname, emailAdresse, telefonNr, geburtsDatum);

	}

	@Override
	public void getName() {
		super.setVollstaendigerName(this.getVorname() + " " + this.getNachname());
	}

}
