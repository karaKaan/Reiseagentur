package klassen;

import java.io.Serializable;
import java.util.Scanner;

/***
 * 
 * Die Klasse Adresse ist Vorrausetzung, dass ein Objekt der Klasse Adresse
 * angelegt werden kann.
 * 
 * @author S0560885 Kaan Kara
 * @eclipseVersion 2019-09 R (4.13.0)
 * @javaVersion 12
 * @runTime 33
 * @erstellungsDatum 21.10.2019
 * @letzte\u00c4nderungsDatum 07.12.2019
 * 
 */

public class Adresse implements Serializable {

	/**
	 * Die Klasse Adresse hat die Variablen String strasse, String hausNr, int plz
	 * und String ort. Die Variablen sind alle private.
	 */
	transient Scanner scanner = new Scanner(System.in);
	private String strasse;
	private String hausNr;
	private int plz;
	private String ort;

	/**
	 * Die Signatur des Konstruktors muss erf\u00fcllt werden, damit ein Objekt der
	 * Klasse Adresse entstehen kann. Daf\u00fcr m\u00fcssen die Parameter(siehe
	 * unten) vollst\u00e4ndig ausgef\u00fcllt werden.
	 * 
	 * @param strasse wird ben\u00f6tigt.
	 * @param hausNr  wird ben\u00f6tigt.
	 * @param plz     wird ben\u00f6tigt.
	 * @param ort     wird ben\u00f6tigt.
	 */
	public Adresse(String strasse, String hausNr, int plz, String ort) {
		super();
		this.strasse = strasse;
		this.hausNr = hausNr;
		this.plz = plz;
		this.ort = ort;
	}

	/**
	 * Gibt die Variable strasse zur\u00fcck.
	 * 
	 * @return strasse wird zur\u00fcckgegeben.
	 */
	public String getStrasse() {
		return strasse;
	}

	/**
	 * Legt die Variable strasse an.
	 * 
	 * @param strasse wird ben\u00f6tigt.
	 */
	public void setStrasse(String strasse) {
		this.strasse = strasse;
	}

	/**
	 * Gibt die Variable hausNr zur\u00fcck.
	 * 
	 * @return hausNr wird zur\u00fcckgegeben.
	 */
	public String getHausNr() {
		return hausNr;
	}

	/**
	 * Legt die Variable hausNr an.
	 * 
	 * @param hausNr wird ben\u00f6tigt.
	 */
	public void setHausNr(String hausNr) {
		this.hausNr = hausNr;
	}

	/**
	 * Gibt die Variable plz zur\u00fcck.
	 * 
	 * @return plz wird zur\u00fcckgegeben.
	 */
	public int getPlz() {
		return plz;
	}

	/**
	 * Legt die Variable plz an.
	 * 
	 * @param plz wird ben\u00f6tigt.
	 */
	public void setPlz(int plz) {
		this.plz = plz;
	}

	/**
	 * Gibt die Variable ort zur\u00fcck.
	 * 
	 * @return ort wird zur\u00fcckgegeben.
	 */
	public String getOrt() {
		return ort;
	}

	/**
	 * Legt die Variable ort an.
	 * 
	 * @param ort wird ben\u00f6tigt.
	 */
	public void setOrt(String ort) {
		this.ort = ort;
	}
}
