package klassen;

/**
 * Das Interface definiert die Methoden vor.
 * 
 * @author S0560885 Kaan Kara
 * @eclipseVersion 2019-09 R (4.13.0)
 * @javaVersion 12
 * @runTime 33
 * @erstellungsDatum 21.10.2019
 * @letzte\u00c4nderungsDatum 10.01.2020
 *
 */
public interface IBezahlStrategie {
	/**
	 * Die Methode nimmt die Variable "betrag" und gibt es weiter.
	 * 
	 * @param betrag
	 * @return betrag
	 */
	double zahlen(double betrag);

	/**
	 * Diese Methode gibt eine Benachrichtung an den Nutzer, bei erfolgreicher
	 * Einzahlung.
	 * 
	 * @param bezeichnung
	 * @param betrag
	 * @return einen String, bei erfolgreicher Einzahlung.
	 */
	String checkOutMessage(String bezeichnung, double betrag);

}
