package klassen;

import java.util.ArrayList;
import java.util.List;

/**
 * Die Klasse Buchhaltung implementiert das Interface IObserver.
 * 
 * @author S0560885 Kaan Kara
 * @eclipseVersion 2019-09 R (4.13.0)
 * @javaVersion 12
 * @runTime 33
 * @erstellungsDatum 21.10.2019
 * @letzte\u00c4nderungsDatum 10.01.2020
 *
 */
public class Buchhaltung implements IObserver {
	private static Buchhaltung buchhaltung = null;
	private List<Zahlung> zahlungBuchHaltungList;

	/**
	 * Der Konstruktor instanziiert nur die ArrayListe.
	 */
	public Buchhaltung() {
		this.zahlungBuchHaltungList = new ArrayList<Zahlung>();

	}

	/**
	 * Es erstellt ein Objekt der Klasse Buchhaltung, wenn es null ist. Ansonsten
	 * wird der schon erstellte Objekt referenziert.
	 * 
	 * @return die static Variable "buchhaltung".
	 */
	public static Buchhaltung getInstance() {
		if (buchhaltung == null) {
			buchhaltung = new Buchhaltung();

		}

		return buchhaltung;
	}

	@Override
	public void updateObserver(Zahlung zahlung, double betrag) {
		zahlungBuchHaltungList.add(zahlung);

	}

	/**
	 * @return gibt zahlungBuchHaltungList wieder.
	 */
	public List<Zahlung> getZahlungBuchHaltungList() {
		return zahlungBuchHaltungList;
	}

	/**
	 * @param zahlungBuchHaltungList wird gesetzt.
	 */
	public void setZahlungBuchHaltungList(List<Zahlung> zahlungBuchHaltungList) {
		this.zahlungBuchHaltungList = zahlungBuchHaltungList;
	}

}
