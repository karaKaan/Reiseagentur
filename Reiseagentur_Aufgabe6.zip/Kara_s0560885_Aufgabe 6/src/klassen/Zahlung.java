package klassen;

import java.util.ArrayList;
import java.util.List;

/**
 * Die Klasse Zahlung implementiert das Interface IObservable.
 * 
 * @author S0560885 Kaan Kara
 * @eclipseVersion 2019-09 R (4.13.0)
 * @javaVersion 12
 * @runTime 33
 * @erstellungsDatum 21.10.2019
 * @letzte\u00c4nderungsDatum 10.01.2020
 *
 */
public class Zahlung implements IObservable {
	private double betrag;
	private IBezahlStrategie bezahlMethode;

	private List<IObserver> observerArrList = new ArrayList<IObserver>();

	/**
	 * Erstellt ein Objekt der Klasse Zahlung. Daf\u00fcr sind die Parameter
	 * "betrag" und "bezahlMethode" notwendig.
	 * 
	 * @param betrag        wird ben\u00f6tigt.
	 * @param bezahlMethode wird ben\u00f6tigt.
	 */
	public Zahlung(double betrag, IBezahlStrategie bezahlMethode) {
		super();
		this.setBetrag(betrag);
		this.setBezahlMethode(bezahlMethode);
	}

	@Override
	public void addObserver(IObserver observer) {
		this.observerArrList.add(observer);

	}

	@Override
	public void removeObserver(IObserver observer) {
		this.observerArrList.remove(observer);

	}

	@Override
	public void notifyObserver(Zahlung zahlung, double betrag) {
		for (IObserver observer : observerArrList) {
			observer.updateObserver(zahlung, betrag);
		}

	}

	public String toString(IBezahlStrategie bezahlMethode) {
		String artDesBezahlens;
		if (bezahlMethode instanceof KreditKarte) {
			artDesBezahlens = ((KreditKarte) bezahlMethode).getArtDesBezahlens();
			return artDesBezahlens;
		}
		if (bezahlMethode instanceof ECKarte) {
			artDesBezahlens = ((ECKarte) bezahlMethode).getArtDesBezahlens();
			return artDesBezahlens;
		}
		if (bezahlMethode instanceof Rechnung) {
			artDesBezahlens = ((Rechnung) bezahlMethode).getArtDesBezahlens();
			return artDesBezahlens;
		}
		return "Zahlung [bezahlMethode=" + bezahlMethode + "]";
	}

	/**
	 * @return gibt betrag wieder.
	 */
	public double getBetrag() {
		return betrag;
	}

	/**
	 * @param setzt betrag ein.
	 */
	public void setBetrag(double betrag) {
		this.betrag = betrag;
	}

	/**
	 * @return gibt bezahlMethode wieder.
	 */
	public IBezahlStrategie getBezahlMethode() {
		return bezahlMethode;
	}

	/**
	 * @param setzt bezahlMethode ein.
	 */
	public void setBezahlMethode(IBezahlStrategie bezahlMethode) {
		this.bezahlMethode = bezahlMethode;
	}

}
