package klassen;

/**
 * Das Interface definiert die Methoden vor.
 * 
 * @author S0560885 Kaan Kara
 * @eclipseVersion 2019-09 R (4.13.0)
 * @javaVersion 12
 * @runTime 33
 * @erstellungsDatum 21.10.2019
 * @letzte\u00c4nderungsDatum 10.01.2020
 * 
 */
public interface IObserver {
	/**
	 * Nimmt als Parameter "zahlung" und "betrag". F\u00fcgt die Zahlung in eine
	 * ArrayListe hinzu.
	 * 
	 * @param zahlung wird ben\u00f6tigt.
	 * @param betrag  wird ben\u00f6tigt.
	 */
	public void updateObserver(Zahlung zahlung, double betrag);
}
