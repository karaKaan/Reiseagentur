package klassen;

/**
 * Das Interface definiert die Methoden vor.
 * 
 * @author S0560885 Kaan Kara
 * @eclipseVersion 2019-09 R (4.13.0)
 * @javaVersion 12
 * @runTime 33
 * @erstellungsDatum 21.10.2019
 * @letzte\u00c4nderungsDatum 10.01.2020
 *
 */
public interface IObservable {
	/**
	 * F\u00fcgt die Objekte der Klassen, welches das Interface IObserver
	 * implementiert haben, in eine ArrayListe hinzu.
	 * 
	 * @param observer wird ben\u00f6tigt.
	 */
	public void addObserver(IObserver observer);

	/**
	 * Die Methode l\u00f6scht das Objekt, welches im Parameter weitergegeben wurde.
	 * 
	 * @param observer wird ben\u00f6tigt.
	 */
	public void removeObserver(IObserver observer);

	/**
	 * Iteriert durch eine ArrayListe und ruft die Methode "updateObserver()" von
	 * jedem Objekt der Klassen, welches das das Interface IObserver implementiert
	 * haben. Außerdem werden die Parameter weitergegeben.
	 * 
	 * @param zahlung wird ben\u00f6tigt.
	 * @param betrag  wird ben\u00f6tigt.
	 */
	public void notifyObserver(Zahlung zahlung, double betrag);

}
