package gui;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import klassen.FlugReservierung;
import klassen.HotelReservierung;
import klassen.Kunde;
import klassen.ReiseAgentur;
import klassen.Reservierung;

/***
 *
 * Die GuStarter Klasse erstellt ein Benutzeroberfl\u00e4che f\u00fcr den Nutzer. Dadurch
 * kann er sich die Kunden anzeigen mit den pers\u00f6nlichen Informationen und deren
 * Reservierungen.
 * 
 * @author S0560885 Kaan Kara
 * @eclipseVersion 2019-09 R (4.13.0)
 * @javaVersion 12
 * @runTime 33
 * @erstellungsDatum 21.01.2019
 * @letzte\u00c4nderungsDatum 24.01.2020
 * 
 */
public class GuiStarter extends JFrame {

	private List<String> kundenListe = new ArrayList<>();
	private List<Object> reservierungsListe = new ArrayList<>();

	private GridBagConstraints gridConstraints = new GridBagConstraints();

	private JPanel topPanel;
	private JPanel kundenPanel;

	private JLabel jLabel;
	private JLabel ueberschrift;
	private JLabel kundenGefunden;
	private JLabel lblKundeNummer;
	private JLabel lblGeburtsdatum;
	private JLabel lblAdresse;

	private JTextField jTextField;

	private JList listeGefundeneKunden;
	private JList listeGefundeneReservierung;

	private JScrollPane scrollForKundeList;
	private JScrollPane scrollForReservierungList;

	private JButton jBtnSearch;
	private JMenuBar menuBar;

	/**
	 * Der Konstruktor f\u00fcgt die Panels zum Frame hinzu.
	 * 
	 * @param reiseAgentur - wird ben\u00f6tigt, um auf die Objekten zu greifen.
	 */
	public GuiStarter(ReiseAgentur reiseAgentur) {
		JPanel panel = new JPanel();
		setTitle(reiseAgentur.getName());
		setSize(1000, 550);
		setResizable(false);

		menuBar = initMenu();
		setJMenuBar(menuBar);

		topPanel = initTopPanel(reiseAgentur);
		kundenPanel = initKundenPanel(reiseAgentur);

		panel.setLayout(new GridBagLayout());

		gridConstraints.gridx = 0;
		gridConstraints.gridy = 0;
		gridConstraints.anchor = GridBagConstraints.CENTER;
		panel.add(topPanel, gridConstraints);

		gridConstraints.weighty = 5;
		gridConstraints.gridx = 0;
		gridConstraints.gridy = 1;
		panel.add(kundenPanel, gridConstraints);

		getContentPane().add(panel);

		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocation(200, 300);

	}

	/**
	 * Der Top Panel beschreibt den obersten Panel und f\u00fchrt einen ActionListener
	 * auf einem Button durch.
	 * 
	 * @param reiseAgentur - wird ben\u00f6tigt
	 * @return gibt einen Objekt der Klasse JPanel zur\u00fcck
	 */
	private JPanel initTopPanel(ReiseAgentur reiseAgentur) {
		JPanel panel = new JPanel();

		jBtnSearch = new JButton("Suchen");

		ueberschrift = new JLabel(reiseAgentur.getName());
		ueberschrift.setFont(new Font("Arial", Font.BOLD, 20));

		jLabel = new JLabel("Kundenname:");

		this.jTextField = new JTextField(20);

		jBtnSearch.addActionListener(searchFunction(reiseAgentur, jTextField));

		panel.setLayout(new GridBagLayout());

		gridConstraints.gridx = 2;
		gridConstraints.gridy = 0;
		gridConstraints.insets = new Insets(10, 10, 20, 10);
		panel.add(ueberschrift, gridConstraints);

		gridConstraints.gridx = 1;
		gridConstraints.gridy = 2;
		panel.add(jLabel, gridConstraints);

		gridConstraints.gridx = 2;
		gridConstraints.gridy = 2;
		panel.add(jTextField, gridConstraints);

		gridConstraints.gridx = 3;
		gridConstraints.gridy = 2;
		panel.add(jBtnSearch, gridConstraints);
		return panel;
	}

	/**
	 * Der Kunden Panel ist der Panel wo am Ende die Informationen des Kunden
	 * angezeigt werden.
	 * 
	 * @param reiseAgentur - wird ben\u00f6tigt
	 * @return gibt einen Objekt der Klasse JPanel zur\u00fcck
	 */
	private JPanel initKundenPanel(ReiseAgentur reiseAgentur) {
		JPanel panel = new JPanel();
		JPanel panel2 = new JPanel();
		JPanel panel3 = new JPanel();
		scrollForKundeList = new JScrollPane(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
				JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		scrollForReservierungList = new JScrollPane(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
				JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

		kundenGefunden = new JLabel("Kunden gefunden()");
		lblKundeNummer = new JLabel("Kundennummer: \t");
		lblGeburtsdatum = new JLabel("Geburtsdatum: \t");
		lblAdresse = new JLabel("Adresse: \t");

		listeGefundeneKunden = new JList(kundenListe.toArray());
		listeGefundeneKunden.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		listeGefundeneKunden.addListSelectionListener(findReservierungInfo(reiseAgentur, listeGefundeneKunden));
		listeGefundeneReservierung = new JList(reservierungsListe.toArray());
		listeGefundeneReservierung.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		panel2.setLayout(new GridBagLayout());

		gridConstraints.anchor = GridBagConstraints.WEST;
		gridConstraints.gridx = 0;
		gridConstraints.gridy = 0;
		gridConstraints.insets = new Insets(2, 2, 2, 2);
		panel2.add(kundenGefunden, gridConstraints);

		gridConstraints.gridx = 0;
		gridConstraints.gridy = 2;
		scrollForKundeList.setViewportView(listeGefundeneKunden);
		scrollForKundeList.setPreferredSize(new Dimension(300, 340));
		panel2.add(scrollForKundeList, gridConstraints);

		panel3.setLayout(new GridBagLayout());

		gridConstraints.gridx = 1;
		gridConstraints.gridy = 0;
		panel3.add(lblKundeNummer, gridConstraints);

		gridConstraints.gridx = 1;
		gridConstraints.gridy = 1;
		panel3.add(lblGeburtsdatum, gridConstraints);

		gridConstraints.gridx = 1;
		gridConstraints.gridy = 2;
		panel3.add(lblAdresse, gridConstraints);

		gridConstraints.gridx = 1;
		gridConstraints.gridy = 3;

		scrollForReservierungList.setViewportView(listeGefundeneReservierung);
		scrollForReservierungList.setPreferredSize(new Dimension(300, 300));
		panel3.add(scrollForReservierungList, gridConstraints);

		panel.setLayout(new GridBagLayout());

		gridConstraints.ipady = 0;
		gridConstraints.gridx = 0;
		gridConstraints.gridy = 0;
		panel.add(panel2, gridConstraints);

		gridConstraints.gridx = 1;
		gridConstraints.gridy = 0;
		panel.add(panel3, gridConstraints);

		return panel;
	}

	/**
	 * Legt einen JMenuBar an, sowie die Menu(Men\u00fcpunkten) und die untergeordneten
	 * Items.
	 * 
	 * @return gibt einen Objekt der Klasse JMenuBar zur\u00fcck.
	 */
	private JMenuBar initMenu() {
		JMenuBar menuBar = new JMenuBar();
		JMenu menuInfo = new JMenu("Info");
		JMenuItem itemAbout = new JMenuItem("About");

		menuInfo.add(itemAbout);
		menuBar.add(menuInfo);

		itemAbout.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(itemAbout, "Kaan Kara, s0560885");
			}
		});
		return menuBar;
	}

	/**
	 * Erstellt einen Listener, der die Eingabe sequenzweise mit dem Objekt der
	 * Klasse Kunde \u00fcberpr\u00fcft. Durch die set-Methoden werden die JListe und der
	 * Label aktualisiert.
	 * 
	 * @param reiseAgentur - wird ben\u00f6tigt.
	 * @param jTextfield   - wird ben\u00f6tigt.
	 * @return gibt einen Objekt der Klasse ActionListener zur\u00fcck.
	 */
	private ActionListener searchFunction(ReiseAgentur reiseAgentur, JTextField jTextfield) {
		ActionListener search = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				kundenListe = new ArrayList<>();
				String textFieldInput = jTextfield.getText();

				for (Kunde kunde : reiseAgentur.getKundeArrList()) {
					if (kunde.getNachname().toLowerCase().contains(textFieldInput.toLowerCase())) {
						kundenListe.add(kunde.getVorname() + " " + kunde.getNachname());

					} else if (kunde.getVorname().toLowerCase().contains(textFieldInput.toLowerCase())) {
						kundenListe.add(kunde.getVorname() + " " + kunde.getNachname());
					}
				}
				kundenGefunden.setText("Kunden gefunden (" + kundenListe.size() + ")");
				listeGefundeneKunden.setListData(kundenListe.toArray());
			}
		};
		return search;
	}

	/**
	 * Erstellt einen Listener, der die Auswahl des Nutzer mit dem Objekt der Klasse
	 * Reservierung vergleicht und wieder gibt. Die JListe sowie die Labels werden
	 * durch die set-Methode aktualisiert.
	 * 
	 * @param reiseAgentur - wird ben\u00f6tigt
	 * @param list         - wird ben\u00f6tigt
	 * @return gibt einen Objekt der Klasse ListSelectionListener zur\u00fcck.
	 */
	private ListSelectionListener findReservierungInfo(ReiseAgentur reiseAgentur, JList list) {
		ListSelectionListener findOnClick = new ListSelectionListener() {

			public void valueChanged(ListSelectionEvent e) {
				if (!reservierungsListe.isEmpty()) {
					reservierungsListe = new ArrayList<>();
				} else {
					if (e.getValueIsAdjusting()) {
						for (Kunde kunde : reiseAgentur.getKundeArrList()) {
							Object selectedKunde = list.getSelectedValue();
							if (selectedKunde.equals(kunde.getVorname() + " " + kunde.getNachname())) {

								lblKundeNummer.setText("Kundennummer: \t" + kunde.getKundenNr());
								lblGeburtsdatum.setText("Geburtsdatum: \t" + kunde.getGeburtsDatum());
								lblAdresse.setText("Adresse: \t" + kunde.getAdresse().getStrasse() + " "
										+ kunde.getAdresse().getHausNr() + ", " + kunde.getAdresse().getPlz() + " "
										+ kunde.getAdresse().getOrt());

								for (Reservierung reservierung : kunde.getKundeInReservierungArrList()) {

									if (reservierung instanceof FlugReservierung) {
										reservierungsListe
												.add(reservierung.getReservierungsNr() + ", " + reservierung.getDatum()
														+ ", " + ((FlugReservierung) reservierung).getFlugNr());

									} else if (reservierung instanceof HotelReservierung) {
										reservierungsListe.add(reservierung.getReservierungsNr() + ", "
												+ reservierung.getDatum() + ", beim "
												+ ((HotelReservierung) reservierung).getHotelName());
									}
								}
							}
							listeGefundeneReservierung.setListData(reservierungsListe.toArray());
						}
					}
				}
			}
		};
		return findOnClick;
	}

}
