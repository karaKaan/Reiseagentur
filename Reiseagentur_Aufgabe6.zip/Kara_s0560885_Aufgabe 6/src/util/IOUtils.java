/**
 * 
 */
package util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.CharsetEncoder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.Collections;
import java.util.Scanner;

import comparator.NachnameComparator;
import klassen.Kunde;
import klassen.ReiseAgentur;

/**
 * 
 * Ein Utility Klasse, wo die Attributen static sind und bei Eingabe der
 * Klassennamen aufgerufen werden können. Diese Utility Klasse beinhaltet
 * notwendige Methoden für den IO-Java.
 * 
 * @author S0560885 Kaan Kara
 * @eclipseVersion 2019-09 R (4.13.0)
 * @javaVersion 12
 * @runTime 33
 * @erstellungsDatum 21.10.2019
 * @letzte\u00c4nderungsDatum 23.12.2019
 */
public class IOUtils {

	/**
	 * Fragt den Nutzer nach dem Dateipfad und der Nutzer kann diese hier eingeben.
	 * 
	 * @return einen String filePath zu anderen Methoden.
	 */
	public static String filePath() {
		Scanner scanner = new Scanner(System.in);

		System.out.println("Bitte geben Sie den Dateipfad ein.");
		System.out.println("Als Beispiel: C:/Users/{Dateipfad}");
		String filePath = scanner.nextLine();

		return filePath;

	}

	/**
	 * Nimmt 2 Parameter, die eine ist von der Klasse ReiseAgentur und die andere
	 * vom String. Es wird ebenfalls nach dem Dateinamen gefragt und bei Eingabe
	 * werden die Daten der Klasse ReiseAgentur reingeschrieben.
	 * 
	 * @param reiseAgentur
	 * @param filePath
	 * @return true - wenn alles funktioniert.
	 * @return false - wenn es nicht funktioniert hat.
	 */
	public static boolean exportData(ReiseAgentur reiseAgentur, String filePath) {
		Scanner scanner = new Scanner(System.in);
		ObjectOutputStream objectOutputStream = null;

		File file = new File(filePath);

		System.out.println("Bitte geben Sie den Namen der Datei an. Vergessen Sie nicht die Endung mit anzugeben.");
		String fileName = scanner.nextLine();

		try {

			if (!file.exists() && !file.isDirectory()) {
				file.mkdirs();
			}
			if (file.exists() && file.isDirectory()) {

				objectOutputStream = new ObjectOutputStream(new FileOutputStream(new File(file, fileName)));
				objectOutputStream.writeObject(reiseAgentur);
				objectOutputStream.flush();

				return true;
			} else {
				System.out.println("Der Dateipfad konnte leider nicht erstellt/gefunden werden.");
				System.out.println("Sie haben vermutlich eine ung\u00fcltige Eingabe in Ihrem Dateipfad: "
						+ file.getAbsolutePath());
			}
		} catch (FileNotFoundException e) {
			System.out.println("Der Dateienname besitzt eine ung\u00fcltige Eingabe: " + fileName);
		} catch (IOException e) {
			System.out.println(e);
		} finally {
			if (objectOutputStream != null) {
				try {
					objectOutputStream.close();
				} catch (Exception e) {
					System.out.println(e);
				}
			}
		}
		return false;
	}

	/**
	 * Es wird nach dem Dateipfad gefragt mit Eingabe des Dateiennamens. Es
	 * importiert die Daten aus der Datei in die Variable magicHolidaysReiseAgentur.
	 * 
	 * @return magicHolidaysReiseAgentur - sodass es im sp\u00e4teren Verlauf, die
	 *         im System gespeicherte Variable der Klasse ReiseAgentur, ersetzt.
	 */
	public static ReiseAgentur importData() {
		Scanner scanner = new Scanner(System.in);

		ObjectInputStream objectInputStream = null;
		ReiseAgentur magicHolidaysReiseAgentur = null;

		System.out.println("Bitte geben Sie den Dateipfad mit dem Namen der Datei an, die Sie exportiert haben.");
		String filePath = scanner.nextLine();

		File importedFile = new File(filePath);
		if (!importedFile.exists()) {
			System.out
					.println("Die Datei existiert nicht oder Sie haben einen falschen Pfad angegeben: " + importedFile);
			return null;
		}
		if (!importedFile.canRead()) {
			System.out.println("Datei kann nicht gelesen werden: " + importedFile);
			return null;
		}
		if (!importedFile.isFile()) {
			System.out.println("Datei ist keine Datei: " + importedFile);
			return null;
		}

		try {

			objectInputStream = new ObjectInputStream(new FileInputStream(new File(filePath)));
			Object importedObject = (Object) objectInputStream.readObject();
			if (importedObject instanceof ReiseAgentur) {
				magicHolidaysReiseAgentur = (ReiseAgentur) importedObject;
			}

		} catch (IOException e) {
			System.out.println(e);
		} catch (ClassNotFoundException e) {
			System.out.println(e);
		} finally {
			if (objectInputStream != null) {
				try {
					objectInputStream.close();
				} catch (Exception e) {
					System.out.println(e);
				}
			}
		}

		return magicHolidaysReiseAgentur;

	}

	/**
	 * Sortiert zun\u00e4chst die ArrayListe der Kunden und nach Eingabe des
	 * filePath, sowie der Dateienname werden die Namen und Anzahl an Reservierung
	 * und die Email Adresse als csv exportiert. Die exportierte csv-Datei ist in
	 * UTF-8 kodiert.
	 * 
	 * @param reiseAgentur
	 * @param filePath
	 */
	public static void exportSortedKundeAsCsv(ReiseAgentur reiseAgentur, String filePath) {
		Scanner scanner = new Scanner(System.in);
		int anzahlKundenInCsv = 0;

		Collections.sort(reiseAgentur.getKundeArrList(), new NachnameComparator());

		OutputStreamWriter outputWriter = null;
		OutputStream outputStream = null;

		System.out.println(
				"Bitte geben Sie den Namen der Datei an. Hierbei brauchen Sie die Endung(.csv) nicht anzugeben.");
		String fileName = scanner.nextLine() + ".csv";

		File file = new File(filePath);
		File filePathAndName = new File(file, fileName);

		if (file.exists()) {
			System.out.println("Datei existiert und wurde \u00fcberschrieben.");
		}
		try {
			if (!file.exists() && !file.isDirectory()) {
				file.mkdirs();
			}
			if (file.exists() && file.isDirectory()) {
				System.out.println(file);
				outputStream = new FileOutputStream(filePathAndName);
				outputWriter = new OutputStreamWriter(outputStream, "utf-8");

				outputWriter.append("Name,");
				outputWriter.append("Anzahl der Reservierungen,");
				outputWriter.append("Email-Adresse\n");

				for (Kunde kunde : reiseAgentur.getKundeArrList()) {

					outputWriter.append(kunde.getVorname() + " " + kunde.getNachname() + ",");
					outputWriter.append(reiseAgentur.anzahlReservierung(kunde) + ",");
					outputWriter.append(kunde.getEmailAdresse() + "\n");

					outputWriter.flush();

					anzahlKundenInCsv++;
				}
				System.out.println(anzahlKundenInCsv + " Datens\u00e4tze in die Datei <"
						+ filePathAndName.getAbsolutePath() + "> exportiert.");
			} else {
				System.out.println("Der Dateipfad konnte leider nicht erstellt/gefunden werden.");
				System.out.println("Sie haben vermutlich eine ung\u00fcltige Eingabe in Ihrem Dateipfad: "
						+ file.getAbsolutePath());
			}
		} catch (FileNotFoundException e) {
			System.out.println("Der Dateienname besitzt eine ung\u00fcltige Eingabe: " + fileName);
		} catch (IOException e) {
			e.getStackTrace();
		} finally {
			if (outputStream != null && outputWriter != null) {
				try {
					outputStream.close();
					outputWriter.close();

				} catch (IOException e) {
					e.getStackTrace();
				}
			}
		}
	}
}
