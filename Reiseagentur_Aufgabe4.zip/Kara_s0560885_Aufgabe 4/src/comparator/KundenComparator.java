package comparator;

import java.util.Comparator;

import klassen.Kunde;

/***
 * Sortiert eine ArrayListe von Kunden.
 * 
 * @author S0560885 Kaan Kara
 * @eclipseVersion 2019-09 R (4.13.0)
 * @javaVersion 12
 * @runTime 33
 * @erstellungsDatum 21.10.2019
 * @letzte\u00c4nderungsDatum 07.12.2019
 * 
 */
public class KundenComparator implements Comparator<Kunde> {

	/**
	 * Nimmt als Parameter 2 Kunden an, das eine lautet Kunde k1 und das ander Kunde
	 * k2. Zun\u00e4chst werden die Vornamen der Kunden \u00fcberpr\u00fcft und
	 * sollte dies identisch sein, wird dann der Nachname mit einander verglichen.
	 * Es wird aufsteigend sortiert.
	 */
	@Override
	public int compare(Kunde k1, Kunde k2) {

		int compareVorname = k1.getVorname().toLowerCase().compareTo(k2.getVorname().toLowerCase());
		int compareNachname = k1.getNachname().toLowerCase().compareTo(k2.getNachname().toLowerCase());
		if (compareVorname == 0) {
			return compareNachname;
		}
		return compareVorname;
	}

}
