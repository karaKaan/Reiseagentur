package comparator;

import java.util.Comparator;
import java.util.Map.Entry;

/***
 *
 * Sortiert eine ArrayListe, wobei die Values miteinander verglichen werden.
 * 
 * @author S0560885 Kaan Kara
 * @eclipseVersion 2019-09 R (4.13.0)
 * @javaVersion 12
 * @runTime 33
 * @erstellungsDatum 21.10.2019
 * @letzte\u00c4nderungsDatum 07.12.2019
 * 
 */

public class BezahlMethodeComparator implements Comparator<Entry<String, Integer>> {

	/**
	 * Nimmt 2 Parametern von Entries an Entry o1 und Entry o2. Vergleicht die
	 * Values von den Entries, den ich als Parameter weitergegeben haben. Es wird
	 * absteigend sortiert.
	 */
	@Override
	public int compare(Entry<String, Integer> o1, Entry<String, Integer> o2) {
		int compareAnzahl = -1 * o1.getValue().compareTo(o2.getValue());
		return compareAnzahl;
	}

}
