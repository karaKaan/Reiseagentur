package klassen;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * Die Klasse GeschaeftsKunde erbt von der abstrakten Klasse Kunde. Durch diese
 * Klasse, kann man ein Objekt der Klasse GeschaeftsKunde erstellen.
 * 
 * @author S0560885 Kaan Kara
 * @eclipseVersion 2019-09 R (4.13.0)
 * @javaVersion 12
 * @runTime 33
 * @erstellungsDatum 21.10.2019
 * @letzte\u00c4nderungsDatum 07.12.2019
 *
 */

public class GeschaeftsKunde extends Kunde implements Serializable{
	String firmenName;
	private BezahlMethode bezahlMethodeFuerGeschaeftsKunde;
	private BezahlMethode[] bezahlMethodeFuerGeschaeftsKundeList = new BezahlMethode[1];

	/**
	 * Die Signatur des Konstruktors muss erf\u00fcllt werden, damit ein Objekt der
	 * Klasse Adresse entstehen kann. Daf\u00fcr m\u00fcssen die Parameter(siehe
	 * unten) vollst\u00e4ndig ausgef\u00fcllt werden.
	 * 
	 * @param kundenNr                             wird ben\u00f6tigt.
	 * @param anrede                               wird ben\u00f6tigt.
	 * @param vornamen                             wird ben\u00f6tigt.
	 * @param nachnamen                            wird ben\u00f6tigt.
	 * @param emailAdresse                         wird ben\u00f6tigt.
	 * @param telefonNr                            wird ben\u00f6tigt.
	 * @param geburtsDatum                         wird ben\u00f6tigt.
	 * @param privateAdresse                       wird ben\u00f6tigt.
	 * @param firmenName                           wird ben\u00f6tigt.
	 * @param bezahlMethodeF\u00fcrGeschaeftsKunde wird ben\u00f6tigt.
	 */
	public GeschaeftsKunde(int kundenNr, String anrede, String vorname, String nachname, String emailAdresse,
			String telefonNr, LocalDate geburtsDatum, String firmenName) {
		super(kundenNr, anrede, vorname, nachname, emailAdresse, telefonNr, geburtsDatum);
		this.firmenName = firmenName;

	}

	/**
	 * 
	 */
	@Override
	public void getName() {
		super.setVollstaendigerName(this.getVorname() + " " + this.getNachname() + " - " + this.getFirmenName());
	}

	public void storeBezahlMethodeToArray(BezahlMethode bezahlMethode) {
		this.bezahlMethodeFuerGeschaeftsKundeList[0] = bezahlMethode;
	}

	/**
	 * Gibt die Variable firmenName zur\u00fcck.
	 * 
	 * @return firmenName wird zur\u00fcckgegeben.
	 */
	public String getFirmenName() {
		return firmenName;
	}

	/**
	 * Legt die Variable firmenName an.
	 * 
	 * @param firmenName wird ben\u00f6tigt.
	 */
	public void setFirmenName(String firmenName) {
		this.firmenName = firmenName;
	}

	/**
	 * Gibt die Variable bezahlMethodeF\u00fcrPrivatKunde der Klasse BezahlMethode
	 * zur\u00fcck.
	 * 
	 * @return bezahlMethodeF\u00fcrGeschaeftsKunde wird zur\u00fcckgegeben.
	 */
	public BezahlMethode getBezahlMethodeFuerGeschaeftsKunde() {
		return bezahlMethodeFuerGeschaeftsKunde;
	}

	/**
	 * Legt den Objekt der Klasse BezahlMethode, als Variable
	 * bezahlMethodeF\u00fcrGeschaeftsKunde an.
	 * 
	 * @param bezahlMethodeF\u00fcrGeschaeftsKunde wird ben\u00f6tigt.
	 */
	public void setBezahlMethodeFuerGeschaeftsKunde(BezahlMethode bezahlMethodeFuerGeschaeftsKunde) {
		this.bezahlMethodeFuerGeschaeftsKunde = bezahlMethodeFuerGeschaeftsKunde;
	}

	/**
	 * Gibt den Array bezahlMethodeF\u00fcrGeschaeftsKundeList, der nur Objekte der
	 * Klasse BezahlMethode akzeptiert, wieder.
	 * 
	 * @return bezahlMethodeF\u00fcrGeschaeftsKundeList wird zur\u00fcckgegeben.
	 */
	public BezahlMethode[] getBezahlMethodeFuerGeschaeftsKundeList() {
		return bezahlMethodeFuerGeschaeftsKundeList;
	}

	/**
	 * Legt die ArrayListe bezahlMethodeF\u00fcrGeschaeftsKundeList, der nur Objekte
	 * der Klasse BezahlMethode akzeptiert, an.
	 * 
	 * @param bezahlMethodeF\u00fcrGeschaeftsKundeList wird ben\u00f6tigt.
	 */
	public void setBezahlMethodeFuerGeschaeftsKundeList(BezahlMethode[] bezahlMethodeFuerGeschaeftsKundeList) {
		this.bezahlMethodeFuerGeschaeftsKundeList = bezahlMethodeFuerGeschaeftsKundeList;
	}

}
