package klassen;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Die Klasse PrivatKunde erbt von der abstrakten Klasse Kunde. Durch diese
 * Klasse, kann man ein Objekt der Klasse PrivatKunden erstellen.
 * 
 * 
 * @author S0560885 Kaan Kara
 * @eclipseVersion 2019-09 R (4.13.0)
 * @javaVersion 12
 * @runTime 33
 * @erstellungsDatum 21.10.2019
 * @letzte\u00c4nderungsDatum 07.12.2019
 *
 */
public class PrivatKunde extends Kunde implements Serializable{
	private BezahlMethode bezahlMethodeFuerPrivatKunde;
	private List<BezahlMethode> bezahlMethodeFuerPrivatKundeArrList = new ArrayList<BezahlMethode>();

	/**
	 * Die Signatur des Konstruktors muss erf\u00fcllt werden, damit ein Objekt der
	 * Klasse Adresse entstehen kann. Daf\u00fcr m\u00fcssen die Parameter(siehe
	 * unten) vollst\u00e4ndig ausgef\u00fcllt werden.
	 * 
	 * @param kundenNr                         wird ben\u00f6tigt.
	 * @param anrede                           wird ben\u00f6tigt.
	 * @param vornamen                         wird ben\u00f6tigt.
	 * @param nachnamen                        wird ben\u00f6tigt.
	 * @param emailAdresse                     wird ben\u00f6tigt.
	 * @param telefonNr                        wird ben\u00f6tigt.
	 * @param geburtsDatum                     wird ben\u00f6tigt.
	 * @param privateAdresse                   wird ben\u00f6tigt.
	 * @param bezahlMethodeF\u00fcrPrivatKunde wird ben\u00f6tigt.
	 */
	public PrivatKunde(int kundenNr, String anrede, String vorname, String nachname, String emailAdresse,
			String telefonNr, LocalDate geburtsDatum) {
		super(kundenNr, anrede, vorname, nachname, emailAdresse, telefonNr, geburtsDatum);

	}

	@Override
	public void getName() {
		super.setVollstaendigerName(this.getVorname() + " " + this.getNachname());
	}

	@Override
	public void storeBezahlMethodeToArray(BezahlMethode bezahlMethode) {
		this.bezahlMethodeFuerPrivatKundeArrList.add(bezahlMethode);
	}

	/**
	 * Gibt die Variable bezahlMethodeF\u00fcrPrivatKunde, der Klasse BezahlMethode,
	 * zur\u00fcck.
	 * 
	 * @return bezahlMethodeF\u00fcrPrivatKunde wird zur\u00fcckgegeben.
	 */
	public BezahlMethode getBezahlMethodeFuerPrivatKunde() {
		return bezahlMethodeFuerPrivatKunde;
	}

	/**
	 * Legt den Objekt der Klasse BezahlMethode, als Variable
	 * bezahlMethodeF\u00fcrPrivatKunde an.
	 * 
	 * @param bezahlMethodeF\u00fcrPrivatKunde wird ben\u00f6tigt.
	 */
	public void setBezahlMethodeFuerPrivatKunde(BezahlMethode bezahlMethodeFuerPrivatKunde) {
		this.bezahlMethodeFuerPrivatKunde = bezahlMethodeFuerPrivatKunde;
	}

	/**
	 * Gibt die ArrayListe bezahlMethodeF\u00fcrPrivatKundeArrList, der Objekte der
	 * Klasse BezahlMethode akzeptiert, wieder.
	 * 
	 * @return bezahlMethodeF\u00fcrPrivatKundeArrList wird zur\u00fcckgegeben.
	 */
	public List<BezahlMethode> getBezahlMethodeFuerPrivatKundeArrList() {
		return bezahlMethodeFuerPrivatKundeArrList;
	}

	/**
	 * Legt die ArrayListe bezahlMethodeF\u00fcrPrivatKundeArrList, der Objekte der
	 * Klasse BezahlMethode akzeptiert, an.
	 * 
	 * @param bezahlMethodeF\u00fcrPrivatKundeArrList wird ben\u00f6tigt.
	 */
	public void setBezahlMethodeFuerPrivatKundeArrList(List<BezahlMethode> bezahlMethodeFuerPrivatKundeArrList) {
		this.bezahlMethodeFuerPrivatKundeArrList = bezahlMethodeFuerPrivatKundeArrList;
	}
}
