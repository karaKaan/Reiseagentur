package klassen;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import comparator.NachnameComparator;

/***
 * 
 * Die Klasse ReiseAgentur ist Vorrausetzung, dass ein Objekt der Klasse
 * ReiseAgentur angelegt werden kann. Au\u00dferdem f\u00fcgt es die Objekte der
 * Klasse Kunde in eine ArrayList.
 * 
 * 
 * @author S0560885 Kaan Kara
 * @eclipseVersion 2019-09 R (4.13.0)
 * @javaVersion 12
 * @runTime 33
 * @erstellungsDatum 21.10.2019
 * @letzte\u00c4nderungsDatum 23.12.2019
 * 
 */

public class ReiseAgentur implements Comparable<Kunde>, Serializable {

	/***
	 * Als Attribute f\u00fcr die Klasse ReiseAgentur wurde ein String ustIdNr,
	 * String name, ein Objekt der Klasse Adresse businessAdresse und eine
	 * ArrayListe kundeArrList die, die Objekte der Klasse Kunde aufnehmen kann,
	 * angelegt.
	 * 
	 * Au\u00dferdem sind die Variablen alle private.
	 * 
	 */

	private String ustIdNr;
	private String name;
	private Adresse businessAdresse;
	private List<Kunde> kundeArrList = new ArrayList<>();
	private Map<String, Integer> anzahlBezahlMethodeMap = new HashMap<>();
	private Map<LocalDate, Set<Reservierung>> reservierungsIndex = new LinkedHashMap<>();
	private int points = 0;

	/**
	 * Der Konstruktor ben\u00f6tigt die Variablen String ustIdNr, String name und
	 * Adresse businessAdresse. Wenn die Signatur des Konstruktor richtig
	 * eingetragen worden ist, wird ein Objekt der Klasse ReiseAgentur angelegt.
	 * 
	 * @param ustIdNr         wird ben\u00f6tigt.
	 * @param name            wird ben\u00f6tigt.
	 * @param businessAdresse wird ben\u00f6tigt.
	 * @param kunde           wird ben\u00f6tigt.
	 */
	public ReiseAgentur(String ustIdNr, String name, Adresse businessAdresse) {
		super();
		this.ustIdNr = ustIdNr;
		this.name = name;
		this.businessAdresse = businessAdresse;

	}
	
	/**
	 * Nimmt als Parameter die Klasse Kunde entgegen.
	 * Es wird \u00fcberpr\u00fcft ob der Kunde in der ArrayListe getKundeInReservierungArrList() vorhanden ist. 
	 * Jedes mal wenn der selbe Kunde eine Reservierung hat wird der int anzahl um 1 addiert.
	 * 
	 * @param kunde
	 * @return int anzahl wird zur\u00fcckgegeben.
	 */
	public int anzahlReservierung(Kunde kunde) {
			int anzahl = 0;
			
			for(Reservierung reservierung : kunde.getKundeInReservierungArrList()) {
				if(!kunde.getKundeInReservierungArrList().isEmpty()) {
					anzahl += 1;	
				}else {
					anzahl = 0;
				}
			}
			return anzahl;
	}
	
	
	/**
	 * F\u00fcgt Objekte der Klasse Kunde in einer ArrayListe hinzu.
	 * 
	 * @param kunde - akzeptiert nur Objekte der Klasse Kunde.
	 */
	public void storeKundeToArrList(Kunde kunde) {
		this.getKundeArrList().add(kunde);
		bezahlMethodeMapAnlegen();
		givePoints();
	}

	/**
	 * Gibt Punkte wenn beim Map die Bezeichnungen gleich sind.
	 */
	public void givePoints() {

		for (Kunde kunde : this.getKundeArrList()) {
			if (kunde instanceof PrivatKunde) {
				PrivatKunde privatKunde = (PrivatKunde) kunde;
				for (BezahlMethode bezahlMethode : privatKunde.getBezahlMethodeFuerPrivatKundeArrList()) {
					for (Map.Entry<String, Integer> entry : this.anzahlBezahlMethodeMap.entrySet()) {
						if (entry.getKey().toLowerCase().equals(bezahlMethode.getBezeichnung().toLowerCase())) {
							this.anzahlBezahlMethodeMap.put(entry.getKey(), entry.getValue() + 1);
						}
					}

				}
			}
			if (kunde instanceof GeschaeftsKunde) {
				GeschaeftsKunde geschaeftsKunde = (GeschaeftsKunde) kunde;
				for (Map.Entry<String, Integer> entry : this.anzahlBezahlMethodeMap.entrySet()) {
					if (entry.getKey().toLowerCase().equals(geschaeftsKunde.getBezahlMethodeFuerGeschaeftsKundeList()[0].getBezeichnung().toLowerCase())) {
						this.anzahlBezahlMethodeMap.put(entry.getKey(), entry.getValue() + 1);
					}
				}
			}
		}
	}



	/**
	 * F\u00fcgt die Bezeichnung von Bezahlmethode sowie die Punkte einem Map hinzu.
	 */
	public void bezahlMethodeMapAnlegen() {
		for (Kunde kunde : this.getKundeArrList()) {
			if (kunde instanceof PrivatKunde) {
				PrivatKunde privatKunde = (PrivatKunde) kunde;
				for (BezahlMethode bezahlMethode : privatKunde.getBezahlMethodeFuerPrivatKundeArrList()) {
					this.getAnzahlBezahlMethodeMap().put(bezahlMethode.getBezeichnung().toLowerCase(), this.getPoints());
				}
			}
			if (kunde instanceof GeschaeftsKunde) {
				GeschaeftsKunde geschaeftsKunde = (GeschaeftsKunde) kunde;
				this.getAnzahlBezahlMethodeMap().put(
						geschaeftsKunde.getBezahlMethodeFuerGeschaeftsKundeList()[0].getBezeichnung().toLowerCase(),
						this.getPoints());
			}
		}
	}

	/**
	 * Sortiert die Kunden nach dem Nachnamen aufsteigend.
	 */
	public void sortKunde() {
		Collections.sort(this.getKundeArrList(), new NachnameComparator());
	}

	/**
	 * Speichert die sortierte Liste an Reservierungen in einen LinkedHashMap. Falls
	 * das Key (Datum) gleich sein sollte, soll der Code den zweiten Value
	 * hinzuf\u00fcgen
	 */
	public void storeSortedReservierungInIndex() {
		this.sortKunde();
		Set<Reservierung> reservierungHashSet;

		for (Kunde kunde : this.getKundeArrList()) {
			for (Reservierung reservierung : kunde.getKundeInReservierungArrList()) {
				if (this.getReservierungsIndex().containsKey(reservierung.getDatum())) {
					this.getReservierungsIndex().get(reservierung.getDatum()).add(reservierung);
				} else {
					reservierungHashSet = new HashSet<>();
					reservierungHashSet.add(reservierung);
					this.getReservierungsIndex().put(reservierung.getDatum(), reservierungHashSet);
				}
			}
		}

	}

	/**
	 * Gibt die Variable ustIdNr zur\u00fcck.
	 * 
	 * @return the ustIdNr wird zur\u00fcckgegeben.
	 */
	public String getUstIdNr() {
		return ustIdNr;
	}

	/**
	 * Legt die Variable ustIdNr an.
	 * 
	 * @param ustIdNr wird ben\u00f6tigt.
	 */
	public void setUstIdNr(String ustIdNr) {
		this.ustIdNr = ustIdNr;
	}

	/**
	 * Gibt die Variable name zur\u00fcck.
	 * 
	 * @return name wird zur\u00fcckgegeben.
	 */
	public String getName() {
		return name;
	}

	/**
	 * Legt die Variable name an.
	 * 
	 * @param name wird ben\u00f6tigt.
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Gibt den Objekt der Klasse Adresse, als Variable businessAdresse zur\u00fcck.
	 * 
	 * @return businessAdresse wird zur\u00fcckgegeben.
	 */
	public Adresse getBusinessAdresse() {
		return businessAdresse;
	}

	/**
	 * Legt den Objekt der Klasse Adresse, als Variable businessAdresse an.
	 * 
	 * @param businessAdresse wird ben\u00f6tigt.
	 */
	public void setBusinessAdresse(Adresse businessAdresse) {
		this.businessAdresse = businessAdresse;
	}

	/**
	 * Gibt eine Liste von Objekten der Klasse Kunde zur\u00fcck.
	 * 
	 * @return kunde wird zur\u00fcckgegeben.
	 */
	public List<Kunde> getKundeArrList() {
		return kundeArrList;
	}

	/**
	 * Legt die Objekte der Klasse Kunde an.
	 * 
	 * @param kunde wird ben\u00f6tigt.
	 */
	public void setKundeArrList(List<Kunde> kunde) {
		this.kundeArrList = kunde;
	}

	@Override
	public int compareTo(Kunde k) {

		return 0;
	}

	/**
	 * Gibt die Variable points zur\u00fcck.
	 * 
	 * @return points wird zur\u00fcckgegeben.
	 */
	public int getPoints() {
		return points;
	}

	/**
	 * Legt die Variable points an.
	 * 
	 * @param points wird angleget.
	 */
	public void setPoints(int points) {
		this.points = points;
	}

	/**
	 * Gibt einen Map von String als Key und Integer als Value zur\u00fcck.
	 * 
	 * @return anzahlBezahlMethodeMap wird zur\u00fcckgegeben.
	 */
	public Map<String, Integer> getAnzahlBezahlMethodeMap() {
		return anzahlBezahlMethodeMap;
	}

	/**
	 * Legt einen Map an.
	 * 
	 * @param anzahlBezahlMethodeMap wird angelegt.
	 */
	public void setAnzahlBezahlMethodeMap(Map<String, Integer> anzahlBezahlMethodeMap) {
		this.anzahlBezahlMethodeMap = anzahlBezahlMethodeMap;
	}

	/**
	 * Gibt einen Map mit dem Key LocalDate und dem Value Set<Reservierung>
	 * zur\u00fcck.
	 * 
	 * @return reservierungsIndex wird zur\u00fcckgegeben.
	 */
	public Map<LocalDate, Set<Reservierung>> getReservierungsIndex() {
		return reservierungsIndex;
	}

	/**
	 * Ein Map wird angelegt.
	 * 
	 * @param reservierungsIndex wird angelegt.
	 */
	public void setReservierungsIndex(Map<LocalDate, Set<Reservierung>> reservierungsIndex) {
		this.reservierungsIndex = reservierungsIndex;
	}
}
